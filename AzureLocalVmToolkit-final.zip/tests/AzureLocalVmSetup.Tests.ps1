﻿#Requires -Version 5.1
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$root = Split-Path $PSScriptRoot
Import-Module (Join-Path $root 'tools\AzureLocalVmRegistration.psm1') -Force
$module = Get-Module AzureLocalVmRegistration
$example = Get-Content (Join-Path $root 'examples\registration.example.json') -Raw
$passed = 0
$directory = Join-Path ([IO.Path]::GetTempPath()) ('AzureLocalSetupTests-' + [guid]::NewGuid().ToString('N'))
$null = New-Item -ItemType Directory -Path $directory
$credential = [pscredential]::new('Administrator', (ConvertTo-SecureString 'offline-fixture-only' -AsPlainText -Force))
function Assert($Condition, [string]$Message) { if (-not $Condition) { throw $Message } }
function Test-Case([string]$Name, [scriptblock]$Body) { & $Body; $script:passed++; Write-Host "PASS $Name" }
function Assert-Throws([scriptblock]$Body, [string]$Pattern) {
    $record = $null
    try { & $Body | Out-Null } catch { $record = $_ }
    Assert ($null -ne $record -and $record.Exception.Message -match $Pattern) "Expected failure: $Pattern."
    return $record
}
& $module {
    $script:OriginalNicCommand = (Get-Command Invoke-AzureLocalVmNicReplacement).ScriptBlock
    function script:Get-LabAzureContext { param($Configuration) $script:S.Events.Add('Context'); return @{} }
    function script:Test-LabInfrastructure { param($Configuration,$Context,$OwnerNodeSession) $script:S.Events.Add('Infrastructure') }
    function script:Test-LabGuestAccess { param($Configuration,$OwnerNodeSession,$Credential) $script:S.Events.Add('GuestAccess') }
    function script:Test-LabSetupNicPreflight {
        param($Configuration,$Context,$OwnerNodeSession,$GuestCredential,$Replacement)
        $script:S.Events.Add('NicPreflight')
        $script:S.PreflightNetwork = $Replacement.LogicalNetworkId
        if ($script:S.Scenario -eq 'PreflightFailure') { throw 'Mock source/pool preflight failed.' }
        if (-not $Replacement.BackupPath -or $Replacement.PrivateIPAddress -ne '192.0.2.30') { throw 'Preflight parameters lost.' }
        if (-not $Replacement.SourceNetworkAdapterId) {
            if ($script:S.Scenario -eq 'MultipleSources') { throw 'Automatic source NIC selection requires exactly one Hyper-V adapter.' }
            $Replacement.SourceNetworkAdapterId = "Microsoft:$($Configuration.ExpectedVmId)\77777777-7777-7777-7777-777777777777"
        }
    }
    function script:Invoke-AzureLocalVmRegistration {
        param($Configuration,$OwnerNodeSession,$Execute,$EnableUnsupportedLabPreview,$Confirm,$TimeoutSeconds,$PollSeconds)
        $script:S.Events.Add('Registration')
        if (-not $Execute -or -not $EnableUnsupportedLabPreview) { throw 'Missing registration consent.' }
        if ($script:S.Scenario -eq 'RegistrationFailure') {
            $e = [InvalidOperationException]::new('Mock registration failed.')
            $e.Data['RegistrationReport'] = @{ Status = 'Failed'; Stage = 'Create parent'; PotentialResourceIds = @('parent') }
            throw $e
        }
        [pscustomobject]@{ Status = 'PreviewProvisioningSucceeded' }
    }
    function script:Invoke-AzureLocalVmNicReplacement {
        param($Configuration,$SourceNetworkAdapterId,$LogicalNetworkId,$NetworkInterfaceName,$PrivateIPAddress,$BackupPath,
            $ConnectivityTestHost,[switch]$ReuseAttachedNetworkInterface,[switch]$ConvertDhcpToStatic,$OwnerNodeSession,$GuestCredential,
            [switch]$Execute,[switch]$EnableUnsupportedLabPreview,[switch]$AcceptNetworkInterruption,$Confirm,$TimeoutSeconds,$PollSeconds)
        if (-not $Execute) {
            return & $script:OriginalNicCommand -Configuration $Configuration -SourceNetworkAdapterId $SourceNetworkAdapterId `
                -LogicalNetworkId $LogicalNetworkId -NetworkInterfaceName $NetworkInterfaceName -PrivateIPAddress $PrivateIPAddress `
                -BackupPath $BackupPath -ConnectivityTestHost $ConnectivityTestHost -ReuseAttachedNetworkInterface:$ReuseAttachedNetworkInterface `
                -ConvertDhcpToStatic:$ConvertDhcpToStatic
        }
        $script:S.Events.Add('NicReplacement')
        $script:S.NicConfirm = $Confirm
        $script:S.NicReuse = $ReuseAttachedNetworkInterface
        $script:S.NicSource = $SourceNetworkAdapterId
        $script:S.NicNetwork = $LogicalNetworkId
        if (-not $EnableUnsupportedLabPreview -or -not $AcceptNetworkInterruption -or -not $ConvertDhcpToStatic -or
            $PrivateIPAddress -ne '192.0.2.30' -or $NetworkInterfaceName -ne 'replacement-nic') { throw 'NIC arguments or consent lost.' }
        if ($script:S.Scenario -eq 'NicFailure') {
            $e = [InvalidOperationException]::new('Mock NIC failed after cutover.')
            $e.Data['NicReplacementReport'] = @{ Status = 'Failed'; GuestCutoverAttempted = $true; OriginalRemoved = $false }
            throw $e
        }
        if ($script:S.Scenario -eq 'RemovalDeclined') {
            return [pscustomobject]@{ Status = 'CutoverVerifiedOriginalRetained'; OriginalRemoved = $false }
        }
        [pscustomobject]@{ Status = 'PreviewNicReplacementSucceeded'; OriginalRemoved = $true; ConnectivityVerified = $true }
    }
    function script:Invoke-AzureLocalVmCompletion {
        param($Configuration,$OwnerNodeSession,$Execute,$EnableUnsupportedLabPreview,$Confirm,$TimeoutSeconds,$PollSeconds,$GuestCredential,[switch]$EnableGuestManagement)
        $script:S.Events.Add('GuestManagement')
        if (-not $EnableGuestManagement) { throw 'Expected guest management only.' }
        if ($script:S.ReportPath) {
            $e = [IO.IOException]::new('Sharing check')
            $locked = $false
            try { $file = [IO.File]::Open($script:S.ReportPath, 'Open', 'Read', 'ReadWrite'); $file.Dispose() } catch [IO.IOException] { $locked = $true }
            if (-not $locked) { throw $e }
        }
        if ($script:S.Scenario -eq 'GuestFailure') {
            $e = [InvalidOperationException]::new('Mock guest connection failed.')
            $e.Data['CompletionReport'] = @{ Status = 'Failed'; GuestArcConnected = $false }
            throw $e
        }
        [pscustomobject]@{ Status = 'PreviewCompletionSucceeded'; GuestArcConnected = $true }
    }
}
function Reset-Fixture([string]$Scenario = '') {
    $c = @{}
    ($example | ConvertFrom-Json).PSObject.Properties | ForEach-Object { $c[$_.Name] = $_.Value }
    & $module { param($scenario) $script:S = @{ Scenario = $scenario; Events = [Collections.Generic.List[string]]::new(); NicConfirm = $null; NicReuse = $null; ReportPath = $null } } $Scenario
    $script:parameters = @{
        Configuration = $c; ReplaceExistingNetworkAdapter = $true
        SourceNetworkAdapterId = "Microsoft:$($c.ExpectedVmId)\77777777-7777-7777-7777-777777777777"
        LogicalNetworkId = "/subscriptions/$($c.SubscriptionId)/resourceGroups/lab-infra-rg/providers/Microsoft.AzureStackHCI/logicalNetworks/lnet1"
        NetworkInterfaceName = 'replacement-nic'; PrivateIPAddress = '192.0.2.30'
        BackupPath = Join-Path $directory ([guid]::NewGuid().ToString('N') + '.backup.json')
        ConvertDhcpToStatic = $true
    }
}
function Events { & $module { $script:S.Events.ToArray() } }
function Execute-Fixture {
    Invoke-AzureLocalVmSetup @script:parameters -GuestCredential $credential -Execute -EnableUnsupportedLabPreview -AcceptNetworkInterruption -Confirm:$false
}
try {
    Test-Case 'Replacement plan explicitly orders registration replacement and guest management without access' {
        Reset-Fixture
        $r = Invoke-AzureLocalVmSetup @parameters
        Assert ($r.NetworkMode -eq 'ReplaceWithAzureManagedNic' -and $r.NicReplacement.NetworkInterfaceId -like '*/replacement-nic' -and
            $r.ExecutionOrder.Count -eq 3 -and @(Events).Count -eq 0) 'Wrong plan or live access.'
        Assert (-not (Test-Path $parameters.BackupPath)) 'Plan wrote backup.'
    }
    Test-Case 'Replacement WhatIf does not create a report or touch infrastructure' {
        Reset-Fixture
        $path = Join-Path $directory 'whatif.json'
        $r = Invoke-AzureLocalVmSetup @parameters -ReportPath $path -Execute -EnableUnsupportedLabPreview -AcceptNetworkInterruption -WhatIf
        Assert ($r.Status -eq 'NotExecuted' -and @(Events).Count -eq 0 -and -not (Test-Path $path)) 'WhatIf performed work.'
    }
    Test-Case 'Network-interruption consent is required before infrastructure access' {
        Reset-Fixture
        $null = Assert-Throws { Invoke-AzureLocalVmSetup @parameters -Execute -EnableUnsupportedLabPreview -Confirm:$false } 'AcceptNetworkInterruption'
        Assert (@(Events).Count -eq 0) 'Consent failure contacted infrastructure.'
    }
    Test-Case 'Source pool preflight runs before registration and stops invalid input' {
        Reset-Fixture PreflightFailure
        $null = Assert-Throws { Execute-Fixture } 'preflight failed'
        Assert ('Registration' -notin @(Events) -and 'NicReplacement' -notin @(Events)) 'Preflight failure mutated resources.'
    }
    Test-Case 'Full execution orders all phases and forwards explicit consent and target options' {
        Reset-Fixture
        $r = Execute-Fixture
        Assert ($r.Status -eq 'PreviewSetupSucceeded' -and $r.NicReplacement.OriginalRemoved -and $r.Completion.GuestArcConnected -and
            ((@(Events) | Select-Object -Last 3) -join ',') -eq 'Registration,NicReplacement,GuestManagement') 'Wrong phase order.'
        Assert ((& $module { $script:S.NicConfirm }) -eq $false) 'Explicit noninteractive confirmation not forwarded.'
    }
    Test-Case 'Default replacement execution retains separate original-removal confirmation' {
        Reset-Fixture
        & $module {
            param($parameters,$credential)
            $ConfirmPreference = 'None'
            $null = Invoke-AzureLocalVmSetup @parameters -GuestCredential $credential -Execute -EnableUnsupportedLabPreview -AcceptNetworkInterruption
        } $parameters $credential
        Assert ((& $module { $script:S.NicConfirm }) -eq $true) 'Original removal confirmation was suppressed by orchestration.'
    }
    foreach ($scenario in @('RegistrationFailure','NicFailure','RemovalDeclined','GuestFailure')) {
        Test-Case "Partial $scenario retains completed phases and never continues blindly" {
            Reset-Fixture $scenario
            $e = Assert-Throws { Execute-Fixture } 'failed|not completed'
            $r = $e.Exception.Data['SetupReport']
            Assert ($r.Status -eq 'Failed') 'Failure reported success.'
            if ($scenario -eq 'RegistrationFailure') { Assert ('NicReplacement' -notin @(Events)) 'Registration failure changed NIC.' }
            else { Assert ($r.Registration.Status -eq 'PreviewProvisioningSucceeded') 'Successful registration lost.' }
            if ($scenario -in @('NicFailure','RemovalDeclined')) { Assert ('GuestManagement' -notin @(Events)) 'NIC failure enabled guest management.' }
            if ($scenario -eq 'NicFailure') { Assert ($r.NicReplacement.GuestCutoverAttempted) 'Partial NIC report lost.' }
            if ($scenario -eq 'GuestFailure') { Assert ($r.NicReplacement.OriginalRemoved) 'Completed replacement lost.' }
        }
    }
    Test-Case 'Explicit registered resume skips registration and permits only attached NIC reuse' {
        Reset-Fixture
        $parameters.RegistrationAlreadyComplete = $true
        $parameters.ReuseAttachedNetworkInterface = $true
        $r = Execute-Fixture
        Assert ($null -eq $r.Registration -and 'Registration' -notin @(Events) -and (& $module { $script:S.NicReuse })) 'Resume did not skip registration.'
        $parameters.RegistrationAlreadyComplete = $false
        $null = Assert-Throws { Invoke-AzureLocalVmSetup @parameters } 'requires RegistrationAlreadyComplete'
    }
    Test-Case 'NIC options cannot be silently ignored in preservation mode' {
        Reset-Fixture
        $parameters.ReplaceExistingNetworkAdapter = $false
        $null = Assert-Throws { Invoke-AzureLocalVmSetup @parameters } 'require.*ReplaceExistingNetworkAdapter'
    }
    Test-Case 'Replacement requires a logical network and backup while source selection can be automatic' {
        foreach ($key in @('LogicalNetworkId','BackupPath')) {
            Reset-Fixture
            $parameters.Configuration.Remove('LogicalNetworkId')
            $parameters.Remove($key)
            $null = Assert-Throws { Invoke-AzureLocalVmSetup @parameters } 'Specify LogicalNetworkId|requires BackupPath'
        }
    }
    Test-Case 'Configuration supplies the exact network ID independently of the VM resource group' {
        Reset-Fixture
        $parameters.Remove('LogicalNetworkId')
        $expected = "/subscriptions/$($parameters.Configuration.SubscriptionId)/resourceGroups/Dejima0/providers/Microsoft.AzureStackHCI/logicalNetworks/selected-network"
        $parameters.Configuration.LogicalNetworkId = $expected
        $r = Invoke-AzureLocalVmSetup @parameters
        Assert ($r.NicReplacement.LogicalNetworkId -ceq $expected -and
            $r.NicReplacement.NetworkInterfaceId -like '*/resourceGroups/lab-vm-rg/*' -and @(Events).Count -eq 0) 'Network ID inferred or VM target resource group changed.'
    }
    Test-Case 'Configuration network ID reaches both preflight and replacement execution' {
        Reset-Fixture
        $parameters.Remove('LogicalNetworkId')
        $expected = "/subscriptions/$($parameters.Configuration.SubscriptionId)/resourceGroups/Dejima0/providers/Microsoft.AzureStackHCI/logicalNetworks/selected-network"
        $parameters.Configuration.LogicalNetworkId = $expected
        $r = Execute-Fixture
        Assert ($r.Status -eq 'PreviewSetupSucceeded' -and (& $module { $script:S.PreflightNetwork }) -ceq $expected -and
            (& $module { $script:S.NicNetwork }) -ceq $expected) 'Execution lost the configured network ID.'
    }
    Test-Case 'Stale network argument conflicting with configuration fails before any access' {
        Reset-Fixture
        $parameters.LogicalNetworkId = $parameters.LogicalNetworkId.Replace('/lnet1', '/stale-network')
        $null = Assert-Throws { Execute-Fixture } 'LogicalNetworkId argument differs from configuration'
        Assert (@(Events).Count -eq 0) 'Conflicting network settings contacted infrastructure.'
    }
    Test-Case 'Legacy configurations can still specify the network explicitly' {
        Reset-Fixture
        $parameters.Configuration.Remove('LogicalNetworkId')
        $r = Invoke-AzureLocalVmSetup @parameters
        Assert ($r.NicReplacement.LogicalNetworkId -ceq $parameters.LogicalNetworkId -and @(Events).Count -eq 0) 'Legacy explicit network no longer supported.'
    }
    Test-Case 'Configured network alone never opts into replacement or changes guest-only resume' {
        Reset-Fixture
        $r = Invoke-AzureLocalVmSetup -Configuration $parameters.Configuration -RegistrationAlreadyComplete
        Assert ($r.NetworkMode -eq 'PreserveExistingHyperV' -and $null -eq $r.NicReplacement -and
            ($r.Requests | ConvertTo-Json -Depth 20) -notmatch '/logicalNetworks/|/networkInterfaces/' -and @(Events).Count -eq 0) 'Configuration implicitly enabled network changes.'
    }
    Test-Case 'Configuration-only network WhatIf performs no discovery or report writes' {
        Reset-Fixture
        $parameters.Remove('LogicalNetworkId')
        $path = Join-Path $directory 'config-network-whatif.json'
        $r = Invoke-AzureLocalVmSetup @parameters -ReportPath $path -Execute -EnableUnsupportedLabPreview -AcceptNetworkInterruption -WhatIf
        Assert ($r.Status -eq 'NotExecuted' -and $r.NicReplacement.LogicalNetworkId -ceq $parameters.Configuration.LogicalNetworkId -and
            @(Events).Count -eq 0 -and -not (Test-Path $path)) 'Configuration-only WhatIf contacted infrastructure or wrote a report.'
    }
    Test-Case 'Automatic source plan performs no discovery or prompting' {
        Reset-Fixture
        $parameters.Remove('SourceNetworkAdapterId')
        $r = Invoke-AzureLocalVmSetup @parameters
        Assert ($r.NicReplacement.SourceSelection -eq 'AutoSingleAdapter' -and -not $r.NicReplacement.SourceNetworkAdapterId -and
            @(Events).Count -eq 0) 'Plan discovered a source NIC.'
    }
    Test-Case 'Unified automatic source is resolved before registration and forwarded as the exact ID' {
        Reset-Fixture
        $expected = $parameters.SourceNetworkAdapterId
        $parameters.Remove('SourceNetworkAdapterId')
        $r = Execute-Fixture
        Assert ($r.SourceSelection -eq 'AutoSingleAdapter' -and $r.SourceNetworkAdapterId -eq $expected -and
            (& $module { $script:S.NicSource }) -eq $expected -and
            ((@(Events) | Select-Object -Last 4) -join ',') -eq 'NicPreflight,Registration,NicReplacement,GuestManagement') 'Automatic source was lost or discovered after registration.'
    }
    Test-Case 'Ambiguous automatic source prevents registration and all later phases' {
        Reset-Fixture MultipleSources
        $parameters.Remove('SourceNetworkAdapterId')
        $null = Assert-Throws { Execute-Fixture } 'exactly one'
        Assert ('Registration' -notin @(Events) -and 'NicReplacement' -notin @(Events)) 'Ambiguous source mutated resources.'
    }
    Test-Case 'Report and original backup cannot use the same path' {
        Reset-Fixture
        $null = Assert-Throws { Invoke-AzureLocalVmSetup @parameters -ReportPath $parameters.BackupPath } 'different files'
        Assert (@(Events).Count -eq 0) 'Invalid paths contacted infrastructure.'
    }
    Test-Case 'Durable report persists phase results and excludes credentials' {
        Reset-Fixture
        $path = Join-Path $directory 'success.json'
        & $module { param($path) $script:S.ReportPath = $path } $path
        $r = Invoke-AzureLocalVmSetup @parameters -GuestCredential $credential -Execute -EnableUnsupportedLabPreview -AcceptNetworkInterruption -Confirm:$false -ReportPath $path
        $text = Get-Content -LiteralPath $path -Raw
        $saved = $text | ConvertFrom-Json
        Assert ($saved.Status -eq $r.Status -and $saved.NicReplacement.OriginalRemoved -and $saved.Completion.GuestArcConnected -and
            $text -notmatch 'offline-fixture-only|PSCredential|SecureString') 'Report incomplete or secret-bearing.'
        $before = $text
        $null = Assert-Throws {
            Invoke-AzureLocalVmSetup @parameters -GuestCredential $credential -Execute -EnableUnsupportedLabPreview -AcceptNetworkInterruption -Confirm:$false -ReportPath $path
        } 'exists'
        Assert ((Get-Content -LiteralPath $path -Raw) -ceq $before) 'Existing report overwritten.'
    }
    Test-Case 'Relative report paths follow the caller PowerShell location' {
        Reset-Fixture
        Push-Location $directory
        try {
            $r = Invoke-AzureLocalVmSetup @parameters -GuestCredential $credential -Execute -EnableUnsupportedLabPreview -AcceptNetworkInterruption -Confirm:$false -ReportPath '.\relative-report.json'
            Assert ($r.Status -eq 'PreviewSetupSucceeded' -and (Test-Path -LiteralPath '.\relative-report.json')) 'Report written outside caller location.'
        } finally { Pop-Location }
    }
    Test-Case 'Persisted failure report retains NIC partial state and completed registration' {
        Reset-Fixture NicFailure
        $path = Join-Path $directory 'failure.json'
        $null = Assert-Throws {
            Invoke-AzureLocalVmSetup @parameters -GuestCredential $credential -Execute -EnableUnsupportedLabPreview -AcceptNetworkInterruption -Confirm:$false -ReportPath $path
        } 'Mock NIC failed'
        $saved = Get-Content -LiteralPath $path -Raw | ConvertFrom-Json
        Assert ($saved.Stage -eq 'NIC replacement' -and $saved.Registration.Status -eq 'PreviewProvisioningSucceeded' -and
            $saved.NicReplacement.GuestCutoverAttempted) 'Failure checkpoint lost.'
    }
    Test-Case 'Explicit April selection propagates to every plan surface without fallback' {
        Reset-Fixture
        $parameters.Configuration.StackHciApiVersion = '2026-07-01-preview'
        $r = Invoke-AzureLocalVmSetup @parameters
        Assert ($r.ApiVersion -eq '2026-07-01-preview' -and $r.NicReplacement.ApiVersion -eq $r.ApiVersion -and
            @($r.Requests | Where-Object { ($_.PSObject.Properties['Uri'] -and $_.Uri -like '*Microsoft.AzureStackHCI*' -and $_.Uri -notlike '*2026-07-01-preview') -or
                ($_.PSObject.Properties['ApiVersion'] -and $_.ApiVersion -ne '2026-07-01-preview') }).Count -eq 0) 'Mixed API versions.'
        $parameters.Configuration.Remove('StackHciApiVersion')
        $july = Invoke-AzureLocalVmSetup @parameters
        Assert ($july.ApiVersion -eq '2026-04-01-preview') 'API version leaked from prior invocation.'
    }
    Test-Case 'Unknown and null API selections fail before any live access' {
        foreach ($version in @('2025-09-01-preview','2026-07-01-preview&x=y',$null,42)) {
            Reset-Fixture
            $parameters.Configuration.StackHciApiVersion = $version
            $null = Assert-Throws { Invoke-AzureLocalVmSetup @parameters } 'StackHciApiVersion'
            Assert (@(Events).Count -eq 0) 'Invalid API selection contacted infrastructure.'
        }
    }
    Test-Case 'Portable packaging includes exactly the whitelisted source files and no environment artifacts' {
        $path = Join-Path $directory 'toolkit.zip'
        Push-Location $directory
        try { $r = & (Join-Path $root 'tools\New-AzureLocalVmToolkit.ps1') -OutputPath '.\toolkit.zip' } finally { Pop-Location }
        Assert ($r.FileCount -eq 15 -and $r.SHA256.Length -eq 64) 'Wrong package shape.'
        $archive = [IO.Compression.ZipFile]::OpenRead($path)
        try {
            Assert ($archive.Entries.Count -eq 15 -and
                @($archive.Entries | Where-Object { $_.FullName -match 'registration\.lab|WS19|backup|report|\.pem$' }).Count -eq 0) 'Environment artifact packaged.'
            foreach ($entry in $archive.Entries) {
                Assert (Test-Path -LiteralPath (Join-Path $root $entry.FullName.Replace('/', '\')) -PathType Leaf) 'Unexpected ZIP entry.'
            }
        } finally { $archive.Dispose() }
    }
    Test-Case 'Packaging never overwrites an existing output file' {
        $path = Join-Path $directory 'existing.zip'
        [IO.File]::WriteAllText($path, 'existing')
        $null = Assert-Throws { & (Join-Path $root 'tools\New-AzureLocalVmToolkit.ps1') -OutputPath $path } 'exists'
        Assert ((Get-Content -LiteralPath $path -Raw) -ceq 'existing') 'Existing ZIP was overwritten.'
    }
    Test-Case 'Portable CLI accepts replacement options and produces an offline combined plan' {
        Reset-Fixture
        foreach ($automatic in @($false,$true)) {
            $cli = @{} + $parameters
            $cli.Remove('Configuration')
            if ($automatic) { $cli.Remove('SourceNetworkAdapterId') }
            $json = & (Join-Path $root 'tools\Invoke-AzureLocalVmSetup.ps1') -ConfigurationPath (Join-Path $root 'examples\registration.example.json') @cli
            $r = $json | ConvertFrom-Json
            Assert ($r.Status -eq 'PlanOnly' -and $r.NetworkMode -eq 'ReplaceWithAzureManagedNic' -and $r.NicReplacement.PrivateIPAddress -eq '192.0.2.30') 'CLI forwarding failed.'
            Assert ($r.NicReplacement.SourceSelection -eq $(if ($automatic) { 'AutoSingleAdapter' } else { 'ExplicitId' })) 'CLI source mode lost.'
        }
    }
    Test-Case 'Unified CLI reads the selected network from its JSON file without a separate argument' {
        Reset-Fixture
        $parameters.Configuration.LogicalNetworkId = "/subscriptions/$($parameters.Configuration.SubscriptionId)/resourceGroups/Dejima0/providers/Microsoft.AzureStackHCI/logicalNetworks/selected-network"
        $path = Join-Path $directory 'configured-network.json'
        $parameters.Configuration | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $path -Encoding UTF8
        $cli = @{} + $parameters
        $cli.Remove('Configuration')
        $cli.Remove('LogicalNetworkId')
        $json = & (Join-Path $root 'tools\Invoke-AzureLocalVmSetup.ps1') -ConfigurationPath $path @cli
        $r = $json | ConvertFrom-Json
        Assert ($r.NicReplacement.LogicalNetworkId -ceq $parameters.Configuration.LogicalNetworkId -and
            $json -notmatch 'logicalNetworks/lnet1') 'CLI used a hard-coded network instead of configuration.'
    }
} finally {
    $credential.Password.Dispose()
    Get-ChildItem -LiteralPath $directory -File | Remove-Item -Force
    Remove-Item -LiteralPath $directory
}
Write-Host "$passed portable setup tests passed (offline; no live Azure/Hyper-V/guest operations)."
