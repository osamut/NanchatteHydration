﻿#Requires -Version 5.1
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$root = Split-Path $PSScriptRoot
Import-Module (Join-Path $root 'tools\AzureLocalVmRegistration.psm1') -Force
$module = Get-Module AzureLocalVmRegistration
$example = Get-Content (Join-Path $root 'examples\registration.example.json') -Raw
$script:passed = 0

function Assert($Condition, [string]$Message) { if (-not $Condition) { throw $Message } }
function Test-Case([string]$Name, [scriptblock]$Body) {
    & $Body
    $script:passed++
    Write-Host "PASS $Name"
}
function Assert-Throws([scriptblock]$Body, [string]$Pattern) {
    $record = $null
    try { & $Body | Out-Null } catch { $record = $_ }
    Assert ($null -ne $record -and $record.Exception.Message -match $Pattern) "Expected failure: $Pattern."
    return $record
}
function New-Config {
    $parsed = $example | ConvertFrom-Json
    $c = @{}
    foreach ($property in $parsed.PSObject.Properties) { $c[$property.Name] = $property.Value }
    $c.LocalHost = $env:COMPUTERNAME
    return $c
}

& $module {
    $script:RealTransport = (Get-Command Invoke-LabArmRequest).ScriptBlock
    $script:RealWindowsTransport = (Get-Command Invoke-LabWindowsHttpRequest).ScriptBlock
    function script:Invoke-LabWindowsHttpRequest {
        param($Method, $Uri, $Body, $Token, $TimeoutSeconds, $IfMatch)
        Invoke-WebRequest -Uri $Uri -Method $Method -Authentication Bearer -Token $Token `
            -Headers $(if ($Method -eq 'PATCH') { @{ 'If-Match' = $IfMatch } } else { @{ 'If-None-Match' = '*' } }) `
            -Body ($Body | ConvertTo-Json -Depth 12 -Compress) -MaximumRedirection 0 -Verbose $false -Debug $false
    }
    function script:Import-Module { param($Name, $MinimumVersion, $ErrorAction) }
    function script:Get-AzContext { param($ErrorAction) return $script:Fixture.Context }
    function script:Get-VM {
        param($ErrorAction)
        $script:Fixture.LocalReads++
        return [pscustomobject]@{ Name = $script:Fixture.Config.LocalVmName; Id = $script:Fixture.LocalVmId }
    }
    function script:Get-Cluster {
        param($ErrorAction)
        return [pscustomobject]@{ Name = 'lab-cluster'; Id = $script:Fixture.LocalClusterId }
    }
    function script:Wait-LabDelay {
        param($Seconds)
        $script:Fixture.Delays.Add($Seconds)
        if (($script:Fixture.Scenario -eq 'Timeout' -and $script:Fixture.VmCreated) -or
            $script:Fixture.Scenario -eq 'ParentMissingPrincipal') { Start-Sleep -Milliseconds 1100 }
    }
    function script:Response($Code, $Body, $Headers = @{}) {
        return [pscustomobject]@{ StatusCode = $Code; Body = $Body; Headers = $Headers }
    }
    function script:Parent-Body {
        return @{
            id = $script:Fixture.Plan.MachineId; kind = 'HCI'; location = 'japaneast'
            identity = @{ type = 'SystemAssigned'; principalId = $(if ($script:Fixture.Scenario -eq 'ParentMissingPrincipal') { $null } else { '44444444-4444-4444-4444-444444444444' }) }
            properties = @{ provisioningState = $(if ($script:Fixture.ParentDone) { 'Succeeded' } else { 'Accepted' }) }
        }
    }
    function script:Vm-Body {
        return @{
            id = $script:Fixture.Plan.VirtualMachineInstanceId
            extendedLocation = @{ name = $script:Fixture.Config.CustomLocationId }
            properties = @{
                localVmName = $script:Fixture.Config.LocalVmName
                hyperVVmId = $(if ($script:Fixture.Scenario -eq 'WrongFinalVm') { '99999999-9999-9999-9999-999999999999' } elseif ($script:Fixture.Scenario -eq 'MissingFinalVmId') { $null } else { $script:Fixture.Config.ExpectedVmId })
                provisioningState = $(if ($script:Fixture.VmDone) { 'Succeeded' } else { 'Accepted' })
            }
        }
    }
    function script:Invoke-LabArmRequest {
        param($Method, $Uri, $Body, $Context, $Subscription, $TimeoutSeconds)
        Assert-ArmUri $Uri $Subscription
        $f = $script:Fixture
        $c = $f.Config
        $f.Calls.Add([pscustomobject]@{ Method = $Method; Uri = $Uri; Body = $Body })
        if ($Method -eq 'PUT') {
            if ($Uri -eq $f.Plan.Requests[0].Uri) {
                if ($f.Scenario -eq 'ParentHttpFailure') { return Response 403 @{ error = @{ code = 'AuthorizationFailed'; message = 'No write permission' } } }
                $f.ParentCreated = $true
                if ($f.Scenario -eq 'NoHeaders') { return Response 201 (Parent-Body) }
                return Response 202 @{} @{ 'Azure-AsyncOperation' = "$script:Arm/subscriptions/$Subscription/operations/parent"; 'Retry-After' = '1' }
            }
            if ($f.Scenario -eq 'VmHttpFailure') { return Response 400 @{ error = @{ code = 'UnsupportedLocalVm'; message = 'Server validation rejected existing VM'; details = @(@{ code = 'NestedDetail' }) } } @{ 'x-ms-request-id' = 'request-123' } }
            if ($f.Scenario -eq 'PreconditionFailure') { return Response 412 @{ error = @{ code = 'PreconditionFailed'; message = 'Concurrent create' } } }
            $f.VmCreated = $true
            if ($f.Scenario -in @('NoHeaders', 'FinalPending')) { return Response 201 (Vm-Body) }
            if ($f.Scenario -eq 'ProviderOperation') {
                return Response 201 (Vm-Body) @{ 'Azure-AsyncOperation' = "$script:Arm/providers/Microsoft.AzureStackHCI/locations/japaneast/operationStatuses/mock%2Aoperation" }
            }
            if ($f.Scenario -eq 'EncodedOperation') {
                return Response 201 (Vm-Body) @{ 'Azure-AsyncOperation' = "$script:Arm/subscriptions/$Subscription/operations/mock%2Aoperation" }
            }
            if ($f.Scenario -eq 'OtherSubscriptionOperation') {
                return Response 201 (Vm-Body) @{ 'Azure-AsyncOperation' = "$script:Arm/subscriptions/99999999-9999-9999-9999-999999999999/operations/mock" }
            }
            if ($f.Scenario -eq 'InitialFailed') { return Response 201 @{ properties = @{ provisioningState = 'Failed' }; error = @{ code = 'ImmediateFailure' } } }
            if ($f.Scenario -eq 'Location') { return Response 202 @{} @{ Location = "$script:Arm/subscriptions/$Subscription/operations/vm" } }
            if ($f.Scenario -eq 'HostileAsync') { return Response 202 @{} @{ 'Azure-AsyncOperation' = 'https://example.test/steal-token' } }
            return Response 201 (Vm-Body) @{ 'Azure-AsyncOperation' = "$script:Arm/subscriptions/$Subscription/operations/vm" }
        }
        if ($Uri -like '*/operations/parent') { $f.ParentDone = $true; return Response 200 @{ status = 'Succeeded' } }
        if ($Uri -like '*/operations/vm') {
            if ($f.Scenario -eq 'AsyncFailure') { return Response 200 @{ status = 'Failed'; error = @{ code = 'VMRegistrationFailed'; message = 'Host rejected request' } } }
            if ($f.Scenario -eq 'AsyncCanceled') { return Response 200 @{ status = 'Canceled'; error = @{ code = 'CanceledByServer' } } }
            if ($f.Scenario -eq 'PollHttpFailure') { return Response 403 @{ error = @{ code = 'CannotReadOperation' } } }
            if ($f.Scenario -eq 'Timeout') { return Response 200 @{ status = 'InProgress' } }
            $f.VmDone = $true
            if ($f.Scenario -eq 'Location') { return Response 204 @{} }
            return Response 200 @{ status = 'Succeeded' }
        }
        $groupId = "/subscriptions/$Subscription/resourceGroups/$($c.ResourceGroup)"
        if ($Uri -eq "$script:Arm${groupId}?api-version=2021-04-01") {
            return Response 200 @{ id = $groupId; location = 'japaneast' }
        }
        if ($Uri -like "*$($c.ClusterId)?api-version=*") {
            return Response 200 @{ id = $c.ClusterId; properties = @{ reportedProperties = @{
                clusterName = 'lab-cluster'; clusterId = '55555555-5555-5555-5555-555555555555'; nodes = @(@{ name = $c.LocalHost })
            } } }
        }
        if ($Uri -like "*$($c.CustomLocationId)?api-version=*") {
            return Response 200 @{ id = $c.CustomLocationId; location = 'japaneast'; properties = @{
                hostResourceId = $f.BridgeId; clusterExtensionIds = @($f.ExtensionId)
            } }
        }
        if ($Uri -like "*$($f.BridgeId)?api-version=*") {
            return Response 200 @{ id = $f.BridgeId; properties = @{
                status = 'Running'; provisioningState = 'Succeeded'; infrastructureConfig = @{ provider = 'HCI' }
            } }
        }
        if ($Uri -like "*$($f.ExtensionId)?api-version=*") {
            return Response 200 @{ id = $f.ExtensionId; properties = @{ configurationSettings = @{
                HCIClusterID = $(if ($f.Scenario -eq 'WrongClusterExtension') { '/wrong-cluster' } else { $c.ClusterId })
            } } }
        }
        foreach ($id in @($c.NetworkInterfaceIds) + @($c.DataDiskIds)) {
            if ($Uri -like "*${id}?api-version=*") {
                return Response 200 @{ id = $id; extendedLocation = @{ name = $(if ($f.Scenario -eq 'WrongReferenceLocation') { '/wrong-cl' } else { $c.CustomLocationId }) }; properties = @{ provisioningState = 'Succeeded' } }
            }
        }
        if ($Uri -like "*$($f.Plan.MachineId)?api-version=*") {
            if ($f.Scenario -eq 'ExistingParent') { return Response 200 (Parent-Body) }
            if ($f.Scenario -eq 'Race' -and $f.LocalReads -gt 1) { return Response 200 (Parent-Body) }
            if ($f.ParentCreated) {
                if ($f.Scenario -eq 'NoHeaders') { $f.ParentDone = $true }
                return Response 200 (Parent-Body)
            }
            return Response 404 @{ error = @{ code = 'ResourceNotFound' } }
        }
        if ($Uri -like "*$($f.Plan.VirtualMachineInstanceId)?api-version=*") {
            if ($f.Scenario -eq 'ExistingVm') { return Response 200 (Vm-Body) }
            if ($f.VmCreated) {
                if ($f.Scenario -in @('NoHeaders', 'ProviderOperation', 'EncodedOperation')) { $f.VmDone = $true }
                if ($f.Scenario -eq 'FinalPending') {
                    $f.VmReads++
                    if ($f.VmReads -ge 2) { $f.VmDone = $true }
                }
                return Response 200 (Vm-Body)
            }
            return Response 404 @{}
        }
        if ($Uri -like '*/providers/Microsoft.HybridCompute/machines?api-version=*') {
            if ($f.Scenario -eq 'ListForbidden') { return Response 403 @{ error = @{ code = 'AuthorizationFailed' } } }
            if ($f.Scenario -eq 'MalformedList') { return Response 200 @{} }
            if ($f.Scenario -eq 'HostileNextLink') { return Response 200 @{ value = @(); nextLink = 'https://example.test/next' } }
            if ($f.Scenario -eq 'ExistingProjection') {
                $other = "/subscriptions/$Subscription/resourceGroups/other-rg/providers/Microsoft.HybridCompute/machines/other-name"
                return Response 200 @{ value = @(@{ id = $other; kind = 'HCI' }) }
            }
            if ($f.Scenario -eq 'Pagination') { return Response 200 @{ value = @(); nextLink = "$script:Arm/subscriptions/$Subscription/next-page" } }
            return Response 200 @{ value = @() }
        }
        if ($Uri -like '*/next-page') { return Response 200 @{ value = @() } }
        if ($Uri -like '*/machines/other-name/providers/Microsoft.AzureStackHCI/virtualMachineInstances/default?api-version=*') {
            $body = Vm-Body
            $body.id = $Uri.Replace($script:Arm, '').Split('?')[0]
            return Response 200 $body
        }
        throw "Unexpected mocked request: $Method $Uri"
    }
}

function Reset-Fixture([string]$Scenario = 'Success', $Configuration = (New-Config)) {
    $plan = New-AzureLocalVmRegistrationPlan $Configuration
    & $module {
        param($Scenario, $Configuration, $Plan)
        $bridge = "/subscriptions/$($Configuration.SubscriptionId)/resourceGroups/lab-infra-rg/providers/Microsoft.ResourceConnector/appliances/lab-bridge"
        $script:Fixture = @{
            Config = $Configuration; Plan = $Plan; Scenario = $Scenario
            Context = [pscustomobject]@{ Tenant = @{ Id = $Configuration.TenantId }; Subscription = @{ Id = $Configuration.SubscriptionId }; Environment = @{ Name = 'AzureCloud' } }
            LocalVmId = $Configuration.ExpectedVmId; LocalClusterId = '55555555-5555-5555-5555-555555555555'
            BridgeId = $bridge; ExtensionId = "$bridge/providers/Microsoft.KubernetesConfiguration/extensions/vmoperator"
            ParentCreated = $false; VmCreated = $false; ParentDone = $false; VmDone = $false
            LocalReads = 0; VmReads = 0; Calls = [System.Collections.Generic.List[object]]::new(); Delays = [System.Collections.Generic.List[int]]::new()
        }
    } $Scenario $Configuration $plan
    return $Configuration
}
function Get-Fixture { & $module { return $script:Fixture } }
function Execute-Fixture([int]$Timeout = 5) {
    Invoke-AzureLocalVmRegistration -Configuration (Get-Fixture).Config -Execute -EnableUnsupportedLabPreview -Confirm:$false -TimeoutSeconds $Timeout -PollSeconds 1
}
function Assert-NoWrites {
    Assert (@((Get-Fixture).Calls | Where-Object Method -EQ 'PUT').Count -eq 0) 'Unexpected ARM write.'
}

Test-Case 'Plan request matches parent and extension resource contracts' {
    $c = Reset-Fixture
    $plan = Invoke-AzureLocalVmRegistration $c
    Assert ($plan.Status -eq 'PlanOnly' -and $plan.Requests.Count -eq 2) 'Wrong plan.'
    Assert ($plan.Requests[0].Body.kind -eq 'HCI' -and $plan.Requests[0].Body.identity.type -eq 'SystemAssigned') 'Wrong parent.'
    Assert ($plan.Requests[1].Uri -like '*/Microsoft.HybridCompute/machines/*/providers/Microsoft.AzureStackHCI/virtualMachineInstances/default?api-version=2026-04-01-preview') 'Wrong extension resource scope.'
    Assert ($plan.Requests[1].Body.properties.createFromLocal -eq $true) 'Missing adoption flag.'
    Assert (-not $plan.Requests[1].Body.properties.osProfile.windowsConfiguration.provisionVMAgent) 'Guest onboarding must be disabled.'
    Assert ((Get-Fixture).Calls.Count -eq 0) 'Plan connected to Azure.'
}
foreach ($case in @(
    @{ Name = 'numeric'; Value = 123; Pattern = 'Expected a JSON string' },
    @{ Name = 'array'; Value = @('WS19Test4'); Pattern = 'Expected a JSON string' },
    @{ Name = 'empty'; Value = ''; Pattern = 'empty or contains only whitespace' },
    @{ Name = 'whitespace'; Value = '   '; Pattern = 'empty or contains only whitespace' },
    @{ Name = 'tab'; Value = "WS19Test4`t"; Pattern = 'U\+0009 at zero-based index 9' },
    @{ Name = 'newline'; Value = "WS19Test4`n"; Pattern = 'U\+000A at zero-based index 9' },
    @{ Name = 'null character'; Value = ('WS19Test4' + [char]0); Pattern = 'U\+0000 at zero-based index 9' }
)) {
    Test-Case "LocalVmName $($case.Name) has actionable diagnostics before any connection" {
        $c = Reset-Fixture
        $c.LocalVmName = $case.Value
        $record = Assert-Throws {
            Invoke-AzureLocalVmRegistration $c -Execute -EnableUnsupportedLabPreview -Confirm:$false
        } ('Invalid text field: LocalVmName\. .*' + $case.Pattern)
        Assert ($record.Exception.Message -match 'save the file, and reload') 'Missing configuration recovery guidance.'
        Assert ($record.Exception.Message -notmatch 'WS19Test4') 'Diagnostic disclosed the configured name.'
        Assert ((Get-Fixture).Calls.Count -eq 0 -and (Get-Fixture).LocalReads -eq 0) 'Invalid name connected to infrastructure.'
    }
}
foreach ($name in @('WS19Test4', 'WS19Test4       ', ([string][char]0x691c + [char]0x8a3c + 'VM'))) {
    Test-Case "Valid LocalVmName is preserved exactly ($($name.Length) characters)" {
        $c = Reset-Fixture
        $c.LocalVmName = $name
        $plan = New-AzureLocalVmRegistrationPlan $c
        Assert ($plan.Requests[1].Body.properties.localVmName -ceq $name) 'VM name was silently normalized.'
        Assert ((Get-Fixture).Calls.Count -eq 0 -and (Get-Fixture).LocalReads -eq 0) 'Plan connected to infrastructure.'
    }
}
Test-Case 'Optional configuration network ID rejects invalid types and foreign resources without connections' {
    foreach ($value in @($null, 42, @('network'), '', ' ', "network`n",
        '/subscriptions/99999999-9999-9999-9999-999999999999/resourceGroups/other/providers/Microsoft.AzureStackHCI/logicalNetworks/net',
        '/subscriptions/22222222-2222-2222-2222-222222222222/resourceGroups/other/providers/Microsoft.AzureStackHCI/networkInterfaces/nic')) {
        $c = Reset-Fixture
        $c.LogicalNetworkId = $value
        $null = Assert-Throws { New-AzureLocalVmRegistrationPlan $c } 'LogicalNetworkId|Invalid resource ID'
        Assert ((Get-Fixture).Calls.Count -eq 0 -and (Get-Fixture).LocalReads -eq 0) 'Invalid network configuration contacted infrastructure.'
    }
}
Test-Case 'Linux and optional NIC/data disk references serialize without images or credentials' {
    $c = New-Config; $c.OsType = 'Linux'
    $c.NetworkInterfaceIds = @("/subscriptions/$($c.SubscriptionId)/resourceGroups/lab-vm-rg/providers/Microsoft.AzureStackHCI/networkInterfaces/nic1")
    $c.DataDiskIds = @("/subscriptions/$($c.SubscriptionId)/resourceGroups/lab-vm-rg/providers/Microsoft.AzureStackHCI/virtualHardDisks/data1")
    $plan = New-AzureLocalVmRegistrationPlan $c
    Assert ($plan.Requests[1].Body.properties.networkProfile.networkInterfaces.Count -eq 1) 'Wrong NIC shape.'
    Assert ($plan.Requests[1].Body.properties.storageProfile.dataDisks.Count -eq 1) 'Wrong disk shape.'
    Assert (-not $plan.Requests[1].Body.properties.osProfile.linuxConfiguration.provisionVMConfigAgent) 'Guest agent enabled.'
    Assert (($plan | ConvertTo-Json -Depth 15) -notmatch 'imageReference|adminPassword|Authorization') 'Unsafe plan properties.'
}
Test-Case 'Execute requires explicit unsupported lab opt-in' {
    $c = Reset-Fixture
    $null = Assert-Throws { Invoke-AzureLocalVmRegistration $c -Execute -Confirm:$false } 'requires'
    Assert-NoWrites
}
Test-Case 'WhatIf never authenticates or reads local infrastructure' {
    $c = Reset-Fixture
    $result = Invoke-AzureLocalVmRegistration $c -Execute -EnableUnsupportedLabPreview -WhatIf
    Assert ($result.Status -eq 'NotExecuted') 'WhatIf returned success.'
    Assert ((Get-Fixture).LocalReads -eq 0 -and (Get-Fixture).Calls.Count -eq 0) 'WhatIf connected.'
}
Test-Case 'Async accepted is polled and final UUID verified before success' {
    $null = Reset-Fixture
    $result = Execute-Fixture
    Assert ($result.Status -eq 'PreviewProvisioningSucceeded' -and -not $result.LifecycleOperationsTested) 'Wrong result.'
    Assert ($result.CreatedResourceIds.Count -eq 2 -and (Get-Fixture).VmDone) 'Accepted treated as completion.'
    Assert (@((Get-Fixture).Calls | Where-Object Method -EQ 'PUT').Count -eq 2) 'Unexpected writes.'
    Assert (1 -in (Get-Fixture).Delays) 'Retry-After ignored.'
}
foreach ($scenario in @('Location', 'NoHeaders', 'Pagination', 'FinalPending', 'ProviderOperation', 'EncodedOperation')) {
    Test-Case "Provisioning supports $scenario" {
        $null = Reset-Fixture $scenario
        Assert ((Execute-Fixture).Status -eq 'PreviewProvisioningSucceeded') 'Provisioning did not complete.'
        if ($scenario -eq 'FinalPending') { Assert ((Get-Fixture).VmReads -ge 2) 'Final Accepted treated as success.' }
        if ($scenario -in @('ProviderOperation', 'EncodedOperation')) {
            Assert (@((Get-Fixture).Calls | Where-Object {$_.Uri -match 'mock%2Aoperation'}).Count -eq 0) 'Unrecognized operation URL followed.'
        }
    }
}
foreach ($change in @('Tenant', 'Subscription', 'Cloud')) {
    Test-Case "Context $change mismatch refuses writes" {
        $null = Reset-Fixture
        $f = Get-Fixture
        if ($change -eq 'Tenant') { $f.Context.Tenant.Id = 'wrong' }
        if ($change -eq 'Subscription') { $f.Context.Subscription.Id = 'wrong' }
        if ($change -eq 'Cloud') { $f.Context.Environment.Name = 'AzureUSGovernment' }
        $null = Assert-Throws { Execute-Fixture } 'context'
        Assert-NoWrites
    }
}
Test-Case 'Local name/UUID and cluster identity cannot be substituted' {
    $null = Reset-Fixture; (Get-Fixture).LocalVmId = '99999999-9999-9999-9999-999999999999'
    $null = Assert-Throws { Execute-Fixture } 'UUID mismatch'; Assert-NoWrites
    $null = Reset-Fixture; (Get-Fixture).LocalClusterId = '99999999-9999-9999-9999-999999999999'
    $null = Assert-Throws { Execute-Fixture } 'cluster identity'; Assert-NoWrites
}
foreach ($scenario in @('ExistingParent', 'ExistingVm', 'ExistingProjection', 'Race', 'ListForbidden', 'WrongClusterExtension', 'MalformedList')) {
    Test-Case "Preflight $scenario refuses writes" {
        $null = Reset-Fixture $scenario
        $null = Assert-Throws { Execute-Fixture } 'already|overwrite|403|extensions|incomplete'
        Assert-NoWrites
    }
}
Test-Case 'Referenced NIC must belong to custom location' {
    $c = New-Config
    $c.NetworkInterfaceIds = @("/subscriptions/$($c.SubscriptionId)/resourceGroups/lab-vm-rg/providers/Microsoft.AzureStackHCI/networkInterfaces/nic1")
    $null = Reset-Fixture 'WrongReferenceLocation' $c
    $null = Assert-Throws { Execute-Fixture } 'Referenced NIC'; Assert-NoWrites
}
foreach ($scenario in @('VmHttpFailure', 'PreconditionFailure', 'AsyncFailure', 'AsyncCanceled', 'InitialFailed', 'PollHttpFailure', 'WrongFinalVm', 'MissingFinalVmId', 'HostileAsync', 'OtherSubscriptionOperation', 'HostileNextLink', 'ParentHttpFailure')) {
    Test-Case "Failure $scenario retains diagnostics without rollback" {
        $null = Reset-Fixture $scenario
        $record = Assert-Throws { Execute-Fixture } 'Registration failed'
        $report = $record.Exception.Data['RegistrationReport']
        Assert ($report.Status -eq 'Failed') 'Missing failure report.'
        Assert (@((Get-Fixture).Calls | Where-Object { $_.Method -notin @('GET', 'PUT') }).Count -eq 0) 'Rollback or power operation.'
        if ($scenario -eq 'VmHttpFailure') {
            Assert ($report.ConfirmedResourceIds.Count -eq 1 -and $report.PotentialResourceIds.Count -eq 2) 'Missing partial resources.'
            Assert ($report.ArmError.code -eq 'UnsupportedLocalVm' -and $report.RequestId -eq 'request-123') 'Server error lost.'
        }
    }
}
Test-Case 'Timeout is failure, not accepted success' {
    $null = Reset-Fixture 'Timeout'
    $record = Assert-Throws { Execute-Fixture 1 } 'Timeout'
    Assert ($record.Exception.Data['RegistrationReport'].PotentialResourceIds.Count -eq 2) 'Missing in-flight resources.'
    Assert ($record.Exception.Data['RegistrationReport'].OperationUri -like 'https://management.azure.com/*/operations/vm') 'Missing operation tracking URL.'
}
Test-Case 'Parent Succeeded without principal identity cannot proceed to VM creation' {
    $null = Reset-Fixture 'ParentMissingPrincipal'
    $record = Assert-Throws { Execute-Fixture 1 } 'Timeout'
    Assert ($record.Exception.Data['RegistrationReport'].ConfirmedResourceIds.Count -eq 0) 'Incomplete parent accepted.'
    Assert (@((Get-Fixture).Calls | Where-Object Method -EQ 'PUT').Count -eq 1) 'VM was created without a ready parent identity.'
}
Test-Case 'A different owner node refuses local reads and writes' {
    $c = New-Config
    $c.LocalHost = if ($env:COMPUTERNAME -eq 'TESTNODE1') { 'TESTNODE2' } else { 'TESTNODE1' }
    $null = Reset-Fixture 'Success' $c
    $null = Assert-Throws { Execute-Fixture } 'owner node'
    Assert-NoWrites
    Assert ((Get-Fixture).LocalReads -eq 0) 'Wrong node inspected a VM.'
}
Test-Case 'Explicit April API is used for registration writes and polling without changing the parent API' {
    $c = New-Config
    $c.StackHciApiVersion = '2026-07-01-preview'
    $null = Reset-Fixture -Configuration $c
    $r = Execute-Fixture
    $calls = @((Get-Fixture).Calls)
    Assert ($r.Status -eq 'PreviewProvisioningSucceeded' -and
        @($calls | Where-Object { $_.Uri -match 'Microsoft.AzureStackHCI/(virtualMachineInstances|networkInterfaces|logicalNetworks|virtualHardDisks)' -and
            $_.Uri -notlike '*api-version=2026-07-01-preview' }).Count -eq 0 -and
        @($calls | Where-Object { $_.Method -eq 'PUT' -and $_.Uri -like '*api-version=2025-01-13' }).Count -eq 1) 'Mixed API versions.'
}
Test-Case 'Omitted optional API selection restores July rather than leaking the previous selection' {
    $c = New-Config
    $c.Remove('StackHciApiVersion')
    $plan = New-AzureLocalVmRegistrationPlan $c
    Assert ($plan.ApiVersion -eq '2026-04-01-preview') 'Default API did not reset.'
}
Test-Case 'Failed April request never retries another API version' {
    $c = New-Config
    $c.StackHciApiVersion = '2026-07-01-preview'
    $null = Reset-Fixture ParentHttpFailure $c
    $null = Assert-Throws { Execute-Fixture } 'AuthorizationFailed|403'
    Assert (@((Get-Fixture).Calls | Where-Object Uri -LIKE '*2026-04-01-preview*').Count -eq 0) 'API fallback attempted.'
}
Test-Case 'Unknown fields, secrets, cross-subscription and duplicate IDs refused' {
    $c = New-Config; $c.Password = 'DO-NOT-LOG'
    $null = Assert-Throws { New-AzureLocalVmRegistrationPlan $c } 'Unknown configuration'
    $c = New-Config; $c.CustomLocationId = $c.CustomLocationId.Replace($c.SubscriptionId, '99999999-9999-9999-9999-999999999999')
    $null = Assert-Throws { New-AzureLocalVmRegistrationPlan $c } 'subscription'
    $c = New-Config; $c.ExpectedVmId = '00000000-0000-0000-0000-000000000000'
    $null = Assert-Throws { New-AzureLocalVmRegistrationPlan $c } 'GUID'
    $c = New-Config; $c.LocalVmName = 'VM*'
    $null = Assert-Throws { New-AzureLocalVmRegistrationPlan $c } 'literal'
    $c = New-Config
    $nicId = "/subscriptions/$($c.SubscriptionId)/resourceGroups/lab-vm-rg/providers/Microsoft.AzureStackHCI/networkInterfaces/nic1"
    $c.NetworkInterfaceIds = @($nicId, $nicId.ToUpperInvariant())
    $null = Assert-Throws { New-AzureLocalVmRegistrationPlan $c } 'Duplicate'
}
Test-Case 'ARM URL guards reject token exfiltration and other subscriptions' {
    & $module {
        foreach ($uri in @('http://management.azure.com/subscriptions/x/test', 'https://management.azure.com.evil.test/subscriptions/x/test',
                'https://management.azure.com/subscriptions/other/test', 'https://management.azure.com/subscriptions/x/%2e%2e/test',
                'https://user@management.azure.com/subscriptions/x/test')) {
            $caught = $false
            try { Assert-ArmUri $uri 'x' } catch { $caught = $true }
            if (-not $caught) { throw "URL guard accepted $uri." }
        }
    }
}
Test-Case 'Transport keeps token secure, disables redirects and sends create-only header' {
    & $module {
        function script:Get-AzAccessToken {
            param($ResourceUrl, $TenantId, $DefaultProfile, [switch]$AsSecureString, $ErrorAction)
            return [pscustomobject]@{ TenantId = $TenantId; Token = (ConvertTo-SecureString 'mock-token' -AsPlainText -Force) }
        }
        function script:Invoke-WebRequest {
            param($Uri, $Method, $Authentication, $Token, $SkipHttpErrorCheck, $MaximumRedirection, $MaximumRetryCount,
                $ConnectionTimeoutSeconds, $OperationTimeoutSeconds, $ErrorAction, $Verbose, $Debug, $Headers, $Body, $ContentType)
            if ($Token -isnot [securestring] -or $MaximumRedirection -ne 0 -or $Headers['If-None-Match'] -ne '*' -or $Verbose -or $Debug) { throw 'Unsafe transport.' }
            return [pscustomobject]@{ StatusCode = 201; Headers = @{}; Content = '{"properties":{"provisioningState":"Accepted"}}' }
        }
        $request = $script:Fixture.Plan.Requests[0]
        $response = & $script:RealTransport PUT $request.Uri $request.Body $script:Fixture.Context $script:Fixture.Config.SubscriptionId
        if ($response.StatusCode -ne 201) { throw 'Transport response not parsed.' }
        function script:Get-AzAccessToken {
            param($ResourceUrl, $TenantId, $DefaultProfile, [switch]$AsSecureString, $ErrorAction)
            return [pscustomobject]@{ TenantId = $TenantId; Token = 'plaintext-token-must-be-rejected' }
        }
        $caught = $false
        try { & $script:RealTransport PUT $request.Uri $request.Body $script:Fixture.Context $script:Fixture.Config.SubscriptionId | Out-Null }
        catch { $caught = $_.Exception.Message -match 'token type' }
        if (-not $caught) { throw 'Plaintext token was accepted.' }
        function script:Get-AzAccessToken {
            param($ResourceUrl, $TenantId, $DefaultProfile, [switch]$AsSecureString, $ErrorAction)
            return [pscustomobject]@{ TenantId = 'wrong-tenant'; Token = (ConvertTo-SecureString 'mock-token' -AsPlainText -Force) }
        }
        $caught = $false
        try { & $script:RealTransport PUT $request.Uri $request.Body $script:Fixture.Context $script:Fixture.Config.SubscriptionId | Out-Null }
        catch { $caught = $_.Exception.Message -match 'token type or tenant' }
        if (-not $caught) { throw 'Token tenant mismatch was accepted.' }
    }
}
Test-Case 'Non-JSON ARM errors preserve HTTP status and request ID' {
    & $module {
        function script:Get-AzAccessToken {
            param($ResourceUrl, $TenantId, $DefaultProfile, [switch]$AsSecureString, $ErrorAction)
            return [pscustomobject]@{ TenantId = $TenantId; Token = (ConvertTo-SecureString 'mock-token' -AsPlainText -Force) }
        }
        function script:Invoke-WebRequest {
            param($Uri, $Method, $Authentication, $Token, $SkipHttpErrorCheck, $MaximumRedirection, $MaximumRetryCount,
                $ConnectionTimeoutSeconds, $OperationTimeoutSeconds, $ErrorAction, $Verbose, $Debug, $Headers, $Body, $ContentType)
            return [pscustomobject]@{ StatusCode = 502; Headers = @{ 'x-ms-request-id' = 'non-json-request' }; Content = 'upstream unavailable' }
        }
        $record = $null
        $request = $script:Fixture.Plan.Requests[0]
        try { & $script:RealTransport PUT $request.Uri $request.Body $script:Fixture.Context $script:Fixture.Config.SubscriptionId | Out-Null }
        catch { $record = $_ }
        if ($null -eq $record -or $record.Exception.Message -notmatch 'HTTP 502.*upstream unavailable' -or
            $record.Exception.Data['RequestId'] -ne 'non-json-request') { throw 'Non-JSON diagnostic was lost.' }
    }
}
Test-Case 'Windows PowerShell transport sends bounded create-only request and disposes resources' {
    & $module {
        Add-Type -AssemblyName System.Net.Http
        $script:HttpRequestSeen = $null
        $script:HttpClientDisposed = $false
        function script:New-LabHttpClient {
            $client = [pscustomobject]@{ Timeout = [TimeSpan]::Zero }
            $client | Add-Member ScriptMethod SendAsync {
                param($request)
                $script:HttpRequestSeen = $request
                $validConditional = if ($request.Method.Method -eq 'PUT') {
                    ($request.Headers.IfNoneMatch | Select-Object -First 1).Tag -eq '*'
                } else {
                    ($request.Headers.IfMatch | Select-Object -First 1).Tag -eq '"etag-test"' -and
                        @($request.Headers.IfNoneMatch).Count -eq 0
                }
                if ($request.Headers.Authorization.Scheme -ne 'Bearer' -or
                    $request.Headers.Authorization.Parameter -ne 'mock-token' -or
                    -not $validConditional -or
                    $request.Content.ReadAsStringAsync().GetAwaiter().GetResult() -notmatch '"kind":"HCI"' -or
                    $this.Timeout.TotalSeconds -ne 3) { throw 'Unsafe Windows transport request.' }
                $response = [System.Net.Http.HttpResponseMessage]::new([System.Net.HttpStatusCode]::BadRequest)
                $response.Content = [System.Net.Http.StringContent]::new('{"error":{"code":"MockFailure"}}')
                $response.Headers.Add('x-ms-request-id', 'windows-request')
                return [System.Threading.Tasks.Task].GetMethod('FromResult').MakeGenericMethod(
                    [System.Net.Http.HttpResponseMessage]).Invoke($null, @($response))
            }
            $client | Add-Member ScriptMethod Dispose { $script:HttpClientDisposed = $true }
            return $client
        }
        $request = $script:Fixture.Plan.Requests[0]
        $token = ConvertTo-SecureString 'mock-token' -AsPlainText -Force
        $response = & $script:RealWindowsTransport PUT $request.Uri $request.Body $token 3
        if ($response.StatusCode -ne 400 -or $response.Headers['x-ms-request-id'] -ne 'windows-request' -or
            $response.Content -notmatch 'MockFailure' -or -not $script:HttpClientDisposed) { throw 'Windows response or cleanup failed.' }
        $response = & $script:RealWindowsTransport PATCH $request.Uri $request.Body $token 3 '"etag-test"'
        if ($response.StatusCode -ne 400) { throw 'Conditional Windows PATCH failed.' }
    }
}
Test-Case 'CLI default outputs plan JSON without authentication' {
    $json = & (Join-Path $root 'tools\Register-AzureLocalVm.ps1') -ConfigurationPath (Join-Path $root 'examples\registration.example.json')
    $plan = $json | ConvertFrom-Json
    Assert ($plan.Status -eq 'PlanOnly' -and $plan.Requests.Count -eq 2) 'CLI JSON contract failed.'
}
Test-Case 'Authenticated node identity must match configured host and VM UUID' {
    $null = Reset-Fixture
    & $module {
        $reader = (Get-Command Read-LabNodeIdentity).ScriptBlock
        try {
            function script:Read-LabNodeIdentity {
                param($Configuration, $OwnerNodeSession)
                [pscustomobject]@{
                    HostName = 'WRONG-NODE'
                    VMs = @([pscustomobject]@{ Name = $Configuration.LocalVmName; Id = $Configuration.ExpectedVmId })
                }
            }
            $caught = $false
            try { Assert-LocalVm $script:Fixture.Config $null }
            catch { $caught = $_.Exception.Message -match 'not the configured LocalHost' }
            if (-not $caught) { throw 'Wrong remote host accepted.' }
            function script:Read-LabNodeIdentity {
                param($Configuration, $OwnerNodeSession)
                [pscustomobject]@{
                    HostName = $Configuration.LocalHost
                    VMs = @([pscustomobject]@{ Name = $Configuration.LocalVmName; Id = 'wrong-uuid' })
                }
            }
            $caught = $false
            try { Assert-LocalVm $script:Fixture.Config $null }
            catch { $caught = $_.Exception.Message -match 'UUID mismatch' }
            if (-not $caught) { throw 'Wrong remote VM accepted.' }
        } finally {
            Set-Item -Path Function:script:Read-LabNodeIdentity -Value $reader
        }
    }
}
Test-Case 'PATCH requires current ETag and preserves update payload' {
    & $module {
        $request = $script:Fixture.Plan.Requests[0]
        foreach ($etag in @($null, '*')) {
            $caught = $false
            try { & $script:RealTransport PATCH $request.Uri @{ properties = @{ networkProfile = @{} } } $script:Fixture.Context $script:Fixture.Config.SubscriptionId 3 $etag | Out-Null }
            catch { $caught = $_.Exception.Message -match 'current resource ETag' }
            if (-not $caught) { throw 'Unconditional PATCH accepted.' }
        }
        function script:Get-AzAccessToken {
            param($ResourceUrl, $TenantId, $DefaultProfile, [switch]$AsSecureString, $ErrorAction)
            [pscustomobject]@{ TenantId = $TenantId; Token = (ConvertTo-SecureString 'mock-token' -AsPlainText -Force) }
        }
        function script:Invoke-WebRequest {
            param($Uri, $Method, $Authentication, $Token, $SkipHttpErrorCheck, $MaximumRedirection, $MaximumRetryCount,
                $ConnectionTimeoutSeconds, $OperationTimeoutSeconds, $ErrorAction, $Verbose, $Debug, $Headers, $Body, $ContentType)
            if ($Method -ne 'PATCH' -or $Headers['If-Match'] -ne '"etag-test"' -or
                $Headers.ContainsKey('If-None-Match') -or $Body -notmatch '"networkProfile"' -or
                $MaximumRedirection -ne 0) { throw 'Unsafe PATCH transport.' }
            [pscustomobject]@{StatusCode=202;Headers=@{};Content='{"properties":{"provisioningState":"Accepted"}}'}
        }
        $response = & $script:RealTransport PATCH $request.Uri @{ properties = @{ networkProfile = @{} } } $script:Fixture.Context $script:Fixture.Config.SubscriptionId 3 '"etag-test"'
        if ($response.StatusCode -ne 202) { throw 'PATCH response not returned.' }
    }
}
Test-Case 'VM name matching ignores case but still requires one UUID-matching VM' {
    $null = Reset-Fixture
    & $module {
        $original = (Get-Command Get-VM).ScriptBlock
        try {
            $config = $script:Fixture.Config
            $config.LocalVmName = $config.LocalVmName.ToLowerInvariant()
            $vmName = $script:Fixture.Config.LocalVmName.ToUpperInvariant()
            $vmId = $script:Fixture.LocalVmId
            $script:CaseVms = @([pscustomobject]@{ Name = $vmName; Id = $vmId })
            function script:Get-VM { param($ErrorAction) $script:CaseVms }
            Assert-LocalVm $config $null
            if ($config.LocalVmName -cne $vmName) { throw 'Configuration name was not normalized to the exact Hyper-V name.' }
            $script:CaseVms = @([pscustomobject]@{ Name = $vmName; Id = $vmId }, [pscustomobject]@{ Name = $config.LocalVmName; Id = '99999999-9999-9999-9999-999999999999' })
            $caught = $false
            try { Assert-LocalVm $config $null } catch { $caught = $_.Exception.Message -match 'ambiguous' }
            if (-not $caught) { throw 'Case-only duplicate VM names were accepted.' }
            $script:CaseVms = @([pscustomobject]@{ Name = $vmName; Id = '99999999-9999-9999-9999-999999999999' })
            $caught = $false
            try { Assert-LocalVm $config $null } catch { $caught = $_.Exception.Message -match 'UUID mismatch' }
            if (-not $caught) { throw 'Wrong UUID was accepted for a case-insensitive name match.' }
        } finally {
            Set-Item -Path Function:script:Get-VM -Value $original
        }
    }
}
Test-Case 'LocalHost is optional and node host comparison is case-insensitive' {
    $config = New-Config
    $config.Remove('LocalHost')
    $plan = New-AzureLocalVmRegistrationPlan $config
    Assert ($plan.LocalHost -match 'automatic') 'Plan did not report automatic owner discovery.'
    $null = Reset-Fixture 'Success' $config
    & $module {
        $original = (Get-Command Get-VM).ScriptBlock
        try { Assert-LocalVm $script:Fixture.Config $null } finally { Set-Item -Path Function:script:Get-VM -Value $original }
    }
    $withHost = New-Config
    $withHost.LocalHost = $env:COMPUTERNAME.ToLowerInvariant()
    $null = New-AzureLocalVmRegistrationPlan $withHost
    $withHost.LocalHost = 'bad host'
    $null = Assert-Throws { New-AzureLocalVmRegistrationPlan $withHost } 'LocalHost must be the short node name'
}
Test-Case 'Owner discovery follows the cluster owner and cleans up sessions' {
    $null = Reset-Fixture
    & $module {
        $script:Sessions = [System.Collections.Generic.List[object]]::new()
        $script:Removed = [System.Collections.Generic.List[object]]::new()
        function script:New-PSSession { param($ComputerName, $Credential, $ErrorAction)
            $s = [pscustomobject]@{ ComputerName = $ComputerName }; $script:Sessions.Add($s); $s }
        function script:Remove-PSSession { param($Session, $ErrorAction) $script:Removed.Add($Session) }
        function script:Invoke-Command { param($Session, $ScriptBlock, $ArgumentList, $ErrorAction)
            if ($script:Found -is [string]) { throw $script:Found }
            $script:Found }
        $config = @{} + $script:Fixture.Config
        $config.Remove('LocalHost')
        $script:Found = [pscustomobject]@{ Owner = 'node2'; Entry = 'NODE1' }
        $session = Connect-AzureLocalVmOwnerNode -Configuration $config
        if ($session.ComputerName -ne 'node2' -or $script:Sessions.Count -ne 2 -or $script:Removed.Count -ne 1 -or
            $script:Sessions[0].ComputerName -ne 'lab-cluster') { throw 'Remote owner was not selected and the entry session closed.' }
        $script:Sessions.Clear(); $script:Removed.Clear()
        $script:Found = [pscustomobject]@{ Owner = 'node1'; Entry = 'NODE1' }
        $session = Connect-AzureLocalVmOwnerNode -Configuration $config -ClusterName node1
        if ($script:Sessions.Count -ne 1 -or $script:Removed.Count -ne 0 -or $session -ne $script:Sessions[0]) { throw 'Local owner session was not reused.' }
        $script:Sessions.Clear(); $script:Removed.Clear()
        $script:Found = 'Expected exactly one clustered VM role for the UUID; found 0.'
        $caught = $false
        try { $null = Connect-AzureLocalVmOwnerNode -Configuration $config } catch { $caught = $_.Exception.Message -match 'exactly one' }
        if (-not $caught -or $script:Removed.Count -ne 1) { throw 'Missing clustered VM did not stop and clean up.' }
        $script:Sessions.Clear(); $script:Removed.Clear()
        $script:Found = [pscustomobject]@{ Owner = 'node2'; Entry = 'NODE1' }
        $stale = @{} + $config
        $stale.LocalHost = 'node1'
        $caught = $false
        try { $null = Connect-AzureLocalVmOwnerNode -Configuration $stale } catch { $caught = $_.Exception.Message -match 'Remove LocalHost' }
        if (-not $caught -or $script:Removed.Count -ne 2) { throw 'Stale LocalHost was not rejected with both sessions closed.' }
    }
}
Test-Case 'ExpectedVmId is optional and resolved from the unique VM name' {
    $config = New-Config
    $plan = New-AzureLocalVmRegistrationPlan (@{} + $config | ForEach-Object { $h = $_; $h.Remove('ExpectedVmId'); $h })
    Assert ($plan.ExpectedVmId -match 'automatic') 'Plan did not report automatic UUID resolution.'
    $null = Reset-Fixture 'Success' $config
    & $module {
        $c = @{} + $script:Fixture.Config
        $c.Remove('ExpectedVmId')
        Assert-LocalVm $c $null
        if ($c.ExpectedVmId -ine $script:Fixture.LocalVmId) { throw 'UUID was not resolved from the unique VM.' }
    }
}
Write-Host "$script:passed tests passed (mocked; no live Azure or Hyper-V operations)."
