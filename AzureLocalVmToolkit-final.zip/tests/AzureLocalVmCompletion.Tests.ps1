﻿#Requires -Version 5.1
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$root = Split-Path $PSScriptRoot
Import-Module (Join-Path $root 'tools\AzureLocalVmRegistration.psm1') -Force
$module = Get-Module AzureLocalVmRegistration
$example = Get-Content (Join-Path $root 'examples\registration.example.json') -Raw
$passed = 0
function Assert($Condition, [string]$Message) { if (-not $Condition) { throw $Message } }
function Test-Case([string]$Name, [scriptblock]$Body) { & $Body; $script:passed++; Write-Host "PASS $Name" }
function Assert-Throws([scriptblock]$Body, [string]$Pattern) {
    $record = $null
    try { & $Body | Out-Null } catch { $record = $_ }
    Assert ($null -ne $record -and $record.Exception.Message -match $Pattern) "Expected failure: $Pattern."
    return $record
}
function New-Config {
    $c = @{}
    $object = $example | ConvertFrom-Json
    foreach ($property in $object.PSObject.Properties) { $c[$property.Name] = $property.Value }
    $c.LocalHost = $env:COMPUTERNAME
    return $c
}
$credential = [pscredential]::new('Administrator', (ConvertTo-SecureString 'mock-secret-never-output' -AsPlainText -Force))
& $module {
    function script:Import-Module { param($Name, $MinimumVersion, $ErrorAction) }
    function script:Get-AzContext { param($ErrorAction) $script:F.Reads++; return $script:F.Context }
    function script:Read-LabNodeIdentity {
        param($Configuration, $OwnerNodeSession)
        $script:F.Reads++
        [pscustomobject]@{
            HostName = $Configuration.LocalHost
            VMs = @([pscustomobject]@{ Name = $Configuration.LocalVmName; Id = $script:F.LocalId; Generation = $script:F.Generation; State = $script:F.State })
        }
    }
    function script:Test-LabInfrastructure {
        param($Configuration, $Context, $OwnerNodeSession)
        Assert-LocalVm $Configuration $OwnerNodeSession
    }
    function script:Wait-LabDelay {
        param($Seconds)
        if ($script:F.Scenario -in @('ConfigTimeout', 'ArcTimeout')) { Start-Sleep -Milliseconds 1100 }
    }
    function script:Nic-Body {
        $f = $script:F
        $ips = @(@{ properties = @{
            subnet = @{ id = $(if ($f.Scenario -eq 'WrongNetwork') { '/wrong-network' } else { $f.LnetId }) }
            privateIPAddress = '192.0.2.20'; gateway = $(if ($f.Scenario -eq 'MissingGateway') { $null } else { '192.0.2.1' })
            prefixLength = '24'
        } })
        if ($f.Scenario -eq 'MultipleIPs') { $ips += $ips[0] }
        @{
            id = $f.Plan.NetworkInterfaceId
            extendedLocation = @{ name = $(if ($f.Scenario -eq 'WrongLocation') { '/wrong-location' } else { $f.Config.CustomLocationId }) }
            properties = @{ provisioningState = $(if ($f.Scenario -eq 'FailedNic') { 'Failed' } else { 'Succeeded' }); macAddress = '02:11:22:33:44:55'; ipConfigurations = $ips }
        }
    }
    function script:Invoke-LabArmRequest {
        param($Method, $Uri, $Body, $Context, $Subscription, $TimeoutSeconds, $IfMatch)
        Assert-ArmUri $Uri $Subscription
        $f = $script:F
        $f.Reads++
        $f.Calls.Add([pscustomobject]@{ Method = $Method; Uri = $Uri; Body = $Body; IfMatch = $IfMatch })
        $id = ([uri]$Uri).AbsolutePath
        $response = @{ StatusCode = 200; Headers = @{ ETag = '"etag-1"' }; Body = @{} }
        if ($Method -eq 'PUT') {
            if ($f.Scenario -eq 'NicHttpFailure') {
                $response.StatusCode = 400
                $response.Body = @{ error = @{ code = 'MacPoolRejected'; message = 'Lab server validation' } }
                return [pscustomobject]$response
            }
            $f.NicExists = $true
            $response.StatusCode = 201
            $response.Body = Nic-Body
            return [pscustomobject]$response
        }
        if ($Method -eq 'PATCH') {
            if ($IfMatch -ne '"etag-1"') { throw 'Missing expected ETag.' }
            if ($f.Scenario -eq 'PatchConflict') {
                $response.StatusCode = 412
                $response.Body = @{ error = @{ code = 'PreconditionFailed' } }
                return [pscustomobject]$response
            }
            if ($Body.properties.ContainsKey('networkProfile')) { $f.Refs = @($Body.properties.networkProfile.networkInterfaces | ForEach-Object { $_.id }) }
            if ($Body.properties.ContainsKey('osProfile')) {
                $flags = $Body.properties.osProfile.windowsConfiguration
                if ($flags.ContainsKey('provisionVMAgent')) { $f.ArcConnected = $f.Scenario -ne 'ArcTimeout' }
            }
            $response.StatusCode = 202
            $response.Body = @{ properties = @{ provisioningState = 'Accepted' } }
            return [pscustomobject]$response
        }
        if ($id -ieq $f.Plan.MachineId) {
            $response.Body = @{
                id = $id; kind = 'HCI'; location = $f.Config.Location
                identity = @{ type = 'SystemAssigned'; principalId = '44444444-4444-4444-4444-444444444444'; tenantId = $(if ($f.Scenario -eq 'WrongParent') { 'wrong-tenant' } else { $f.Config.TenantId }) }
                properties = @{ status = $(if ($f.ArcConnected) { 'Connected' } else { 'Disconnected' }); agentVersion = 'mock-version' }
            }
        } elseif ($id -ieq $f.Plan.VirtualMachineInstanceId) {
            $f.VmReads++
            if ($f.Scenario -eq 'EtagRace' -and $f.VmReads -ge 3) { $response.Headers.ETag = '"etag-2"' }
            $response.Body = @{
                id = $id; extendedLocation = @{ name = $f.Config.CustomLocationId }
                properties = @{
                    hyperVVmId = $(if ($f.Scenario -eq 'WrongVm') { '99999999-9999-9999-9999-999999999999' } else { $f.Config.ExpectedVmId })
                    localVmName = $f.Config.LocalVmName; provisioningState = 'Succeeded'
                    networkProfile = @{ networkInterfaces = @($f.Refs | ForEach-Object { @{ id = $_ } }) }
                    instanceView = @{ vmAgent = @{ statuses = @(@{ displayStatus = $(if ($f.Scenario -eq 'ConfigFailed') { 'Failed' } elseif ($f.ConfigConnected) { 'Connected' } else { 'Connecting' }) }) } }
                }
            }
        } elseif ($id -ieq $f.Plan.NetworkInterfaceId) {
            if ($f.NicExists) { $response.Body = Nic-Body } else { $response.StatusCode = 404; $response.Body = @{} }
        } elseif ($id -ieq $f.LnetId) {
            $response.Body = @{
                id = $id; extendedLocation = @{ name = $f.Config.CustomLocationId }
                properties = @{ provisioningState = 'Succeeded'; networkType = $(if ($f.Scenario -eq 'InfrastructureNetwork') { 'Infrastructure' } else { 'Workload' })
                    dhcpOptions = @{ dnsServers = @(if ($f.Scenario -ne 'MissingDns') { '192.0.2.53' }) } }
            }
        } else { throw "Unexpected mock request: $Method $Uri" }
        return [pscustomobject]$response
    }
    function script:Invoke-LabGuest {
        param($Configuration, $OwnerNodeSession, $Credential, $Command, $Arguments)
        $f = $script:F
        $f.GuestCalls.Add($Command.ToString())
        if ($Command.ToString() -match 'Win32_OperatingSystem') {
            if ($f.Scenario -eq 'GuestUnsupported') { throw 'Unsupported guest OS.' }
            return @{ Caption = 'Mock Windows'; Version = '10.0' }
        }
        if ($Command.ToString() -match 'Get-NetAdapter') {
            if ($f.Scenario -eq 'GuestNetworkFailure') { throw 'Guest NIC MAC absent.' }
            if ($Arguments[0] -ne '021122334455' -or $Arguments[1] -ne '192.0.2.20' -or $Arguments[2] -ne 24 -or $Arguments[3] -ne '192.0.2.1' -or
                $Arguments[4][0] -ne '192.0.2.53') { throw 'Guest configuration parameters incorrect.' }
            return @{ MacAddress = $Arguments[0]; IPv4 = $Arguments[1]; OtherAdaptersUnchanged = $true }
        }
        if ($Command.ToString() -match 'ISO') {
            if ($f.Scenario -eq 'InstallerFailure') { throw 'Official installer failed.' }
            $f.ConfigConnected = $f.Scenario -ne 'ConfigTimeout'
            return
        }
        if ($Command.ToString() -match 'himds') {
            if ($f.Scenario -eq 'HimdsFailure') { throw 'Connected Machine agent service not running.' }
            return @{ Name = 'himds'; Status = 'Running' }
        }
        throw 'Unexpected guest operation.'
    }
}
function Reset-Fixture([string]$Scenario = 'Success', [switch]$Attached) {
    $c = New-Config
    $lnet = "/subscriptions/$($c.SubscriptionId)/resourceGroups/lab-infra-rg/providers/Microsoft.AzureStackHCI/logicalNetworks/lnet1"
    $plan = New-AzureLocalVmCompletionPlan $c $lnet -AddNetworkInterface
    & $module {
        param($c, $lnet, $plan, $Scenario, $Attached)
        $refs = @("/subscriptions/$($c.SubscriptionId)/resourceGroups/old-rg/providers/Microsoft.AzureStackHCI/networkInterfaces/old-nic")
        if ($Attached) { $refs += $plan.NetworkInterfaceId }
        $script:F = @{
            Config = $c; LnetId = $lnet; Plan = $plan; Scenario = $Scenario
            Context = [pscustomobject]@{ Tenant = @{ Id = $c.TenantId }; Subscription = @{ Id = $c.SubscriptionId }; Environment = @{ Name = 'AzureCloud' } }
            Reads = 0; VmReads = 0; LocalId = $c.ExpectedVmId; Generation = 2; State = 'Running'
            RegistrationCalls = 0
            Refs = $refs; NicExists = [bool]$Attached; ConfigConnected = $false; ArcConnected = $false
            Calls = [System.Collections.Generic.List[object]]::new(); GuestCalls = [System.Collections.Generic.List[string]]::new()
        }
    } $c $lnet $plan $Scenario ([bool]$Attached)
}
function Get-Fixture { & $module { $script:F } }
function Execute-Fixture([switch]$GuestOnly, [switch]$ConfigureOnly, [int]$Timeout = 5) {
    $f = Get-Fixture
    Invoke-AzureLocalVmCompletion -Configuration $f.Config -LogicalNetworkId $f.LnetId -GuestCredential $credential `
        -AddNetworkInterface:(-not ($GuestOnly -or $ConfigureOnly)) -ConfigureGuestNetwork:(-not $GuestOnly) `
        -EnableGuestManagement:(-not $ConfigureOnly) -Execute -EnableUnsupportedLabPreview -Confirm:$false -TimeoutSeconds $Timeout -PollSeconds 1
}
function Assert-NoWrites { Assert (@((Get-Fixture).Calls | Where-Object Method -NE 'GET').Count -eq 0) 'Unexpected write.' }

Test-Case 'Plan is portable, does not read live resources and contains no credentials' {
    Reset-Fixture
    $f = Get-Fixture
    $plan = Invoke-AzureLocalVmCompletion $f.Config $f.LnetId -AddNetworkInterface -ConfigureGuestNetwork -EnableGuestManagement -GuestCredential $credential
    Assert ($plan.Status -eq 'PlanOnly' -and $plan.Requests.Count -eq 4 -and $f.Reads -eq 0) 'Wrong plan.'
    Assert ($plan.Requests[0].Body.properties.createFromLocal -eq $false -and $plan.NetworkInterfaceId.EndsWith('/lab-imported-vm-nic0')) 'Wrong NIC creation/naming.'
    Assert (($plan | ConvertTo-Json -Depth 15) -notmatch 'mock-secret|adminPassword|Credential|Authorization') 'Secret in plan.'
}
Test-Case 'WhatIf bypasses authentication, node/guest reads and writes' {
    Reset-Fixture; $f = Get-Fixture
    $plan = Invoke-AzureLocalVmCompletion $f.Config $f.LnetId -AddNetworkInterface -EnableGuestManagement -Execute -EnableUnsupportedLabPreview -WhatIf
    Assert ($plan.Status -eq 'NotExecuted' -and $f.Reads -eq 0 -and $f.GuestCalls.Count -eq 0) 'WhatIf contacted infrastructure.'
}
Test-Case 'Completion uses configured network for plan and execution without an argument' {
    Reset-Fixture
    $f = Get-Fixture
    $plan = Invoke-AzureLocalVmCompletion -Configuration $f.Config -AddNetworkInterface -ConfigureGuestNetwork
    Assert ($plan.LogicalNetworkId -ceq $f.Config.LogicalNetworkId -and
        $plan.Requests[0].Body.properties.ipConfigurations[0].properties.subnet.id -ceq $f.Config.LogicalNetworkId) 'Completion plan lost configured network.'
    $r = Invoke-AzureLocalVmCompletion -Configuration $f.Config -GuestCredential $credential `
        -AddNetworkInterface -ConfigureGuestNetwork -EnableGuestManagement -Execute -EnableUnsupportedLabPreview -Confirm:$false
    Assert ($r.Status -eq 'PreviewCompletionSucceeded' -and $r.GuestNetworkConfigured) 'Completion execution did not use the resolved network.'
}
Test-Case 'Completion refuses a stale network override before any infrastructure access' {
    Reset-Fixture
    $f = Get-Fixture
    $null = Assert-Throws {
        Invoke-AzureLocalVmCompletion -Configuration $f.Config -LogicalNetworkId ($f.LnetId + '-stale') -AddNetworkInterface
    } 'differs from configuration'
    Assert ($f.Reads -eq 0) 'Conflicting network settings contacted infrastructure.'
}
Test-Case 'Explicit lab opt-in and guest credentials required' {
    Reset-Fixture; $f = Get-Fixture
    $null = Assert-Throws { Invoke-AzureLocalVmCompletion $f.Config $f.LnetId -AddNetworkInterface -Execute -Confirm:$false } 'EnableUnsupportedLabPreview'
    $null = Assert-Throws { Invoke-AzureLocalVmCompletion $f.Config -EnableGuestManagement -Execute -EnableUnsupportedLabPreview -Confirm:$false } 'GuestCredential'
    Assert ($f.Reads -eq 0) 'Missing credentials performed reads.'
}
Test-Case 'NIC creation preserves old references and enables the existing guest Arc parent' {
    Reset-Fixture
    $result = Execute-Fixture
    $f = Get-Fixture
    Assert ($result.Status -eq 'PreviewCompletionSucceeded' -and $result.NicAttached -and $result.GuestNetworkConfigured -and $result.GuestArcConnected) 'Incomplete result.'
    Assert ($f.Refs.Count -eq 2 -and $f.Refs[0].EndsWith('/old-nic')) 'Old NIC reference lost.'
    Assert (@($f.Calls | Where-Object Method -EQ 'PUT').Count -eq 1 -and @($f.Calls | Where-Object Method -EQ 'PATCH').Count -eq 3) 'Wrong operation count.'
    Assert (@($f.Calls | Where-Object Method -NOTIN @('GET', 'PUT', 'PATCH')).Count -eq 0) 'Power/delete action performed.'
    Assert (($result | ConvertTo-Json -Depth 15) -notmatch 'mock-secret') 'Secret in result.'
}
Test-Case 'Already attached NIC is reused without PUT or another adapter' {
    Reset-Fixture -Attached
    $f = Get-Fixture
    $r = Invoke-AzureLocalVmCompletion $f.Config $f.LnetId -AddNetworkInterface -Execute -EnableUnsupportedLabPreview -Confirm:$false
    Assert ($r.NicAttached -and $r.CreatedResourceIds.Count -eq 0) 'Attached NIC not recognized.'
    Assert-NoWrites
}
Test-Case 'Guest-only retry never recreates NIC or resets an enabled agent' {
    Reset-Fixture -Attached
    $r = Execute-Fixture -GuestOnly
    Assert ($r.GuestArcConnected) 'Guest did not connect.'
    $f = Get-Fixture
    Assert (@($f.Calls | Where-Object Method -EQ 'PUT').Count -eq 0) 'NIC recreated.'
    $first = @($f.Calls | Where-Object Method -EQ 'PATCH')[0]
    Assert (-not $first.Body.properties.osProfile.windowsConfiguration.ContainsKey('provisionVMAgent')) 'Existing Arc agent reset.'
}
Test-Case 'Existing Hyper-V networking works without any Azure NIC reference in guest-only completion mocks' {
    Reset-Fixture
    $f = Get-Fixture
    $f.Refs = @()
    $r = Invoke-AzureLocalVmCompletion $f.Config -GuestCredential $credential -EnableGuestManagement `
        -Execute -EnableUnsupportedLabPreview -Confirm:$false
    Assert ($r.GuestArcConnected -and -not $r.NicAttached -and -not $r.GuestNetworkConfigured -and $null -eq $r.NicId) 'Unexpected NIC operation.'
    Assert ($f.Refs.Count -eq 0 -and -not $f.NicExists) 'A NIC was introduced.'
    Assert (@($f.Calls | Where-Object { $_.Uri -match '/(networkInterfaces|logicalNetworks)/' -or $_.Method -eq 'PUT' }).Count -eq 0) 'NIC resource access.'
    foreach ($call in $f.Calls | Where-Object Method -EQ 'PATCH') {
        Assert ($call.Body.properties.Keys.Count -eq 1 -and $call.Body.properties.ContainsKey('osProfile')) 'Network profile changed.'
    }
    Assert (($f.GuestCalls -join "`n") -notmatch '(Set|New|Remove)-(Net|Dns)|Get-NetAdapter') 'Guest network command executed.'
}
Test-Case 'Multiple existing NIC references remain intact' {
    Reset-Fixture
    $f = Get-Fixture
    $f.Refs += $f.Refs[0].Replace('old-nic', 'old-nic-2')
    $null = Execute-Fixture
    Assert ($f.Refs.Count -eq 3 -and $f.Refs[1].EndsWith('/old-nic-2')) 'Multiple references lost.'
}
Test-Case 'Unattached or failed existing resources are never adopted or deleted' {
    Reset-Fixture; (Get-Fixture).NicExists = $true
    $null = Assert-Throws { Execute-Fixture } 'not attached'
    Assert-NoWrites
}
foreach ($scenario in @('WrongVm', 'WrongParent', 'InfrastructureNetwork', 'GuestUnsupported')) {
    Test-Case "$scenario refuses mutation" {
        Reset-Fixture $scenario
        $null = Assert-Throws { Execute-Fixture } 'identity|parent|workload|Unsupported'
        Assert-NoWrites
    }
}
foreach ($scenario in @('WrongNetwork', 'WrongLocation', 'FailedNic')) {
    Test-Case "Attached NIC $scenario refuses mutation" {
        Reset-Fixture $scenario -Attached
        $null = Assert-Throws { Execute-Fixture } 'NIC identity'
        Assert-NoWrites
    }
}
Test-Case 'Context, owner UUID, VM generation and power state are validated' {
    foreach ($change in @('Context', 'LocalId', 'Generation', 'State')) {
        Reset-Fixture; $f = Get-Fixture
        switch ($change) {
            Context { $f.Context.Tenant.Id = 'wrong' }
            LocalId { $f.LocalId = 'wrong' }
            Generation { $f.Generation = 1 }
            State { $f.State = 'Off' }
        }
        $null = Assert-Throws { Execute-Fixture } 'context|UUID|Generation'
        Assert-NoWrites
    }
}
foreach ($scenario in @('MissingGateway', 'MissingDns', 'MultipleIPs')) {
    Test-Case "Guest NIC $scenario refuses to guess configuration" {
        Reset-Fixture $scenario -Attached
        $null = Assert-Throws { Execute-Fixture -ConfigureOnly } 'IPv4|DNS|exactly one|NIC identity'
        Assert (@((Get-Fixture).GuestCalls | Where-Object { $_ -match 'Get-NetAdapter' }).Count -eq 0) 'Guest network changed despite missing settings.'
        Assert-NoWrites
    }
}
foreach ($scenario in @('NicHttpFailure', 'PatchConflict', 'EtagRace', 'GuestNetworkFailure', 'InstallerFailure', 'ConfigFailed', 'HimdsFailure')) {
    Test-Case "Partial failure $scenario reports stage and resources without rollback" {
        Reset-Fixture $scenario
        $record = Assert-Throws { Execute-Fixture } 'Completion failed'
        $report = $record.Exception.Data['CompletionReport']
        Assert ($report.Status -eq 'Failed' -and $report.Stage -and $report.PotentialResourceIds.Count -eq 1) 'Missing report.'
        Assert (@((Get-Fixture).Calls | Where-Object Method -NOTIN @('GET', 'PUT', 'PATCH')).Count -eq 0) 'Automatic cleanup.'
        if ($scenario -eq 'NicHttpFailure') { Assert ($report.ArmError.code -eq 'MacPoolRejected') 'ARM diagnostics lost.' }
        if ($scenario -eq 'EtagRace') { Assert (@((Get-Fixture).Calls | Where-Object Method -EQ 'PATCH').Count -eq 0) 'Racing VM overwritten.' }
    }
}
foreach ($scenario in @('ConfigTimeout', 'ArcTimeout')) {
    Test-Case "$scenario cannot report accepted as connected" {
        Reset-Fixture $scenario -Attached
        $record = Assert-Throws { Execute-Fixture -GuestOnly -Timeout 1 } 'Timeout'
        Assert (-not $record.Exception.Data['CompletionReport'].GuestArcConnected) 'False connection success.'
    }
}
Test-Case 'Invalid scope, unsupported guest OS and absent actions are rejected in plans' {
    Reset-Fixture; $f = Get-Fixture
    $null = Assert-Throws { New-AzureLocalVmCompletionPlan $f.Config } 'at least one'
    $null = Assert-Throws { New-AzureLocalVmCompletionPlan $f.Config '/subscriptions/other/resourceGroups/x/providers/Microsoft.AzureStackHCI/logicalNetworks/x' -AddNetworkInterface } 'subscription'
    $f.Config.OsType = 'Linux'
    $null = Assert-Throws { New-AzureLocalVmCompletionPlan $f.Config -EnableGuestManagement } 'Windows'
    Assert ($f.Reads -eq 0) 'Invalid plan performed reads.'
}

& $module {
    function script:Invoke-AzureLocalVmRegistration {
        param($Configuration, $OwnerNodeSession, $Execute, $EnableUnsupportedLabPreview, $Confirm, $TimeoutSeconds, $PollSeconds)
        $script:F.RegistrationCalls++
        if (-not $Execute -or -not $EnableUnsupportedLabPreview -or $Confirm) { throw 'Wrong registration arguments.' }
        if ($script:F.Scenario -eq 'RegistrationFailure') {
            $e = [InvalidOperationException]::new('Mock registration failed.')
            $e.Data['RegistrationReport'] = @{
                Status = 'Failed'; Stage = 'Create VM instance'
                ConfirmedResourceIds = @($script:F.Plan.MachineId)
                PotentialResourceIds = @($script:F.Plan.VirtualMachineInstanceId)
            }
            throw $e
        }
        if ($script:F.Scenario -eq 'RegistrationNotExecuted') { return [pscustomobject]@{ Status = 'NotExecuted' } }
        [pscustomobject]@{ Status = 'PreviewProvisioningSucceeded'; MachineId = $script:F.Plan.MachineId }
    }
}
Test-Case 'Unified plan includes registration and agents but no NIC or network configuration' {
    Reset-Fixture
    $f = Get-Fixture
    $r = Invoke-AzureLocalVmSetup $f.Config
    Assert ($r.Status -eq 'PlanOnly' -and $r.Requests.Count -eq 4 -and $r.NetworkMode -eq 'PreserveExistingHyperV') 'Wrong setup plan.'
    Assert (($r | ConvertTo-Json -Depth 20) -notmatch '"networkProfile"|"ipConfigurations"|/networkInterfaces/|mock-secret') 'NIC or secret in setup plan.'
    Assert ($f.Reads -eq 0 -and $f.RegistrationCalls -eq 0 -and $f.GuestCalls.Count -eq 0) 'Setup plan contacted infrastructure.'
    $resume = Invoke-AzureLocalVmSetup $f.Config -RegistrationAlreadyComplete
    Assert ($resume.Requests.Count -eq 2 -and @($resume.Requests | Where-Object Method -NE 'PATCH').Count -eq 0) 'Resume plans registration.'
}
Test-Case 'Unified WhatIf performs no authentication, registration or guest access' {
    Reset-Fixture
    $f = Get-Fixture
    $r = Invoke-AzureLocalVmSetup $f.Config -Execute -EnableUnsupportedLabPreview -WhatIf
    Assert ($r.Status -eq 'NotExecuted' -and $f.Reads -eq 0 -and $f.RegistrationCalls -eq 0 -and $f.GuestCalls.Count -eq 0) 'Setup WhatIf did work.'
}
Test-Case 'Unified opt-in and credentials are required before registration' {
    Reset-Fixture
    $f = Get-Fixture
    $null = Assert-Throws { Invoke-AzureLocalVmSetup $f.Config -Execute -Confirm:$false } 'EnableUnsupportedLabPreview'
    $null = Assert-Throws { Invoke-AzureLocalVmSetup $f.Config -Execute -EnableUnsupportedLabPreview -Confirm:$false } 'GuestCredential'
    Assert ($f.Reads -eq 0 -and $f.RegistrationCalls -eq 0) 'Missing credentials caused registration.'
}
Test-Case 'Unified setup rejects NIC attachment configuration instead of ignoring it' {
    Reset-Fixture
    $f = Get-Fixture
    $f.Config.NetworkInterfaceIds = @($f.Refs[0])
    $null = Assert-Throws { Invoke-AzureLocalVmSetup $f.Config } 'NetworkInterfaceIds must be empty'
    Assert ($f.Reads -eq 0 -and $f.RegistrationCalls -eq 0) 'NIC configuration reached live reads.'
}
Test-Case 'Unified execution registers once then connects using existing networking' {
    Reset-Fixture
    $f = Get-Fixture
    $f.Refs = @()
    $r = Invoke-AzureLocalVmSetup $f.Config -GuestCredential $credential -Execute -EnableUnsupportedLabPreview -Confirm:$false
    Assert ($r.Status -eq 'PreviewSetupSucceeded' -and $f.RegistrationCalls -eq 1 -and $r.Completion.GuestArcConnected) 'Incomplete setup.'
    Assert (-not $f.NicExists -and $f.Refs.Count -eq 0 -and -not $r.Completion.GuestNetworkConfigured) 'Setup changed networking.'
    Assert (@($f.Calls | Where-Object { $_.Uri -match '/(networkInterfaces|logicalNetworks)/' -or $_.Method -eq 'PUT' }).Count -eq 0) 'Completion created a NIC.'
    Assert (($f.GuestCalls -join "`n") -notmatch '(Set|New|Remove)-(Net|Dns)|Get-NetAdapter') 'Setup configured guest networking.'
}
Test-Case 'Unified explicit resume skips registration but retains target identity checks' {
    Reset-Fixture
    $f = Get-Fixture
    $r = Invoke-AzureLocalVmSetup $f.Config -RegistrationAlreadyComplete -GuestCredential $credential -Execute -EnableUnsupportedLabPreview -Confirm:$false
    Assert ($r.Status -eq 'PreviewSetupSucceeded' -and $f.RegistrationCalls -eq 0 -and $null -eq $r.Registration) 'Resume registered again.'
    Reset-Fixture 'WrongVm'
    $f = Get-Fixture
    $null = Assert-Throws {
        Invoke-AzureLocalVmSetup $f.Config -RegistrationAlreadyComplete -GuestCredential $credential -Execute -EnableUnsupportedLabPreview -Confirm:$false
    } 'identity'
    Assert-NoWrites
}
Test-Case 'Unified guest and context preflight prevent partial registration' {
    foreach ($change in @('Context', 'Generation', 'State', 'GuestUnsupported')) {
        Reset-Fixture
        $f = Get-Fixture
        switch ($change) {
            Context { $f.Context.Tenant.Id = 'wrong' }
            Generation { $f.Generation = 1 }
            State { $f.State = 'Off' }
            GuestUnsupported { $f.Scenario = 'GuestUnsupported' }
        }
        $null = Assert-Throws {
            Invoke-AzureLocalVmSetup $f.Config -GuestCredential $credential -Execute -EnableUnsupportedLabPreview -Confirm:$false
        } 'context|Generation|Unsupported'
        Assert ($f.RegistrationCalls -eq 0) 'Preflight failure registered resources.'
        Assert-NoWrites
    }
}
Test-Case 'Unified registration failure preserves resource report and prevents guest changes' {
    Reset-Fixture 'RegistrationFailure'
    $f = Get-Fixture
    $errorRecord = Assert-Throws {
        Invoke-AzureLocalVmSetup $f.Config -GuestCredential $credential -Execute -EnableUnsupportedLabPreview -Confirm:$false
    } 'registration failed'
    $r = $errorRecord.Exception.Data['SetupReport']
    Assert ($r.Status -eq 'Failed' -and $r.Registration.ConfirmedResourceIds.Count -eq 1 -and $r.Registration.PotentialResourceIds.Count -eq 1) 'Partial registration report lost.'
    Assert-NoWrites
}
Test-Case 'Unified declined registration never proceeds to guest management' {
    Reset-Fixture 'RegistrationNotExecuted'
    $f = Get-Fixture
    $null = Assert-Throws {
        Invoke-AzureLocalVmSetup $f.Config -GuestCredential $credential -Execute -EnableUnsupportedLabPreview -Confirm:$false
    } 'did not confirm'
    Assert-NoWrites
}
Test-Case 'Unified guest failure retains successful registration without fallback NIC creation' {
    Reset-Fixture 'InstallerFailure'
    $f = Get-Fixture
    $errorRecord = Assert-Throws {
        Invoke-AzureLocalVmSetup $f.Config -GuestCredential $credential -Execute -EnableUnsupportedLabPreview -Confirm:$false
    } 'installer failed'
    $r = $errorRecord.Exception.Data['SetupReport']
    Assert ($r.Status -eq 'Failed' -and $r.Registration.Status -eq 'PreviewProvisioningSucceeded' -and $r.Completion.Stage -eq 'Install guest configuration agent') 'Stage reports lost.'
    Assert (@($f.Calls | Where-Object { $_.Method -notin @('GET','PATCH') -or $_.Uri -match '/(networkInterfaces|logicalNetworks)/' }).Count -eq 0) 'Automatic NIC creation or rollback.'
}
Test-Case 'Explicit April API propagates to guest-management reads PATCH and polling' {
    Reset-Fixture -Attached
    $f = Get-Fixture
    $f.Config.StackHciApiVersion = '2026-07-01-preview'
    $r = Execute-Fixture -GuestOnly
    Assert ($r.GuestArcConnected -and @($f.Calls | Where-Object { $_.Uri -match 'Microsoft.AzureStackHCI/' -and
        $_.Uri -notlike '*api-version=2026-07-01-preview' }).Count -eq 0) 'Completion used another API version.'
}
Test-Case 'Standalone completion CLI produces plan JSON without authentication' {
    $lnet = '/subscriptions/22222222-2222-2222-2222-222222222222/resourceGroups/lab-infra-rg/providers/Microsoft.AzureStackHCI/logicalNetworks/lnet1'
    $json = & (Join-Path $root 'tools\Complete-AzureLocalVm.ps1') -ConfigurationPath (Join-Path $root 'examples\registration.example.json') `
        -LogicalNetworkId $lnet -AddNetworkInterface -EnableGuestManagement
    $r = $json | ConvertFrom-Json
    Assert ($r.Status -eq 'PlanOnly' -and $r.Requests.Count -eq 4) 'CLI plan shape invalid.'
}
Test-Case 'Standalone completion CLI reads the network from configuration' {
    $json = & (Join-Path $root 'tools\Complete-AzureLocalVm.ps1') -ConfigurationPath (Join-Path $root 'examples\registration.example.json') -AddNetworkInterface
    $r = $json | ConvertFrom-Json
    Assert ($r.LogicalNetworkId -eq (New-Config).LogicalNetworkId -and $r.Status -eq 'PlanOnly') 'CLI failed to read configured network.'
}
Test-Case 'Standalone unified CLI plans registration or explicit resume without networking' {
    foreach ($resume in @($false, $true)) {
        $json = & (Join-Path $root 'tools\Invoke-AzureLocalVmSetup.ps1') -ConfigurationPath (Join-Path $root 'examples\registration.example.json') `
            -RegistrationAlreadyComplete:$resume
        $r = $json | ConvertFrom-Json
        Assert ($r.Status -eq 'PlanOnly' -and $r.NetworkMode -eq 'PreserveExistingHyperV' -and $r.Requests.Count -eq $(if ($resume) { 2 } else { 4 })) 'Unified CLI plan invalid.'
        Assert ($json -notmatch '"networkProfile"|"ipConfigurations"|/networkInterfaces/') 'Unified CLI plans NIC changes.'
    }
}
$credential.Password.Dispose()
Write-Host "$passed completion tests passed (mocked; no live Azure/Hyper-V/guest operations)."
