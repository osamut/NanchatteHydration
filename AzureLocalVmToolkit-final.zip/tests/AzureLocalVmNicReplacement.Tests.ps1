﻿#Requires -Version 5.1
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$root = Split-Path $PSScriptRoot
Import-Module (Join-Path $root 'tools\AzureLocalVmRegistration.psm1') -Force
$module = Get-Module AzureLocalVmRegistration
$example = Get-Content (Join-Path $root 'examples\registration.example.json') -Raw | ConvertFrom-Json
$testDirectory = Join-Path $PSScriptRoot ('.nic-replacement-tests-' + [guid]::NewGuid().ToString('N'))
$null = New-Item -ItemType Directory -Path $testDirectory
$passed = 0
$credential = [pscredential]::new('Administrator', (ConvertTo-SecureString 'offline-mock-password' -AsPlainText -Force))
function Assert($Condition, [string]$Message) { if (-not $Condition) { throw $Message } }
function Test-Case([string]$Name, [scriptblock]$Body) { & $Body; $script:passed++; Write-Host "PASS $Name" }
function Assert-Throws([scriptblock]$Body, [string]$Pattern) {
    $failure = $null
    try { & $Body | Out-Null } catch { $failure = $_ }
    Assert ($null -ne $failure -and $failure.Exception.Message -match $Pattern) "Expected failure: $Pattern; got $failure"
    return $failure
}

& $module {
    function script:Get-LabAzureContext { param($Configuration) $script:R.Reads++; return @{} }
    function script:Read-LabNodeIdentity {
        param($Configuration, $OwnerNodeSession)
        [pscustomobject]@{ HostName = $Configuration.LocalHost; VMs = @([pscustomobject]@{
            Id = $Configuration.ExpectedVmId; Name = $Configuration.LocalVmName; State = 'Running'; Generation = 2
        }) }
    }
    function script:Test-LabInfrastructure { param($Configuration, $Context, $OwnerNodeSession) Assert-LocalVm $Configuration $OwnerNodeSession }
    function script:Test-LabGuestAccess { param($Configuration, $OwnerNodeSession, $Credential) return @{ Version = '10.0' } }
    function script:Invoke-LabGuest {
        param($Configuration, $OwnerNodeSession, $Credential, $Command, $Arguments = @())
        Assert-LocalVm $Configuration $OwnerNodeSession
        & $Command @Arguments
    }
    function script:Wait-LabDelay { param($Seconds) Start-Sleep -Milliseconds 30 }
    function script:Wait-LabGuestConnected {
        param($Configuration, $Plan, $Context, $Agent, $TimeoutSeconds, $PollSeconds)
        $script:R.Events.Add('ArcVerify')
        if ($script:R.Scenario -eq 'ArcFailure') { throw 'Existing Arc connection failed.' }
        return @{ status = 'Connected' }
    }
    function script:Get-Service { param($Name, $ErrorAction) return [pscustomobject]@{ Status = 'Running' } }
    function script:Get-VM {
        param($Id, $ErrorAction)
        $script:R.Reads++
        [pscustomobject]@{ Id = $Id; Name = $script:R.Config.LocalVmName; State = 'Running'; Generation = 2 }
    }
    function script:Get-VMNetworkAdapter { param($VM, $ErrorAction) $script:R.Hosts }
    function script:Get-VMNetworkAdapterVlan {
        param($VMNetworkAdapter, $ErrorAction)
        [pscustomobject]@{ OperationMode = $VMNetworkAdapter.VlanMode; AccessVlanId = $VMNetworkAdapter.VlanId }
    }
    function script:Get-VMNetworkAdapterAcl { param($VMNetworkAdapter, $ErrorAction) }
    function script:Get-VMNetworkAdapterExtendedAcl { param($VMNetworkAdapter, $ErrorAction) }
    function script:Disconnect-VMNetworkAdapter {
        param($VMNetworkAdapter, $Confirm, $ErrorAction)
        if ($VMNetworkAdapter.Id -ine $script:R.SourceId) { throw 'Attempted to disconnect another NIC.' }
        $script:R.Events.Add('DisconnectOriginal')
        $VMNetworkAdapter.SwitchName = ''
        $VMNetworkAdapter.SwitchId = [guid]::Empty.ToString()
        if ($script:R.Scenario -eq 'OtherHostChanged') { $script:R.Hosts[1].SwitchId = 'other-switch' }
    }
    function script:Remove-VMNetworkAdapter {
        param($VMNetworkAdapter, $Confirm, $ErrorAction)
        if ($VMNetworkAdapter.Id -ine $script:R.SourceId -or $VMNetworkAdapter.SwitchName) { throw 'Unsafe NIC deletion.' }
        if (@($script:R.Events | Where-Object { $_ -eq 'ConnectivityVerified' }).Count -eq 0) { throw 'Deletion before connectivity verification.' }
        $script:R.Events.Add('RemoveOriginal')
        $script:R.Hosts = @($script:R.Hosts | Where-Object Id -NE $VMNetworkAdapter.Id)
        $script:R.Guests = @($script:R.Guests | Where-Object InterfaceIndex -NE 7)
    }
    function script:New-TestHost($Id, $Mac, $Name) {
        [pscustomobject]@{
            Id = $Id; Name = $Name; MacAddress = $Mac; SwitchId = '44444444-4444-4444-4444-444444444444'
            SwitchName = 'vm-switch'; VlanMode = 'Untagged'; VlanId = 0; IsLegacy = $false
            MacAddressSpoofing = 'Off'; PortMirroringMode = 'None'; DhcpGuard = 'Off'; RouterGuard = 'Off'
        }
    }
    function script:New-TestGuest($Index, $Mac, $IP) {
        [pscustomobject]@{
            Name = "Ethernet $Index"; InterfaceGuid = ('{55555555-5555-5555-5555-' + ('{0:d12}' -f [int]$Index) + '}')
            InterfaceIndex = $Index; MacAddress = $Mac; Status = 'Up'; Dhcp = 'Disabled'
            AutomaticMetric = 'Disabled'; InterfaceMetric = 25; NlMtu = 1400
            Forwarding = 'Disabled'; WeakHostSend = 'Disabled'; WeakHostReceive = 'Disabled'
            DnsServers = @('192.0.2.53', '192.0.2.54'); DnsSuffix = 'lab.invalid'
            RegisterAddress = $true; UseSuffix = $true
            IPv4 = @([pscustomobject]@{ IPAddress = $IP; PrefixLength = 24; SkipAsSource = $false; AddressState = 'Preferred' })
            GlobalIPv6 = @()
            Routes = @([pscustomobject]@{ DestinationPrefix = '0.0.0.0/0'; NextHop = '192.0.2.1'; RouteMetric = 9; Protocol = 'NetMgmt' })
        }
    }
    function script:Add-TestTarget {
        $f = $script:R
        $f.Hosts += New-TestHost $f.TargetId '021122334455' 'duplicate-name'
        $guest = New-TestGuest 12 '02-11-22-33-44-55' '192.0.2.99'
        $guest.InterfaceMetric = 100; $guest.NlMtu = 1500; $guest.DnsSuffix = ''; $guest.Dhcp = 'Enabled'
        $f.Guests += $guest
    }
    function script:Get-NetAdapter { param($ErrorAction) $script:R.Guests }
    function script:Get-NetLbfoTeamMember {
        param($ErrorAction)
        if ($script:R.Scenario -eq 'Team') { [pscustomobject]@{ Name = 'Ethernet 7' } }
    }
    function script:Get-NetIPAddress {
        param($InterfaceIndex, $AddressFamily, $ErrorAction)
        if ($InterfaceIndex -and @($script:R.Guests | Where-Object { $_.InterfaceIndex -eq $InterfaceIndex -and $_.IPv4.Count -gt 0 }).Count -eq 0) {
            throw 'No matching interface IP instances.'
        }
        foreach ($g in $script:R.Guests) {
            if ($InterfaceIndex -and $InterfaceIndex -ne $g.InterfaceIndex) { continue }
            foreach ($ip in $g.IPv4) {
                [pscustomobject]@{ InterfaceIndex = $g.InterfaceIndex; AddressFamily = 'IPv4'; IPAddress = $ip.IPAddress
                    PrefixLength = $ip.PrefixLength; SkipAsSource = $ip.SkipAsSource; AddressState = $ip.AddressState }
            }
            if ($AddressFamily -ne 'IPv4') {
                foreach ($ip in $g.GlobalIPv6) {
                    [pscustomobject]@{ InterfaceIndex = $g.InterfaceIndex; AddressFamily = 'IPv6'; IPAddress = $ip }
                }
            }
        }
    }
    function script:Get-NetRoute {
        param($InterfaceIndex, $AddressFamily, $ErrorAction)
        if ($InterfaceIndex -and @($script:R.Guests | Where-Object { $_.InterfaceIndex -eq $InterfaceIndex -and $_.Routes.Count -gt 0 }).Count -eq 0) {
            throw 'No matching interface route instances.'
        }
        foreach ($g in $script:R.Guests) {
            if ($InterfaceIndex -and $InterfaceIndex -ne $g.InterfaceIndex) { continue }
            foreach ($route in $g.Routes) {
                [pscustomobject]@{ InterfaceIndex = $g.InterfaceIndex; DestinationPrefix = $route.DestinationPrefix
                    NextHop = $route.NextHop; RouteMetric = $route.RouteMetric; Protocol = $route.Protocol }
            }
        }
    }
    function script:Get-NetIPInterface { param($AddressFamily, $ErrorAction) $script:R.Guests }
    function script:Get-DnsClientServerAddress {
        param($AddressFamily, $ErrorAction)
        foreach ($g in $script:R.Guests) { [pscustomobject]@{ InterfaceIndex = $g.InterfaceIndex; ServerAddresses = $g.DnsServers } }
    }
    function script:Get-DnsClient {
        param($ErrorAction)
        foreach ($g in $script:R.Guests) {
            [pscustomobject]@{ InterfaceIndex = $g.InterfaceIndex; ConnectionSpecificSuffix = $g.DnsSuffix
                RegisterThisConnectionsAddress = $g.RegisterAddress; UseSuffixWhenRegistering = $g.UseSuffix }
        }
    }
    function script:Set-NetIPInterface {
        param($InterfaceIndex, $AddressFamily, $Dhcp, $AutomaticMetric, $InterfaceMetric, $NlMtuBytes, $ErrorAction)
        $script:R.Events.Add("GuestSetInterface:$InterfaceIndex")
        $g = @($script:R.Guests | Where-Object InterfaceIndex -EQ $InterfaceIndex)[0]
        if ($Dhcp -eq 'Disabled' -and $g.Dhcp -eq 'Enabled') { $g.IPv4 = @(); $g.Routes = @() }
        foreach ($name in @('Dhcp', 'AutomaticMetric', 'InterfaceMetric')) {
            if ($PSBoundParameters.ContainsKey($name)) { $g.$name = $PSBoundParameters[$name] }
        }
        if ($PSBoundParameters.ContainsKey('NlMtuBytes')) { $g.NlMtu = $NlMtuBytes }
    }
    function script:Remove-NetIPAddress {
        [CmdletBinding(SupportsShouldProcess)]
        param([Parameter(ValueFromPipeline)]$InputObject)
        process {
            $script:R.Events.Add("GuestRemoveIP:$($InputObject.InterfaceIndex)")
            $g = @($script:R.Guests | Where-Object InterfaceIndex -EQ $InputObject.InterfaceIndex)[0]
            $g.IPv4 = @($g.IPv4 | Where-Object IPAddress -NE $InputObject.IPAddress)
        }
    }
    function script:Remove-NetRoute {
        [CmdletBinding(SupportsShouldProcess)]
        param([Parameter(ValueFromPipeline)]$InputObject)
        process {
            $g = @($script:R.Guests | Where-Object InterfaceIndex -EQ $InputObject.InterfaceIndex)[0]
            $g.Routes = @($g.Routes | Where-Object { $_.DestinationPrefix -ne $InputObject.DestinationPrefix -or $_.NextHop -ne $InputObject.NextHop })
        }
    }
    function script:New-NetIPAddress {
        param($InterfaceIndex, $IPAddress, $PrefixLength, $ErrorAction)
        if (@($script:R.Guests | ForEach-Object { $_.IPv4 } | Where-Object IPAddress -EQ $IPAddress).Count -ne 0) {
            throw 'Duplicate IP introduced during cutover.'
        }
        $g = @($script:R.Guests | Where-Object InterfaceIndex -EQ $InterfaceIndex)[0]
        $g.IPv4 += [pscustomobject]@{ IPAddress = $IPAddress; PrefixLength = $PrefixLength; SkipAsSource = $false
            AddressState = $(if ($script:R.Scenario -eq 'DuplicateAddress') { 'Duplicate' } else { 'Preferred' }) }
        $script:R.Events.Add("GuestNewIP:$InterfaceIndex")
    }
    function script:New-NetRoute {
        param($InterfaceIndex, $DestinationPrefix, $NextHop, $RouteMetric, $ErrorAction)
        $g = @($script:R.Guests | Where-Object InterfaceIndex -EQ $InterfaceIndex)[0]
        $g.Routes += [pscustomobject]@{ DestinationPrefix = $DestinationPrefix; NextHop = $NextHop; RouteMetric = $RouteMetric; Protocol = 'NetMgmt' }
    }
    function script:Set-DnsClientServerAddress {
        param($InterfaceIndex, $ServerAddresses, $ErrorAction)
        if ($script:R.Scenario -eq 'GuestFailure') { throw 'Guest DNS write failed after partial cutover.' }
        $g = @($script:R.Guests | Where-Object InterfaceIndex -EQ $InterfaceIndex)[0]
        $g.DnsServers = @($ServerAddresses)
        if ($script:R.Scenario -eq 'OtherGuestChanged') { $script:R.Guests[1].DnsServers = @('192.0.2.88') }
    }
    function script:Set-DnsClient {
        param($InterfaceIndex, $ConnectionSpecificSuffix, $RegisterThisConnectionsAddress, $UseSuffixWhenRegistering, $ErrorAction)
        $g = @($script:R.Guests | Where-Object InterfaceIndex -EQ $InterfaceIndex)[0]
        $g.DnsSuffix = $ConnectionSpecificSuffix; $g.RegisterAddress = $RegisterThisConnectionsAddress; $g.UseSuffix = $UseSuffixWhenRegistering
    }
    function script:Test-NetConnection {
        param($ComputerName, $Port, $InformationLevel, $WarningAction)
        $f = $script:R
        $target = @($f.Guests | Where-Object InterfaceIndex -EQ 12)[0]
        $success = $f.Scenario -ne 'ConnectivityFailure' -and
            -not ($f.Scenario -eq 'PostDeleteFailure' -and 'RemoveOriginal' -in $f.Events)
        if ($success) { $f.Events.Add('ConnectivityVerified') }
        $sourceAddress = switch ($f.Scenario) {
            'WrongSource' { '192.0.2.200' }
            'CimSource' { [pscustomobject]@{ IPAddress = $target.IPv4[0].IPAddress; InterfaceAlias = $target.Name } }
            'WrongCimSource' { [pscustomobject]@{ IPAddress = '192.0.2.200'; InterfaceAlias = $target.Name } }
            'MissingCimSource' { [pscustomobject]@{ InterfaceAlias = $target.Name } }
            'NullSource' { $null }
            'IPAddressSource' { [Net.IPAddress]::Parse($target.IPv4[0].IPAddress) }
            default { $target.IPv4[0].IPAddress }
        }
        [pscustomobject]@{ ComputerName = $ComputerName; RemoteAddress = '192.0.2.10'; TcpTestSucceeded = $success
            SourceAddress = $sourceAddress
            InterfaceAlias = $(if ($f.Scenario -eq 'WrongAlias') { 'another-NIC' } else { $target.Name }) }
    }
    function script:Test-NicBody {
        $f = $script:R
        @{
            id = $f.NicId; extendedLocation = @{ name = $f.Config.CustomLocationId }
            properties = @{
                provisioningState = $(if ($f.Scenario -eq 'ProvisionFailed') { 'Failed' } else { 'Succeeded' })
                macAddress = $(if ($f.Scenario -eq 'EmptyMac') { '' } elseif ($f.Scenario -eq 'DuplicateMac') { '00155D123456' } else { '02:11:22:33:44:55' })
                ipConfigurations = @(@{ properties = @{ subnet = @{ id = $f.LnetId }; privateIPAddress = $f.DesiredIP
                    prefixLength = '24'; gateway = $(if ($f.Scenario -eq 'WrongGateway') { '192.0.2.2' } else { '192.0.2.1' }) } })
            }
        }
    }
    function script:Invoke-LabArmRequest {
        param($Method, $Uri, $Body, $Context, $Subscription, $TimeoutSeconds, $IfMatch)
        $f = $script:R
        Assert-ArmUri $Uri $Subscription
        $f.Reads++
        $f.Calls.Add([pscustomobject]@{ Method = $Method; Uri = $Uri; Body = $Body; IfMatch = $IfMatch })
        $id = ([uri]$Uri).AbsolutePath
        $result = @{ StatusCode = 200; Headers = @{ ETag = '"etag-1"' }; Body = @{} }
        if ($Method -ne 'GET') {
            if (-not (Test-Path -LiteralPath $f.BackupPath)) { throw 'Azure mutation before durable backup.' }
            $f.Events.Add($Method)
            if ($Method -eq 'PUT') {
                if ($f.Scenario -eq 'CreateFailure') { $result.StatusCode = 409; $result.Body = @{ error = @{ code = 'AllocationFailed' } }; return [pscustomobject]$result }
                $f.NicExists = $true
                $result.StatusCode = 201; $result.Body = Test-NicBody
            } elseif ($Method -eq 'PATCH') {
                if ($IfMatch -ne '"etag-1"') { throw 'ETag missing.' }
                if ($f.Scenario -eq 'PatchConflict') { $result.StatusCode = 412; return [pscustomobject]$result }
                $f.Refs = @($Body.properties.networkProfile.networkInterfaces | ForEach-Object { $_.id })
                if ($f.Scenario -eq 'LostReference') { $f.Refs = @($f.NicId) }
                if ($f.Scenario -ne 'NoRealization') { Add-TestTarget }
                if ($f.Scenario -eq 'ExtraAdapter') { $f.Hosts += New-TestHost 'unexpected' '021122334477' 'extra' }
                if ($f.Scenario -eq 'SourceChanged') { $f.Guests[0].DnsSuffix = 'changed.invalid' }
                $result.StatusCode = 202; $result.Body = @{ properties = @{ provisioningState = 'Accepted' } }
            } else { throw 'Unexpected destructive ARM method.' }
            return [pscustomobject]$result
        }
        if ($id -ieq $f.Plan.MachineId) {
            $result.Body = @{ id = $id; kind = 'HCI'; location = $f.Config.Location
                identity = @{ type = 'SystemAssigned'; principalId = '66666666-6666-6666-6666-666666666666'; tenantId = $f.Config.TenantId }
                properties = @{ status = 'Connected' } }
        } elseif ($id -ieq $f.Plan.VirtualMachineInstanceId) {
            $f.VmReads++
            if ($f.Scenario -eq 'EtagRace' -and $f.VmReads -ge 3) { $result.Headers.ETag = '"etag-2"' }
            $result.Body = @{ id = $id; extendedLocation = @{ name = $f.Config.CustomLocationId }
                properties = @{ localVmName = $f.Config.LocalVmName; hyperVVmId = $(if ($f.Scenario -eq 'WrongVm') { 'wrong' } else { $f.Config.ExpectedVmId })
                    provisioningState = 'Succeeded'; networkProfile = @{ networkInterfaces = @($f.Refs | ForEach-Object { @{ id = $_ } }) } } }
        } elseif ($id -ieq $f.NicId) {
            if ($f.NicExists) { $result.Body = Test-NicBody } else { $result.StatusCode = 404 }
        } elseif ($id -ieq $f.OtherNicId) {
            $result.Body = @{ id = $id; properties = @{ macAddress = $(if ($f.Scenario -eq 'SourceManaged') { '00155D123456' } else { '021122334466' }) } }
        } elseif ($id -ieq $f.LnetId) {
            $result.Body = @{ id = $id; extendedLocation = @{ name = $f.Config.CustomLocationId }
                properties = @{ provisioningState = 'Succeeded'; networkType = 'Workload'; vmSwitchName = 'vm-switch'
                    subnets = @(@{ properties = @{ addressPrefix = '192.0.2.0/24'; ipAllocationMethod = 'Static'; vlan = 0
                        ipPools = @(@{ ipPoolType = 'vm'; start = '192.0.2.10'; end = '192.0.2.200' }) } }) } }
            if ($f.Scenario -eq 'LegacyNetworkShape') {
                $result.Body.properties.Remove('networkType')
                $result.Body.properties.subnets[0].properties.ipPools[0].Remove('ipPoolType')
            }
            if ($f.Scenario -eq 'InfrastructureNetwork') { $result.Body.properties.networkType = 'Infrastructure' }
            if ($f.Scenario -eq 'VipPool') { $result.Body.properties.subnets[0].properties.ipPools[0].ipPoolType = 'vippool' }
            if ($f.Scenario -eq 'UnknownPoolType') { $result.Body.properties.subnets[0].properties.ipPools[0].ipPoolType = 'unknown' }
        } else { throw "Unexpected GET $Uri" }
        return [pscustomobject]$result
    }
}

function Reset-Fixture([string]$Scenario = 'Success', [switch]$Reuse) {
    $c = @{}
    foreach ($p in $example.PSObject.Properties) { $c[$p.Name] = $p.Value }
    $c.LocalHost = $env:COMPUTERNAME
    $source = "Microsoft:$($c.ExpectedVmId)\77777777-7777-7777-7777-777777777777"
    $lnet = "/subscriptions/$($c.SubscriptionId)/resourceGroups/lab-infra-rg/providers/Microsoft.AzureStackHCI/logicalNetworks/lnet1"
    $backup = Join-Path $testDirectory ([guid]::NewGuid().ToString('N') + '.json')
    $plan = Invoke-AzureLocalVmNicReplacement $c $source $lnet
    & $module {
        param($c, $source, $lnet, $backup, $plan, $Scenario, $Reuse)
        $script:R = @{
            Config = $c; SourceId = $source; LnetId = $lnet; BackupPath = $backup; Plan = $plan; NicId = $plan.NetworkInterfaceId
            TargetId = "Microsoft:$($c.ExpectedVmId)\88888888-8888-8888-8888-888888888888"
            OtherNicId = $plan.NetworkInterfaceId.Replace('-nic0', '-other'); DesiredIP = '192.0.2.20'
            Refs = @($plan.NetworkInterfaceId.Replace('-nic0', '-other'))
            Scenario = $Scenario; NicExists = [bool]$Reuse; Reads = 0; VmReads = 0; Reuse = [bool]$Reuse
            Calls = [System.Collections.Generic.List[object]]::new(); Events = [System.Collections.Generic.List[string]]::new()
            Hosts = @((New-TestHost $source '00155D123456' 'duplicate-name'),
                (New-TestHost "Microsoft:$($c.ExpectedVmId)\99999999-9999-9999-9999-999999999999" '021122334466' 'duplicate-name'))
            Guests = @((New-TestGuest 7 '00-15-5D-12-34-56' '192.0.2.20'), (New-TestGuest 4 '02-11-22-33-44-66' '192.0.2.80'))
        }
        if ($Reuse) { $script:R.Refs += $plan.NetworkInterfaceId; Add-TestTarget }
    } $c $source $lnet $backup $plan $Scenario ([bool]$Reuse)
}
function Fixture { & $module { $script:R } }
function Execute-Fixture([switch]$ConvertDhcpToStatic, [string]$PrivateIPAddress) {
    $f = Fixture
    Invoke-AzureLocalVmNicReplacement $f.Config $f.SourceId $f.LnetId -BackupPath $f.BackupPath -GuestCredential $credential `
        -ReuseAttachedNetworkInterface:$f.Reuse -ConvertDhcpToStatic:$ConvertDhcpToStatic -PrivateIPAddress $PrivateIPAddress `
        -Execute -EnableUnsupportedLabPreview -AcceptNetworkInterruption -Confirm:$false -TimeoutSeconds 1 -PollSeconds 1
}
function Assert-NoMutation {
    $f = Fixture
    Assert (@($f.Calls | Where-Object Method -NE 'GET').Count -eq 0 -and $f.Events.Count -eq 0) 'Unexpected network mutation.'
}
function Assert-OriginalRetained {
    $f = Fixture
    Assert (@($f.Hosts | Where-Object Id -EQ $f.SourceId).Count -eq 1 -and 'RemoveOriginal' -notin $f.Events) 'Original NIC was removed on failure.'
}

try {
    Test-Case 'Plan uses July 2026 API without any live access or backup writes' {
        Reset-Fixture
        $f = Fixture; $plan = Invoke-AzureLocalVmNicReplacement $f.Config $f.SourceId $f.LnetId -BackupPath $f.BackupPath
        Assert ($plan.Status -eq 'PlanOnly' -and $plan.ApiVersion -eq '2026-04-01-preview' -and $f.Reads -eq 0) 'Wrong plan.'
        Assert (-not (Test-Path -LiteralPath $f.BackupPath)) 'Plan wrote a backup.'
    }
    Test-Case 'Omitted source ID plans automatic single-adapter selection without reading infrastructure' {
        Reset-Fixture
        $f = Fixture
        $p = Invoke-AzureLocalVmNicReplacement -Configuration $f.Config -LogicalNetworkId $f.LnetId
        Assert ($p.SourceSelection -eq 'AutoSingleAdapter' -and -not $p.SourceNetworkAdapterId -and $f.Reads -eq 0) 'Automatic plan accessed infrastructure.'
    }
    Test-Case 'Configured network reaches replacement execution without an explicit argument' {
        Reset-Fixture
        $f = Fixture
        $r = Invoke-AzureLocalVmNicReplacement -Configuration $f.Config -SourceNetworkAdapterId $f.SourceId `
            -BackupPath $f.BackupPath -GuestCredential $credential -Execute -EnableUnsupportedLabPreview -AcceptNetworkInterruption -Confirm:$false
        $backup = Get-Content -LiteralPath $f.BackupPath -Raw | ConvertFrom-Json
        Assert ($r.OriginalRemoved -and $backup.Plan.LogicalNetworkId -ceq $f.Config.LogicalNetworkId) 'Replacement lost the configured network.'
    }
    Test-Case 'Replacement rejects conflicting network arguments before reads or mutations' {
        Reset-Fixture
        $f = Fixture
        $null = Assert-Throws {
            Invoke-AzureLocalVmNicReplacement -Configuration $f.Config -LogicalNetworkId ($f.LnetId + '-stale')
        } 'differs from configuration'
        Assert ($f.Reads -eq 0) 'Conflicting settings contacted infrastructure.'
        Assert-NoMutation
    }
    Test-Case 'Automatic selection WhatIf does not access infrastructure or create a backup' {
        Reset-Fixture
        $f = Fixture
        $p = Invoke-AzureLocalVmNicReplacement -Configuration $f.Config -LogicalNetworkId $f.LnetId `
            -BackupPath $f.BackupPath -Execute -EnableUnsupportedLabPreview -AcceptNetworkInterruption -WhatIf
        Assert ($p.Status -eq 'NotExecuted' -and $f.Reads -eq 0 -and -not (Test-Path $f.BackupPath)) 'WhatIf discovered or mutated source.'
    }
    Test-Case 'Sole adapter is automatically selected and its exact ID is persisted before replacement' {
        Reset-Fixture
        $f = Fixture
        $f.Hosts = @($f.Hosts[0]); $f.Guests = @($f.Guests[0]); $f.Refs = @()
        $r = Invoke-AzureLocalVmNicReplacement -Configuration $f.Config -LogicalNetworkId $f.LnetId `
            -BackupPath $f.BackupPath -GuestCredential $credential -Execute -EnableUnsupportedLabPreview -AcceptNetworkInterruption -Confirm:$false
        $backup = Get-Content -LiteralPath $f.BackupPath -Raw | ConvertFrom-Json
        Assert ($r.OriginalRemoved -and $r.SourceSelection -eq 'AutoSingleAdapter' -and $r.SourceNetworkAdapterId -eq $f.SourceId -and
            $backup.Plan.SourceNetworkAdapterId -eq $f.SourceId -and $backup.OriginalHostNic.Id -eq $f.SourceId) 'Selected source identity not retained.'
    }
    foreach ($adapterCount in @(0,2)) {
        Test-Case "Automatic selection refuses $adapterCount adapters without writes or backup" {
            Reset-Fixture
            $f = Fixture
            if ($adapterCount -eq 0) { $f.Hosts = @() }
            $null = Assert-Throws {
                Invoke-AzureLocalVmNicReplacement -Configuration $f.Config -LogicalNetworkId $f.LnetId `
                    -BackupPath $f.BackupPath -GuestCredential $credential -Execute -EnableUnsupportedLabPreview -AcceptNetworkInterruption -Confirm:$false
            } 'exactly one'
            Assert-NoMutation
            Assert (-not (Test-Path $f.BackupPath)) 'Ambiguous source backed up or mutated.'
        }
    }
    Test-Case 'Automatic selection never treats a sole Azure-managed NIC as an unmanaged source' {
        Reset-Fixture
        $f = Fixture
        $f.Hosts = @($f.Hosts[1])
        $null = Assert-Throws {
            Invoke-AzureLocalVmNicReplacement -Configuration $f.Config -LogicalNetworkId $f.LnetId `
                -BackupPath $f.BackupPath -GuestCredential $credential -Execute -EnableUnsupportedLabPreview -AcceptNetworkInterruption -Confirm:$false
        } 'already Azure-managed'
        Assert-NoMutation
    }
    Test-Case 'Automatically discovered source ID must still belong to the configured VM UUID' {
        Reset-Fixture
        $f = Fixture
        $f.Hosts = @($f.Hosts[0])
        $f.Hosts[0].Id = 'Microsoft:11111111-1111-1111-1111-111111111111\77777777-7777-7777-7777-777777777777'
        $null = Assert-Throws {
            Invoke-AzureLocalVmNicReplacement -Configuration $f.Config -LogicalNetworkId $f.LnetId `
                -BackupPath $f.BackupPath -GuestCredential $credential -Execute -EnableUnsupportedLabPreview -AcceptNetworkInterruption -Confirm:$false
        } 'configured VM'
        Assert-NoMutation
    }
    Test-Case 'Unified real preflight resolves a sole source NIC and rejects ambiguity before any writes' {
        Reset-Fixture
        $f = Fixture
        $replacement = Invoke-AzureLocalVmNicReplacement -Configuration $f.Config -LogicalNetworkId $f.LnetId -BackupPath $f.BackupPath
        $null = Assert-Throws {
            & $module { param($f,$credential,$replacement) Test-LabSetupNicPreflight $f.Config @{} $null $credential $replacement } $f $credential $replacement
        } 'exactly one'
        $f.Hosts = @($f.Hosts[0])
        & $module { param($f,$credential,$replacement) Test-LabSetupNicPreflight $f.Config @{} $null $credential $replacement } $f $credential $replacement
        Assert ($replacement.SourceNetworkAdapterId -eq $f.SourceId) 'Unified preflight did not resolve exact ID.'
        Assert-NoMutation
    }
    Test-Case 'WhatIf bypasses credentials, live access, backup and deletion' {
        Reset-Fixture; $f = Fixture
        $p = Invoke-AzureLocalVmNicReplacement $f.Config $f.SourceId $f.LnetId -Execute -EnableUnsupportedLabPreview -AcceptNetworkInterruption -WhatIf
        Assert ($p.Status -eq 'NotExecuted' -and $f.Reads -eq 0) 'WhatIf contacted live infrastructure.'
        Assert-NoMutation
    }
    Test-Case 'Both lab and network-interruption consent are required' {
        Reset-Fixture; $f = Fixture
        $null = Assert-Throws { Invoke-AzureLocalVmNicReplacement $f.Config $f.SourceId $f.LnetId -Execute -Confirm:$false } 'AcceptNetworkInterruption'
        $null = Assert-Throws { Invoke-AzureLocalVmNicReplacement $f.Config $f.SourceId $f.LnetId -Execute -EnableUnsupportedLabPreview -Confirm:$false } 'AcceptNetworkInterruption'
        Assert ($f.Reads -eq 0) 'Consent failure contacted infrastructure.'
    }
    Test-Case 'Successful replacement preserves exact IPv4 DNS gateway suffix metrics and MTU' {
        Reset-Fixture
        $r = Execute-Fixture; $f = Fixture
        Assert ($r.Status -eq 'PreviewNicReplacementSucceeded' -and $r.OriginalRemoved -and $r.ConnectivityVerified -and $r.ArcVerified) 'Replacement incomplete.'
        Assert ($f.Hosts.Count -eq 2 -and @($f.Hosts | Where-Object Id -EQ $f.SourceId).Count -eq 0) 'Wrong host NIC removed.'
        $g = @($f.Guests | Where-Object InterfaceIndex -EQ 12)[0]
        Assert ($g.IPv4[0].IPAddress -eq '192.0.2.20' -and $g.InterfaceMetric -eq 25 -and $g.NlMtu -eq 1400 -and
            $g.Routes[0].NextHop -eq '192.0.2.1' -and $g.Routes[0].RouteMetric -eq 9 -and $g.DnsSuffix -eq 'lab.invalid' -and
            ($g.DnsServers -join ',') -eq '192.0.2.53,192.0.2.54' -and $g.Dhcp -eq 'Disabled') 'Settings were not transferred.'
        Assert ($f.Events.IndexOf('GuestRemoveIP:7') -lt $f.Events.IndexOf('GuestNewIP:12') -and
            $f.Events.IndexOf('ConnectivityVerified') -lt $f.Events.IndexOf('RemoveOriginal')) 'Unsafe cutover ordering.'
        $put = @($f.Calls | Where-Object Method -EQ 'PUT')[0]
        Assert ($put.Body.properties.ipConfigurations[0].properties.privateIPAddress -eq '192.0.2.20' -and
            $put.Body.properties.createFromLocal -eq $false) 'Wrong Azure NIC allocation.'
        Assert (-not $put.Body.properties.ipConfigurations[0].properties.ContainsKey('gateway') -and
            -not $put.Body.properties.ipConfigurations[0].properties.ContainsKey('prefixLength')) 'Read-only NIC fields submitted.'
        Assert (@($f.Calls | Where-Object { $_.Uri -match 'Microsoft.AzureStackHCI/' -and $_.Uri -notmatch 'api-version=2026-04-01-preview$' }).Count -eq 0) 'Old API version used.'
    }
    Test-Case 'Backup is durable, preserves original identities and excludes credentials' {
        $f = Fixture
        $text = Get-Content -LiteralPath $f.BackupPath -Raw
        $backup = $text | ConvertFrom-Json
        Assert ($backup.OriginalHostNic.Id -eq $f.SourceId -and $backup.OriginalGuestNic.InterfaceIndex -eq 7 -and
            $backup.OriginalGuestNic.IPv4[0].IPAddress -eq '192.0.2.20') 'Incomplete backup.'
        Assert ($text -notmatch 'offline-mock-password|Authorization|SecureString|PSCredential') 'Credentials leaked.'
    }
    Test-Case 'TCP probe accepts the Windows CIM source-address shape' {
        Reset-Fixture -Scenario CimSource
        $r = Execute-Fixture
        Assert ($r.OriginalRemoved -and $r.Connectivity.SourceAddress -eq '192.0.2.20' -and
            $r.Connectivity.InterfaceAlias -eq 'Ethernet 12') 'CIM source address not verified.'
    }
    Test-Case 'TCP probe accepts a System.Net.IPAddress source address' {
        Reset-Fixture -Scenario IPAddressSource
        $r = Execute-Fixture
        Assert ($r.OriginalRemoved -and $r.ConnectivityVerified) 'IPAddress source not verified.'
    }
    foreach ($probeScenario in @('WrongCimSource', 'MissingCimSource', 'NullSource')) {
        Test-Case "TCP probe refuses $probeScenario before original removal" {
            Reset-Fixture -Scenario $probeScenario
            $errorRecord = Assert-Throws { Execute-Fixture } 'DNS/TCP443'
            Assert (-not ('RemoveOriginal' -in (Fixture).Events)) 'Unverified source allowed original removal.'
        }
    }
    Test-Case 'Explicit attached-NIC reuse avoids Azure creation and VM patch' {
        Reset-Fixture -Reuse
        $r = Execute-Fixture
        Assert ($r.OriginalRemoved -and $r.CreatedResourceIds.Count -eq 0) 'Reuse failed.'
        Assert (@((Fixture).Calls | Where-Object Method -NE 'GET').Count -eq 0) 'Reuse modified Azure resources.'
    }
    Test-Case 'DHCP conversion requires explicit approval and produces a static lease address' {
        Reset-Fixture
        (Fixture).Guests[0].Dhcp = 'Enabled'
        $null = Assert-Throws { Execute-Fixture } 'ConvertDhcpToStatic'
        Assert-NoMutation
        $r = Execute-Fixture -ConvertDhcpToStatic
        Assert ($r.OriginalRemoved -and (Fixture).Guests[1].Dhcp -eq 'Disabled') 'DHCP conversion failed.'
    }
    Test-Case 'Out-of-pool address is rejected without modifying pools or allocating a NIC' {
        Reset-Fixture
        (Fixture).Guests[0].IPv4[0].IPAddress = '192.0.2.250'
        $null = Assert-Throws { Execute-Fixture } 'outside.*pool'
        Assert-NoMutation
    }
    Test-Case 'An explicitly approved pool address replaces an out-of-pool original IP' {
        Reset-Fixture
        $f = Fixture; $f.Guests[0].IPv4[0].IPAddress = '192.0.2.250'; $f.DesiredIP = '192.0.2.30'
        $r = Execute-Fixture -PrivateIPAddress '192.0.2.30'
        $backup = Get-Content -LiteralPath $f.BackupPath -Raw | ConvertFrom-Json
        Assert ($r.PrivateIPAddress -eq '192.0.2.30' -and $backup.OriginalGuestNic.IPv4[0].IPAddress -eq '192.0.2.250') 'IP override or original backup lost.'
    }
    Test-Case 'Automatic interface metric mode is retained' {
        Reset-Fixture
        (Fixture).Guests[0].AutomaticMetric = 'Enabled'
        $r = Execute-Fixture
        Assert ($r.OriginalRemoved -and (Fixture).Guests[1].AutomaticMetric -eq 'Enabled') 'Automatic metric lost.'
    }
    Test-Case 'VM without any Azure NIC references preserves unrelated local NICs' {
        Reset-Fixture; (Fixture).Refs = @()
        $r = Execute-Fixture
        Assert ($r.OriginalRemoved -and (Fixture).Refs.Count -eq 1 -and (Fixture).Hosts.Count -eq 2) 'Empty references failed.'
    }
    Test-Case 'A reused target must have exactly the desired Azure IP configuration' {
        Reset-Fixture -Reuse
        $null = Assert-Throws { Execute-Fixture -PrivateIPAddress '192.0.2.30' } 'IP/prefix/gateway'
        Assert-NoMutation
    }
    Test-Case 'IP already present on an unrelated guest adapter is refused' {
        Reset-Fixture
        $null = Assert-Throws { Execute-Fixture -PrivateIPAddress '192.0.2.80' } 'another guest NIC'
        Assert-NoMutation
    }
    Test-Case 'Invalid guest interface GUID is refused instead of being used for cutover' {
        Reset-Fixture
        (Fixture).Guests[0].InterfaceGuid = 'invalid-guid'
        $null = Assert-Throws { Execute-Fixture } 'Guest interface GUID'
        Assert-NoMutation
    }
    Test-Case 'Unreported optional network and pool types warn and require authoritative Azure allocation' {
        Reset-Fixture 'LegacyNetworkShape'
        $output = @(& { Execute-Fixture } 3>&1)
        $warnings = @($output | Where-Object { $_ -is [System.Management.Automation.WarningRecord] })
        $result = @($output | Where-Object { $_ -isnot [System.Management.Automation.WarningRecord] })
        Assert ($warnings.Count -eq 2 -and $result[0].OriginalRemoved) 'Optional fields were fabricated or accepted silently.'
    }
    foreach ($scenario in @('InfrastructureNetwork', 'VipPool', 'UnknownPoolType')) {
        Test-Case "$scenario is never accepted as a VM allocation pool" {
            Reset-Fixture $scenario
            $null = Assert-Throws { Execute-Fixture } 'workload|outside.*pool|Unknown.*pool type'
            Assert-NoMutation
        }
    }
    foreach ($scenario in @('Team', 'IPv6', 'IPv6Dns', 'MultipleIPv4', 'ExtraRoute', 'SourceManaged', 'WrongVm', 'Trunk', 'WrongPrefix', 'Forwarding')) {
        Test-Case "$scenario fails closed before any mutation" {
            Reset-Fixture $scenario
            $f = Fixture
            switch ($scenario) {
                'IPv6' { $f.Guests[0].GlobalIPv6 = @('2001:db8::1') }
                'IPv6Dns' { $f.Guests[0].DnsServers += '2001:db8::53' }
                'MultipleIPv4' { $f.Guests[0].IPv4 += $f.Guests[0].IPv4[0] }
                'ExtraRoute' { $f.Guests[0].Routes += [pscustomobject]@{ DestinationPrefix = '198.51.100.0/24'; NextHop = '192.0.2.1'; RouteMetric = 1; Protocol = 'NetMgmt' } }
                'Trunk' { $f.Hosts[0].VlanMode = 'Trunk' }
                'WrongPrefix' { $f.Guests[0].IPv4[0].PrefixLength = 16 }
                'Forwarding' { $f.Guests[0].Forwarding = 'Enabled' }
            }
            $null = Assert-Throws { Execute-Fixture } 'teaming|IPv6|IPv4|additional|Azure-managed|identity|VLAN|prefix'
            Assert-NoMutation
        }
    }
    foreach ($scenario in @('CreateFailure', 'ProvisionFailed', 'EmptyMac', 'DuplicateMac', 'WrongGateway', 'PatchConflict', 'EtagRace', 'ExtraAdapter', 'SourceChanged', 'NoRealization', 'LostReference')) {
        Test-Case "$scenario retains original adapter and original IP configuration" {
            Reset-Fixture $scenario; $f = Fixture
            $errorRecord = Assert-Throws { Execute-Fixture } 'NIC replacement failed'
            Assert-OriginalRetained
            Assert (-not $errorRecord.Exception.Data['NicReplacementReport'].GuestCutoverAttempted -and
                $f.Guests[0].IPv4[0].IPAddress -eq '192.0.2.20') 'Original guest network changed too early.'
        }
    }
    foreach ($scenario in @('GuestFailure', 'ConnectivityFailure', 'WrongSource', 'WrongAlias', 'DuplicateAddress', 'ArcFailure', 'OtherGuestChanged', 'OtherHostChanged')) {
        Test-Case "$scenario reports partial cutover and never removes the original adapter" {
            Reset-Fixture $scenario
            $errorRecord = Assert-Throws { Execute-Fixture } 'NIC replacement failed'
            $report = $errorRecord.Exception.Data['NicReplacementReport']
            Assert-OriginalRetained
            Assert ($report.GuestCutoverAttempted -and -not $report.OriginalRemovalAttempted -and
                (Test-Path -LiteralPath $report.BackupPath)) 'Partial state or backup missing.'
        }
    }
    Test-Case 'Failure after removal explicitly reports that the original adapter is already gone' {
        Reset-Fixture 'PostDeleteFailure'
        $errorRecord = Assert-Throws { Execute-Fixture } 'after removal'
        $report = $errorRecord.Exception.Data['NicReplacementReport']
        Assert ($report.Status -eq 'Failed' -and $report.OriginalRemoved -and $report.OriginalRemovalAttempted -and
            $report.BeforeRemovalVerified -and -not $report.AfterRemovalVerified -and -not $report.ConnectivityVerified) 'Irreversible partial state hidden.'
    }
    Test-Case 'Existing resources require explicit reuse of an attached NIC' {
        Reset-Fixture; (Fixture).NicExists = $true
        $null = Assert-Throws { Execute-Fixture } 'already exists'
        Assert-NoMutation
        Reset-Fixture -Reuse; (Fixture).Refs = @((Fixture).OtherNicId)
        $null = Assert-Throws { Execute-Fixture } 'already attached'
        Assert-NoMutation
    }
    Test-Case 'An existing backup is never overwritten and blocks live access' {
        Reset-Fixture
        $f = Fixture
        [IO.File]::WriteAllText($f.BackupPath, 'existing-backup')
        $null = Assert-Throws { Execute-Fixture } 'already exists'
        Assert ($f.Reads -eq 0 -and (Get-Content -LiteralPath $f.BackupPath -Raw) -eq 'existing-backup') 'Backup overwritten.'
    }
    Test-Case 'Backup write failure prevents Azure and guest changes' {
        Reset-Fixture
        $f = Fixture; $f.BackupPath = Join-Path (Join-Path $testDirectory 'nonexistent') 'backup.json'
        $null = Assert-Throws { Execute-Fixture } 'backup'
        Assert-NoMutation
    }
    Test-Case 'Source NIC from another VM is rejected without contacting any service' {
        Reset-Fixture; $f = Fixture
        $null = Assert-Throws { Invoke-AzureLocalVmNicReplacement $f.Config 'Microsoft:wrong\wrong' $f.LnetId } 'SourceNetworkAdapterId'
        Assert ($f.Reads -eq 0) 'Invalid ID caused live reads.'
    }
    Test-Case 'Unified source and pool preflight uses the actual host guest and pool validation without mutation' {
        Reset-Fixture
        $f = Fixture
        $replacement = Invoke-AzureLocalVmNicReplacement $f.Config $f.SourceId $f.LnetId -BackupPath $f.BackupPath
        & $module {
            param($f,$credential,$replacement)
            Test-LabSetupNicPreflight $f.Config @{} $null $credential $replacement
        } $f $credential $replacement
        Assert-NoMutation
        Assert (-not (Test-Path -LiteralPath $f.BackupPath)) 'Preflight wrote backup.'
    }
    Test-Case 'Unified actual preflight rejects DHCP without consent and invalid source or pool' {
        foreach ($scenario in @('Dhcp','Source','Pool','Backup')) {
            Reset-Fixture
            $f = Fixture
            $replacement = Invoke-AzureLocalVmNicReplacement $f.Config $f.SourceId $f.LnetId -BackupPath $f.BackupPath
            switch ($scenario) {
                Dhcp { $f.Guests[0].Dhcp = 'Enabled' }
                Source { $replacement.SourceNetworkAdapterId = 'missing' }
                Pool { $f.Guests[0].IPv4[0].IPAddress = '192.0.2.250' }
                Backup { [IO.File]::WriteAllText($f.BackupPath, 'existing') }
            }
            $null = Assert-Throws {
                & $module {
                    param($f,$credential,$replacement)
                    Test-LabSetupNicPreflight $f.Config @{} $null $credential $replacement
                } $f $credential $replacement
            } 'DHCP|absent|pool|BackupPath'
            Assert-NoMutation
        }
    }
    Test-Case 'Relative backup paths resolve against the caller PowerShell location' {
        Reset-Fixture
        $f = Fixture
        $f.BackupPath = '.\relative-backup.json'
        Push-Location $testDirectory
        try {
            $r = Execute-Fixture
            Assert ($r.OriginalRemoved -and $r.BackupPath -eq (Join-Path $testDirectory 'relative-backup.json') -and
                (Test-Path -LiteralPath '.\relative-backup.json')) 'Backup used process working directory instead of PowerShell location.'
        } finally { Pop-Location }
    }
    Test-Case 'Explicit April API propagates through NIC creation attachment and final verification' {
        Reset-Fixture
        $f = Fixture
        $f.Config.StackHciApiVersion = '2026-07-01-preview'
        $r = Execute-Fixture
        Assert ($r.OriginalRemoved -and $r.ApiVersion -eq '2026-07-01-preview' -and
            @($f.Calls | Where-Object { $_.Uri -match 'Microsoft.AzureStackHCI/' -and
                $_.Uri -notlike '*api-version=2026-07-01-preview' }).Count -eq 0) 'Replacement mixed API versions.'
    }
    Test-Case 'Portable CLI forwards new version, target ID and WhatIf without infrastructure access' {
        Reset-Fixture; $f = Fixture
        foreach ($automatic in @($false,$true)) {
            $cli = @{ LogicalNetworkId = $f.LnetId }
            if (-not $automatic) { $cli.SourceNetworkAdapterId = $f.SourceId }
            $json = & (Join-Path $root 'tools\Replace-AzureLocalVmNic.ps1') -ConfigurationPath (Join-Path $root 'examples\registration.example.json') `
                @cli -Execute -EnableUnsupportedLabPreview -AcceptNetworkInterruption -WhatIf
            $p = $json | ConvertFrom-Json
            Assert ($p.Status -eq 'NotExecuted' -and $p.ApiVersion -eq '2026-04-01-preview') 'CLI arguments lost.'
            Assert ($p.SourceSelection -eq $(if ($automatic) { 'AutoSingleAdapter' } else { 'ExplicitId' })) 'CLI source mode lost.'
        }
    }
    Test-Case 'Standalone replacement CLI accepts the network exclusively from configuration' {
        $json = & (Join-Path $root 'tools\Replace-AzureLocalVmNic.ps1') -ConfigurationPath (Join-Path $root 'examples\registration.example.json')
        $r = $json | ConvertFrom-Json
        Assert ($r.Status -eq 'PlanOnly' -and $r.LogicalNetworkId -ceq $example.LogicalNetworkId) 'CLI did not use the JSON network.'
    }
    Write-Host "Passed $passed offline NIC replacement cases."
} finally {
    $credential.Password.Dispose()
    Remove-Item -LiteralPath $testDirectory -Recurse -Force
}
