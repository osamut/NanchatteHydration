#Requires -Version 5.1
[CmdletBinding(SupportsShouldProcess, ConfirmImpact = 'High')]
param(
    [Parameter(Mandatory)][string]$ConfigurationPath,
    [pscredential]$GuestCredential,
    [System.Management.Automation.Runspaces.PSSession]$OwnerNodeSession,
    [switch]$RegistrationAlreadyComplete,
    [switch]$ReplaceExistingNetworkAdapter,
    [string]$SourceNetworkAdapterId,
    [string]$LogicalNetworkId,
    [string]$NetworkInterfaceName,
    [string]$PrivateIPAddress,
    [string]$BackupPath,
    [string]$ConnectivityTestHost = 'management.azure.com',
    [switch]$ReuseAttachedNetworkInterface,
    [switch]$ConvertDhcpToStatic,
    [switch]$AcceptNetworkInterruption,
    [string]$ReportPath,
    [switch]$Execute,
    [switch]$EnableUnsupportedLabPreview,
    [ValidateRange(1, 3600)][int]$TimeoutSeconds = 600,
    [ValidateRange(1, 60)][int]$PollSeconds = 5
)
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot 'AzureLocalVmRegistration.psm1') -Force
$parsed = Get-Content -LiteralPath $ConfigurationPath -Raw | ConvertFrom-Json
if ($null -eq $parsed -or $parsed -isnot [pscustomobject]) { throw 'Configuration must be a JSON object.' }
$configuration = @{}
foreach ($property in $parsed.PSObject.Properties) { $configuration[$property.Name] = $property.Value }
$arguments = @{ Configuration = $configuration }
foreach ($key in $PSBoundParameters.Keys) {
    if ($key -ne 'ConfigurationPath') { $arguments[$key] = $PSBoundParameters[$key] }
}
try {
    Invoke-AzureLocalVmSetup @arguments | ConvertTo-Json -Depth 35
} catch {
    $report = $_.Exception.Data['SetupReport']
    if ($null -ne $report) { Write-Error ($report | ConvertTo-Json -Depth 35) -ErrorAction Continue }
    throw
}
