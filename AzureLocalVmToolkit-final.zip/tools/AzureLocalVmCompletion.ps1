#Requires -Version 5.1

function Get-LabItems($Object, [string]$Name) {
    $values = Get-Field $Object $Name
    if ($null -eq $values) { return }
    if ($values -isnot [array]) { throw "Expected an array for $Name." }
    foreach ($value in $values) { $value }
}

function New-AzureLocalVmCompletionPlan {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][System.Collections.IDictionary]$Configuration,
        [string]$LogicalNetworkId,
        [switch]$AddNetworkInterface,
        [switch]$ConfigureGuestNetwork,
        [switch]$EnableGuestManagement
    )
    $registration = New-AzureLocalVmRegistrationPlan $Configuration
    if (-not ($AddNetworkInterface -or $ConfigureGuestNetwork -or $EnableGuestManagement)) { throw 'Select at least one completion action.' }
    if (($ConfigureGuestNetwork -or $EnableGuestManagement) -and $Configuration.OsType -ne 'Windows') {
        throw 'Automated guest completion supports Windows guests only.'
    }
    if ($AddNetworkInterface -or $ConfigureGuestNetwork) {
        $LogicalNetworkId = Resolve-LabLogicalNetworkId $Configuration $LogicalNetworkId
    }
    $nicId = $null
    if ($AddNetworkInterface -or $ConfigureGuestNetwork) {
        $nicId = "/subscriptions/$($Configuration.SubscriptionId)/resourceGroups/$($Configuration.ResourceGroup)/providers/Microsoft.AzureStackHCI/networkInterfaces/$($Configuration.MachineName)-nic0"
    }
    $impact = @()
    if ($AddNetworkInterface) { $impact += 'Adds a new adapter, not an adoption of the old adapter.' }
    if ($ConfigureGuestNetwork) { $impact += 'Changes guest IP/DNS settings only on the selected Azure NIC MAC.' }
    if (-not ($AddNetworkInterface -or $ConfigureGuestNetwork)) { $impact += 'Uses existing Hyper-V networking without adding adapters or changing IP/DNS, MAC, routes or switch settings. Does not project the existing NIC as an Azure-managed NIC.' }
    if ($EnableGuestManagement) { $impact += 'Installs guest agents using the existing parent machine. Connectivity without an Azure-managed NIC is unverified; failure never triggers automatic NIC creation.' }
    $impact += 'Never deletes resources or powers off/restarts the VM.'
    $requests = @()
    if ($AddNetworkInterface) {
        $requests += [pscustomobject]@{
            Method = 'PUT'; ResourceId = $nicId; ApiVersion = $script:VmApi
            Body = @{
                location = $Configuration.Location
                extendedLocation = @{ name = $Configuration.CustomLocationId; type = 'CustomLocation' }
                properties = @{
                    createFromLocal = $false
                    ipConfigurations = @(@{ name = 'ipconfig0'; properties = @{ subnet = @{ id = $LogicalNetworkId } } })
                }
            }
        }
        $requests += [pscustomobject]@{
            Method = 'PATCH'; ResourceId = $registration.VirtualMachineInstanceId; ApiVersion = $script:VmApi
            MergeExistingNetworkInterfaces = $true
            Body = @{ properties = @{ networkProfile = @{ networkInterfaces = @(@{ id = $nicId }) } } }
        }
    }
    if ($EnableGuestManagement) {
        foreach ($flags in @(@{ provisionVMConfigAgent = $true }, @{ provisionVMConfigAgent = $true; provisionVMAgent = $true })) {
            $requests += [pscustomobject]@{
                Method = 'PATCH'; ResourceId = $registration.VirtualMachineInstanceId; ApiVersion = $script:VmApi
                Body = @{ properties = @{ osProfile = @{ windowsConfiguration = $flags } } }
            }
        }
    }
    [pscustomobject]@{
        Status = 'PlanOnly'; Warning = $script:Risk; LiveReadsPerformed = $false; ApiVersion = $script:VmApi
        MachineId = $registration.MachineId; VirtualMachineInstanceId = $registration.VirtualMachineInstanceId
        NetworkInterfaceId = $nicId; LogicalNetworkId = $LogicalNetworkId
        ExpectedVmId = Get-LabConfiguredVmId $Configuration; LocalHost = Get-LabConfiguredHost $Configuration
        AddNetworkInterface = [bool]$AddNetworkInterface; ConfigureGuestNetwork = [bool]$ConfigureGuestNetwork
        EnableGuestManagement = [bool]$EnableGuestManagement
        Impact = $impact -join ' '
        Requests = $requests
        RequestNote = 'PATCH bodies are templates. Execution preserves existing NIC references and uses current ETags. Existing, unattached or failed NIC resources are refused.'
    }
}

function Read-LabCompletionVm($Configuration, $Plan, $Context) {
    $response = Invoke-LabArmRequest GET "$script:Arm$($Plan.VirtualMachineInstanceId)?api-version=$script:VmApi" $null $Context $Configuration.SubscriptionId
    Assert-Response $response
    $vm = $response.Body
    if (-not $Configuration.Contains('ExpectedVmId')) { throw 'VM UUID was not resolved before reading the Azure VM; refusing.' }
    $properties = Get-Field $vm 'properties'
    if ((Get-Field $vm 'id') -ine $Plan.VirtualMachineInstanceId -or
        (Get-Field $properties 'hyperVVmId') -ine $Configuration.ExpectedVmId -or
        (Get-Field $properties 'localVmName') -ine $Configuration.LocalVmName -or
        (Get-Field (Get-Field $vm 'extendedLocation') 'name') -ine $Configuration.CustomLocationId) {
        throw 'Existing Azure VM identity differs from configuration.'
    }
    return $response
}

function Update-LabCompletionVm($Configuration, $Plan, $Context, $OwnerNodeSession, $Properties, [int]$TimeoutSeconds, [int]$PollSeconds, [string]$ExpectedETag) {
    Assert-LocalVm $Configuration $OwnerNodeSession
    $current = Read-LabCompletionVm $Configuration $Plan $Context
    if ((Get-Field (Get-Field $current.Body 'properties') 'provisioningState') -ne 'Succeeded') {
        throw 'Existing VM is not successfully provisioned; refusing update.'
    }
    $etag = [string](Get-Field $current.Headers 'ETag')
    if ($ExpectedETag -and $etag -cne $ExpectedETag) { throw 'VM ETag changed while preparing NIC attachment; refusing racing update.' }
    $response = Invoke-LabArmRequest PATCH "$script:Arm$($Plan.VirtualMachineInstanceId)?api-version=$script:VmApi" `
        @{ properties = $Properties } $Context $Configuration.SubscriptionId ([Math]::Min(30, $TimeoutSeconds)) $etag
    Assert-Response $response
    $null = Wait-LabProvisioning $response $Plan.VirtualMachineInstanceId $script:VmApi $Context $Configuration.SubscriptionId $TimeoutSeconds $PollSeconds
    $null = Read-LabCompletionVm $Configuration $Plan $Context
}

function Invoke-LabGuest($Configuration, $OwnerNodeSession, [pscredential]$Credential, [scriptblock]$Command, [object[]]$Arguments = @()) {
    Assert-LocalVm $Configuration $OwnerNodeSession
    $hostCommand = {
        param($HostName, $VmId, $VmName, $Credential, $CommandText, $GuestArguments)
        $ErrorActionPreference = 'Stop'
        $vm = Get-VM -Id ([guid]$VmId) -ErrorAction Stop
        if (($HostName -and $env:COMPUTERNAME -ine $HostName) -or $vm.Name -ine $VmName) { throw 'Guest command host/VM identity mismatch.' }
        Invoke-Command -VMId $vm.Id -Credential $Credential -ScriptBlock ([scriptblock]::Create($CommandText)) `
            -ArgumentList $GuestArguments -ErrorAction Stop
    }
    $hostArguments = @((Get-LabHostArgument $Configuration), $Configuration.ExpectedVmId, $Configuration.LocalVmName, $Credential, $Command.ToString(), $Arguments)
    if ($null -ne $OwnerNodeSession) {
        return Invoke-Command -Session $OwnerNodeSession -ScriptBlock $hostCommand -ArgumentList $hostArguments -ErrorAction Stop
    }
    return & $hostCommand @hostArguments
}

function Assert-LabIpv4([string]$Value, [string]$Field) {
    $address = $null
    if (-not [Net.IPAddress]::TryParse($Value, [ref]$address) -or $address.AddressFamily -ne [Net.Sockets.AddressFamily]::InterNetwork) {
        throw "Missing or invalid IPv4 value: $Field."
    }
}

function Test-LabGuestAccess($Configuration, $OwnerNodeSession, $Credential) {
    $node = Read-LabNodeIdentity $Configuration $OwnerNodeSession
    if ($node.VMs[0].Generation -ne 2 -or [string]$node.VMs[0].State -ne 'Running') {
        throw 'Completion supports running Generation 2 VMs only; no power operations are performed.'
    }
    Invoke-LabGuest $Configuration $OwnerNodeSession $Credential {
        $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
        if (-not ([Security.Principal.WindowsPrincipal]::new($identity)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { throw 'Guest administrator privileges required.' }
        $os = Get-CimInstance Win32_OperatingSystem -ErrorAction Stop
        if ([version]$os.Version -lt [version]'10.0' -or $os.OSArchitecture -notmatch '64') { throw 'Guest completion requires a supported 64-bit Windows OS with Hyper-V sockets.' }
        [pscustomobject]@{ Caption = $os.Caption; Version = $os.Version }
    }
}

function Set-LabGuestNetwork($Configuration, $OwnerNodeSession, $Credential, $Nic, $LogicalNetwork) {
    $properties = Get-Field $Nic 'properties'
    $ipConfigurations = @(Get-LabItems $properties 'ipConfigurations')
    if ($ipConfigurations.Count -ne 1) { throw 'Guest network configuration requires exactly one NIC IP configuration.' }
    $ip = Get-Field $ipConfigurations[0] 'properties'
    $mac = [string](Get-Field $properties 'macAddress')
    $mac = $mac -replace '[:-]', ''
    if ($mac -notmatch '^[0-9a-f]{12}$') { throw 'NIC MAC is missing or invalid.' }
    $address = [string](Get-Field $ip 'privateIPAddress')
    $gateway = [string](Get-Field $ip 'gateway')
    Assert-LabIpv4 $address 'NIC privateIPAddress'
    Assert-LabIpv4 $gateway 'NIC gateway'
    $prefix = 0
    if (-not [int]::TryParse([string](Get-Field $ip 'prefixLength'), [ref]$prefix) -or $prefix -lt 1 -or $prefix -gt 32) { throw 'NIC prefix length missing or invalid.' }
    $dns = @(Get-LabItems (Get-Field (Get-Field $LogicalNetwork 'properties') 'dhcpOptions') 'dnsServers')
    if ($dns.Count -eq 0) { throw 'Logical network DNS servers missing; refusing to guess guest settings.' }
    foreach ($server in $dns) { Assert-LabIpv4 $server 'DNS server' }
    Invoke-LabGuest $Configuration $OwnerNodeSession $Credential {
        param($Mac, $Address, $Prefix, $Gateway, $Dns)
        $ErrorActionPreference = 'Stop'
        $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
        if (-not ([Security.Principal.WindowsPrincipal]::new($identity)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { throw 'Guest administrator privileges required.' }
        $adapters = @(Get-NetAdapter -ErrorAction Stop | Where-Object { ($_.MacAddress -replace '[:-]', '') -ieq $Mac })
        if ($adapters.Count -ne 1) { throw 'New NIC MAC is absent or ambiguous in guest.' }
        $index = $adapters[0].InterfaceIndex
        $before = @(Get-NetIPAddress -AddressFamily IPv4 -ErrorAction Stop | Where-Object InterfaceIndex -NE $index |
            Sort-Object InterfaceIndex, IPAddress | Select-Object InterfaceIndex, IPAddress, PrefixLength)
        Set-NetIPInterface -InterfaceIndex $index -AddressFamily IPv4 -Dhcp Disabled -InterfaceMetric 100 -ErrorAction Stop
        Get-NetIPAddress -AddressFamily IPv4 -ErrorAction Stop | Where-Object { $_.InterfaceIndex -eq $index -and $_.IPAddress -ne $Address } |
            Remove-NetIPAddress -Confirm:$false -ErrorAction Stop
        if (-not (Get-NetIPAddress -AddressFamily IPv4 -ErrorAction Stop | Where-Object { $_.InterfaceIndex -eq $index -and $_.IPAddress -eq $Address -and $_.PrefixLength -eq $Prefix })) {
            Get-NetIPAddress -AddressFamily IPv4 -ErrorAction Stop | Where-Object InterfaceIndex -EQ $index | Remove-NetIPAddress -Confirm:$false -ErrorAction Stop
            $null = New-NetIPAddress -InterfaceIndex $index -IPAddress $Address -PrefixLength $Prefix -ErrorAction Stop
        }
        $routes = @(Get-NetRoute -AddressFamily IPv4 -ErrorAction Stop | Where-Object { $_.InterfaceIndex -eq $index -and $_.DestinationPrefix -eq '0.0.0.0/0' })
        $routes | Where-Object NextHop -NE $Gateway | Remove-NetRoute -Confirm:$false -ErrorAction Stop
        if (-not ($routes | Where-Object NextHop -EQ $Gateway)) {
            $null = New-NetRoute -InterfaceIndex $index -DestinationPrefix '0.0.0.0/0' -NextHop $Gateway -ErrorAction Stop
        }
        Set-DnsClientServerAddress -InterfaceIndex $index -ServerAddresses $Dns -ErrorAction Stop
        $after = @(Get-NetIPAddress -AddressFamily IPv4 -ErrorAction Stop | Where-Object InterfaceIndex -NE $index |
            Sort-Object InterfaceIndex, IPAddress | Select-Object InterfaceIndex, IPAddress, PrefixLength)
        if (($before | ConvertTo-Json -Compress) -cne ($after | ConvertTo-Json -Compress)) { throw 'Another adapter IPv4 configuration changed during the operation.' }
        $actual = @(Get-NetIPAddress -InterfaceIndex $index -AddressFamily IPv4 -ErrorAction Stop)
        if (-not ($actual | Where-Object { $_.IPAddress -eq $Address -and $_.PrefixLength -eq $Prefix })) { throw 'New guest NIC address verification failed.' }
        [pscustomobject]@{ MacAddress = $Mac; IPv4 = $Address; PrefixLength = $Prefix; OtherAdaptersUnchanged = $true }
    } @($mac, $address, $prefix, $gateway, $dns)
}

function Install-LabGuestConfigAgent($Configuration, $OwnerNodeSession, $Credential) {
    Invoke-LabGuest $Configuration $OwnerNodeSession $Credential {
        $ErrorActionPreference = 'Stop'
        $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
        if (-not ([Security.Principal.WindowsPrincipal]::new($identity)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { throw 'Guest administrator privileges required.' }
        $service = @(Get-Service -ErrorAction Stop | Where-Object Name -EQ 'mocguestagent')
        if ($service.Count -eq 1 -and $service[0].Status -eq 'Running') { return }
        $volumes = @(Get-Volume -FileSystemLabel mocguestagentprov -ErrorAction Stop)
        if ($volumes.Count -ne 1 -or -not $volumes[0].DriveLetter) { throw 'Official guest-agent ISO is not mounted.' }
        $installer = Join-Path ($volumes[0].DriveLetter + ':\') 'install.ps1'
        if (-not (Test-Path -LiteralPath $installer)) { throw 'Official ISO installer missing.' }
        & powershell.exe -NoProfile -NonInteractive -File $installer | Out-Null
        if ($LASTEXITCODE -ne 0) { throw "Official guest agent installer failed (exit $LASTEXITCODE)." }
        $service = Get-Service mocguestagent -ErrorAction Stop
        if ($service.Status -ne 'Running') { throw 'VM configuration agent service is not running.' }
    }
}

function Wait-LabGuestConnected($Configuration, $Plan, $Context, [string]$Agent, [int]$TimeoutSeconds, [int]$PollSeconds) {
    $clock = [Diagnostics.Stopwatch]::StartNew()
    do {
        if ($Agent -eq 'Config') {
            $current = Read-LabCompletionVm $Configuration $Plan $Context
            $properties = Get-Field $current.Body 'properties'
            $view = Get-Field (Get-Field $properties 'instanceView') 'vmAgent'
            $statuses = @(Get-LabItems $view 'statuses')
            if (@($statuses | Where-Object {
                (Get-Field $_ 'displayStatus') -in @('Failed', 'Canceled') -or (Get-Field $_ 'code') -match '/(failed|canceled)$'
            }).Count -gt 0) {
                throw "Configuration agent failed or canceled: $($view | ConvertTo-Json -Depth 10 -Compress)"
            }
            $connected = @($statuses | Where-Object { (Get-Field $_ 'displayStatus') -in @('Connected', 'Active') }).Count -gt 0
        } else {
            $machine = Read-LabResource $Plan.MachineId $script:MachineApi $Context $Configuration.SubscriptionId
            $properties = Get-Field $machine 'properties'
            $connected = (Get-Field $properties 'status') -eq 'Connected'
        }
        if ((Get-Field $properties 'provisioningState') -in @('Failed', 'Canceled')) {
            throw "$Agent resource failed or canceled: $($properties | ConvertTo-Json -Depth 10 -Compress)"
        }
        if ($connected) {
            if ($Agent -eq 'Config') { return $view }
            return $properties
        }
        $remaining = $TimeoutSeconds - $clock.Elapsed.TotalSeconds
        if ($remaining -le 0) { throw "Timeout waiting for $Agent guest agent connection. Server operations may still be running." }
        Wait-LabDelay ([int][Math]::Min($PollSeconds, [Math]::Ceiling($remaining)))
    } while ($true)
}

function Invoke-AzureLocalVmCompletion {
    [CmdletBinding(SupportsShouldProcess, ConfirmImpact = 'High')]
    param(
        [Parameter(Mandatory)][System.Collections.IDictionary]$Configuration,
        [string]$LogicalNetworkId,
        [switch]$AddNetworkInterface,
        [switch]$ConfigureGuestNetwork,
        [switch]$EnableGuestManagement,
        [pscredential]$GuestCredential,
        [System.Management.Automation.Runspaces.PSSession]$OwnerNodeSession,
        [switch]$Execute,
        [switch]$EnableUnsupportedLabPreview,
        [ValidateRange(1, 3600)][int]$TimeoutSeconds = 600,
        [ValidateRange(1, 60)][int]$PollSeconds = 5
    )
    $plan = New-AzureLocalVmCompletionPlan $Configuration $LogicalNetworkId -AddNetworkInterface:$AddNetworkInterface `
        -ConfigureGuestNetwork:$ConfigureGuestNetwork -EnableGuestManagement:$EnableGuestManagement
    $LogicalNetworkId = $plan.LogicalNetworkId
    if (-not $Execute) { return $plan }
    if (-not $EnableUnsupportedLabPreview) { throw 'Execute requires -EnableUnsupportedLabPreview.' }
    if (-not $PSCmdlet.ShouldProcess("$($plan.VirtualMachineInstanceId); owner $(Get-LabConfiguredHost $Configuration); UUID $(Get-LabConfiguredVmId $Configuration); NIC $($plan.NetworkInterfaceId); tenant $($Configuration.TenantId)", "$script:Risk $($plan.Impact)")) {
        $plan.Status = 'NotExecuted'
        return $plan
    }
    $state = [ordered]@{
        Status = 'InProgress'; Stage = 'Preflight'; VmId = $plan.VirtualMachineInstanceId; NicId = $plan.NetworkInterfaceId
        CreatedResourceIds = @(); PotentialResourceIds = @(); ModifiedResourceIds = @()
        NicAttached = $false; GuestNetworkConfigured = $false; GuestArcConnected = $false
    }
    try {
        if (($ConfigureGuestNetwork -or $EnableGuestManagement) -and $null -eq $GuestCredential) { throw 'Selected guest operations require -GuestCredential (Get-Credential); never put a password in JSON.' }
        $context = Get-LabAzureContext $Configuration
        Test-LabInfrastructure $Configuration $context $OwnerNodeSession
        $node = Read-LabNodeIdentity $Configuration $OwnerNodeSession
        if ($node.VMs[0].Generation -ne 2 -or [string]$node.VMs[0].State -ne 'Running') { throw 'Completion supports running Generation 2 VMs only; no power operations are performed.' }
        $parent = Read-LabResource $plan.MachineId $script:MachineApi $context $Configuration.SubscriptionId
        $identity = Get-Field $parent 'identity'
        if ((Get-Field $parent 'kind') -ne 'HCI' -or (Get-Field $parent 'location') -ine $Configuration.Location -or
            (Get-Field $identity 'type') -ne 'SystemAssigned' -or -not (Get-Field $identity 'principalId') -or
            (Get-Field $identity 'tenantId') -ine $Configuration.TenantId) { throw 'Existing parent is not the expected HCI/SystemAssigned machine in the configured tenant/region.' }
        $current = Read-LabCompletionVm $Configuration $plan $context
        if ((Get-Field (Get-Field $current.Body 'properties') 'provisioningState') -ne 'Succeeded') { throw 'VM is not successfully provisioned.' }
        if ($ConfigureGuestNetwork -or $EnableGuestManagement) {
            $state.GuestOS = Test-LabGuestAccess $Configuration $OwnerNodeSession $GuestCredential
        }
        $nic = $null
        $lnet = $null
        if ($AddNetworkInterface -or $ConfigureGuestNetwork) {
            $lnet = Read-LabResource $LogicalNetworkId $script:VmApi $context $Configuration.SubscriptionId
            if ((Get-Field (Get-Field $lnet 'extendedLocation') 'name') -ine $Configuration.CustomLocationId -or
                (Get-Field (Get-Field $lnet 'properties') 'provisioningState') -ne 'Succeeded' -or
                (Get-Field (Get-Field $lnet 'properties') 'networkType') -eq 'Infrastructure') { throw 'Logical network is not a ready workload network in the selected custom location.' }
            $nic = Read-LabResource $plan.NetworkInterfaceId $script:VmApi $context $Configuration.SubscriptionId -AllowNotFound
            $references = @(Get-LabItems (Get-Field (Get-Field $current.Body 'properties') 'networkProfile') 'networkInterfaces')
            $alreadyAttached = @($references | Where-Object { (Get-Field $_ 'id') -ieq $plan.NetworkInterfaceId }).Count -eq 1
            if ($null -ne $nic -and -not $alreadyAttached) { throw 'NIC already exists but is not attached to this VM. Unattached, failed or unrelated resources are never adopted or overwritten.' }
            if ($null -eq $nic -and -not $AddNetworkInterface) { throw 'ConfigureGuestNetwork requires an existing attached NIC; select AddNetworkInterface to create one.' }
            if ($alreadyAttached -and $null -eq $nic) { throw 'VM refers to a missing NIC resource.' }
            if ($null -eq $nic) {
                $state.Stage = 'Create NIC'
                Assert-LocalVm $Configuration $OwnerNodeSession
                if ($null -ne (Read-LabResource $plan.NetworkInterfaceId $script:VmApi $context $Configuration.SubscriptionId -AllowNotFound)) { throw 'NIC appeared after preflight; refusing overwrite.' }
                $state.PotentialResourceIds = @($plan.NetworkInterfaceId)
                $response = Invoke-LabArmRequest PUT "$script:Arm$($plan.NetworkInterfaceId)?api-version=$script:VmApi" $plan.Requests[0].Body $context $Configuration.SubscriptionId ([Math]::Min(30, $TimeoutSeconds))
                Assert-Response $response
                $nic = Wait-LabProvisioning $response $plan.NetworkInterfaceId $script:VmApi $context $Configuration.SubscriptionId $TimeoutSeconds $PollSeconds
                $state.CreatedResourceIds = @($plan.NetworkInterfaceId)
            }
            $nicProperties = Get-Field $nic 'properties'
            $nicIps = @(Get-LabItems $nicProperties 'ipConfigurations')
            if ((Get-Field $nicProperties 'provisioningState') -ne 'Succeeded' -or
                (Get-Field (Get-Field $nic 'extendedLocation') 'name') -ine $Configuration.CustomLocationId -or
                $nicIps.Count -ne 1 -or
                (Get-Field (Get-Field (Get-Field $nicIps[0] 'properties') 'subnet') 'id') -ine $LogicalNetworkId) { throw 'NIC identity, network or provisioning state differs from the selected target.' }
            if (-not $alreadyAttached) {
                $state.Stage = 'Attach NIC'
                $latest = Read-LabCompletionVm $Configuration $plan $context
                $refs = @(Get-LabItems (Get-Field (Get-Field $latest.Body 'properties') 'networkProfile') 'networkInterfaces')
                if (@($refs | Where-Object { (Get-Field $_ 'id') -ieq $plan.NetworkInterfaceId }).Count -ne 0) { throw 'NIC references changed after preflight; refusing racing attachment.' }
                $ids = @($refs | ForEach-Object { @{ id = (Get-Field $_ 'id') } }) + @(@{ id = $plan.NetworkInterfaceId })
                foreach ($id in $ids) { Assert-Id $id.id 'Microsoft.AzureStackHCI/networkInterfaces' $Configuration.SubscriptionId }
                $state.ModifiedResourceIds = @($plan.VirtualMachineInstanceId)
                Update-LabCompletionVm $Configuration $plan $context $OwnerNodeSession @{ networkProfile = @{ networkInterfaces = $ids } } $TimeoutSeconds $PollSeconds ([string](Get-Field $latest.Headers 'ETag'))
                $current = Read-LabCompletionVm $Configuration $plan $context
                $after = @(Get-LabItems (Get-Field (Get-Field $current.Body 'properties') 'networkProfile') 'networkInterfaces')
                if ($after.Count -ne $ids.Count -or @($after | Where-Object { (Get-Field $_ 'id') -ieq $plan.NetworkInterfaceId }).Count -ne 1) { throw 'NIC attachment verification failed.' }
                foreach ($id in $ids) {
                    if (@($after | Where-Object { (Get-Field $_ 'id') -ieq $id.id }).Count -ne 1) { throw 'An existing NIC reference was lost during attachment.' }
                }
            }
            $state.NicAttached = $true
            $state.NicMacAddress = Get-Field $nicProperties 'macAddress'
            $state.NicIPv4 = Get-Field (Get-Field $nicIps[0] 'properties') 'privateIPAddress'
        }
        if ($ConfigureGuestNetwork) {
            $state.Stage = 'Configure new guest NIC'
            $state.GuestNetwork = Set-LabGuestNetwork $Configuration $OwnerNodeSession $GuestCredential $nic $lnet
            $state.GuestNetworkConfigured = $true
        }
        if ($EnableGuestManagement) {
            $state.Stage = 'Mount guest agent ISO'
            $state.ModifiedResourceIds = @($plan.VirtualMachineInstanceId)
            Update-LabCompletionVm $Configuration $plan $context $OwnerNodeSession @{ osProfile = @{ windowsConfiguration = @{ provisionVMConfigAgent = $true } } } $TimeoutSeconds $PollSeconds
            $state.Stage = 'Install guest configuration agent'
            $null = Install-LabGuestConfigAgent $Configuration $OwnerNodeSession $GuestCredential
            $state.Stage = 'Wait for configuration agent'
            $state.ConfigAgent = Wait-LabGuestConnected $Configuration $plan $context 'Config' $TimeoutSeconds $PollSeconds
            $state.Stage = 'Enable Arc guest connection'
            Update-LabCompletionVm $Configuration $plan $context $OwnerNodeSession @{ osProfile = @{ windowsConfiguration = @{ provisionVMConfigAgent = $true; provisionVMAgent = $true } } } $TimeoutSeconds $PollSeconds
            $state.Stage = 'Verify Arc guest connection'
            $arc = Wait-LabGuestConnected $Configuration $plan $context 'Arc' $TimeoutSeconds $PollSeconds
            $state.ArcStatus = Get-Field $arc 'status'
            $state.AgentVersion = Get-Field $arc 'agentVersion'
            $state.GuestService = Invoke-LabGuest $Configuration $OwnerNodeSession $GuestCredential {
                $service = Get-Service himds -ErrorAction Stop
                if ($service.Status -ne 'Running') { throw 'Connected Machine agent service is not running.' }
                [pscustomobject]@{ Name = $service.Name; Status = [string]$service.Status }
            }
            $state.GuestArcConnected = $true
        }
        Assert-LocalVm $Configuration $OwnerNodeSession
        $null = Read-LabCompletionVm $Configuration $plan $context
        $state.Status = 'PreviewCompletionSucceeded'
        $state.Stage = 'Verified'
        $state.Warning = $script:Risk
        [pscustomobject]$state
    } catch {
        $state.Status = 'Failed'
        $state.Message = $_.Exception.Message
        $state.ArmError = $_.Exception.Data['ArmError']
        $state.RequestId = $_.Exception.Data['RequestId']
        $state.ManualAction = 'Inspect listed resources, selected guest NIC and services. Partial guest changes may remain. No resources were deleted or rolled back, and no VM power operation was performed. Do not rerun registration or delete resources blindly.'
        $exception = [InvalidOperationException]::new("Completion failed at $($state.Stage). $($_.Exception.Message)", $_.Exception)
        $exception.Data['CompletionReport'] = $state
        throw $exception
    }
}
