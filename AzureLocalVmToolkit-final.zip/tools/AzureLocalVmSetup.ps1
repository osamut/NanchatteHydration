#Requires -Version 5.1

function Write-LabSetupReport($Stream, $Report) {
    if ($null -eq $Stream) { return }
    $bytes = [Text.UTF8Encoding]::new($false).GetBytes(($Report | ConvertTo-Json -Depth 35))
    $Stream.Position = 0
    $Stream.Write($bytes, 0, $bytes.Length)
    $Stream.SetLength($bytes.Length)
    $Stream.Flush($true)
}

function Test-LabSetupNicPreflight($Configuration, $Context, $OwnerNodeSession, $GuestCredential, $Replacement) {
    if (-not $Replacement.BackupPath -or (Test-Path -LiteralPath $Replacement.BackupPath)) {
        throw 'NIC replacement requires a new BackupPath; inspect existing backups and partial state instead of retrying blindly.'
    }
    $directory = [IO.Path]::GetDirectoryName((Resolve-LabFilePath $Replacement.BackupPath))
    if (-not (Test-Path -LiteralPath $directory -PathType Container)) { throw 'BackupPath parent directory must already exist.' }
    $hosts = @(Invoke-LabNicHost $Configuration $OwnerNodeSession)
    $source = Select-LabSourceNic $hosts $Replacement.SourceNetworkAdapterId $Configuration.ExpectedVmId
    $Replacement.SourceNetworkAdapterId = [string]$source.Id
    $guests = @(Get-LabNicGuestSnapshot $Configuration $OwnerNodeSession $GuestCredential)
    $guest = Get-LabNicByMac $guests (ConvertTo-LabNicMac $source.MacAddress)
    Assert-LabReplacementGuest $guest -Source
    if ($guest.Dhcp -eq 'Enabled' -and -not $Replacement.ConvertDhcpToStatic) { throw 'Original NIC uses DHCP; explicitly approve -ConvertDhcpToStatic.' }
    $address = if ($Replacement.PrivateIPAddress) { $Replacement.PrivateIPAddress } else { $guest.IPv4[0].IPAddress }
    $lnet = Read-LabResource $Replacement.LogicalNetworkId $script:VmApi $Context $Configuration.SubscriptionId
    Assert-LabReplacementPool $lnet $Configuration $source $guest $address
}

function Invoke-AzureLocalVmSetup {
    [CmdletBinding(SupportsShouldProcess, ConfirmImpact = 'High')]
    param(
        [Parameter(Mandatory)][System.Collections.IDictionary]$Configuration,
        [pscredential]$GuestCredential,
        [System.Management.Automation.Runspaces.PSSession]$OwnerNodeSession,
        [switch]$RegistrationAlreadyComplete,
        [switch]$ReplaceExistingNetworkAdapter,
        [string]$SourceNetworkAdapterId,
        [string]$LogicalNetworkId,
        [string]$NetworkInterfaceName,
        [string]$PrivateIPAddress,
        [string]$BackupPath,
        [string]$ConnectivityTestHost = 'management.azure.com',
        [switch]$ReuseAttachedNetworkInterface,
        [switch]$ConvertDhcpToStatic,
        [switch]$AcceptNetworkInterruption,
        [string]$ReportPath,
        [switch]$Execute,
        [switch]$EnableUnsupportedLabPreview,
        [ValidateRange(1, 3600)][int]$TimeoutSeconds = 600,
        [ValidateRange(1, 60)][int]$PollSeconds = 5
    )
    $registration = New-AzureLocalVmRegistrationPlan $Configuration
    if ($Configuration.NetworkInterfaceIds.Count -ne 0) {
        throw 'Unified setup preserves existing Hyper-V networking. NetworkInterfaceIds must be empty; no Azure NIC is attached by this workflow.'
    }
    $completion = New-AzureLocalVmCompletionPlan $Configuration -EnableGuestManagement
    $replacement = $null
    $replacementArguments = @{}
    if ($ReplaceExistingNetworkAdapter) {
        $LogicalNetworkId = Resolve-LabLogicalNetworkId $Configuration $LogicalNetworkId
        if (-not $BackupPath) { throw 'ReplaceExistingNetworkAdapter requires BackupPath.' }
        if ($ReuseAttachedNetworkInterface -and -not $RegistrationAlreadyComplete) {
            throw 'ReuseAttachedNetworkInterface requires RegistrationAlreadyComplete and an already attached NIC.'
        }
        $replacementArguments = @{
            Configuration = $Configuration; SourceNetworkAdapterId = $SourceNetworkAdapterId
            LogicalNetworkId = $LogicalNetworkId; NetworkInterfaceName = $NetworkInterfaceName
            PrivateIPAddress = $PrivateIPAddress; BackupPath = $BackupPath
            ConnectivityTestHost = $ConnectivityTestHost; ReuseAttachedNetworkInterface = $ReuseAttachedNetworkInterface
            ConvertDhcpToStatic = $ConvertDhcpToStatic
        }
        $replacement = Invoke-AzureLocalVmNicReplacement @replacementArguments
        if ($ReportPath -and (Resolve-LabFilePath $ReportPath) -ieq (Resolve-LabFilePath $BackupPath)) {
            throw 'ReportPath and BackupPath must be different files.'
        }
    } elseif ($SourceNetworkAdapterId -or $LogicalNetworkId -or $NetworkInterfaceName -or $PrivateIPAddress -or
        $BackupPath -or $ReuseAttachedNetworkInterface -or $ConvertDhcpToStatic -or $AcceptNetworkInterruption -or
        $ConnectivityTestHost -ne 'management.azure.com') {
        throw 'NIC replacement options require -ReplaceExistingNetworkAdapter; existing networking is otherwise preserved.'
    }
    $requests = @()
    if (-not $RegistrationAlreadyComplete) { $requests += $registration.Requests }
    $requests += $completion.Requests
    $plan = [pscustomobject]@{
        Status = 'PlanOnly'; Warning = $script:Risk; LiveReadsPerformed = $false; ApiVersion = $script:VmApi
        TenantId = $Configuration.TenantId; SubscriptionId = $Configuration.SubscriptionId
        MachineId = $registration.MachineId; VirtualMachineInstanceId = $registration.VirtualMachineInstanceId
        LocalHost = Get-LabConfiguredHost $Configuration; LocalVmName = $Configuration.LocalVmName; ExpectedVmId = Get-LabConfiguredVmId $Configuration
        RegistrationAlreadyComplete = [bool]$RegistrationAlreadyComplete
        NetworkMode = $(if ($ReplaceExistingNetworkAdapter) { 'ReplaceWithAzureManagedNic' } else { 'PreserveExistingHyperV' })
        Impact = $(if ($replacement) { $replacement.Impact + ' Then enable guest management.' } else { $completion.Impact })
        NicReplacement = $replacement; ReportPath = $ReportPath; Requests = $requests
        ExecutionOrder = @('Registration (unless already complete)', $(if ($replacement) { 'NIC replacement and separately confirmed original removal' }), 'Guest management')
    }
    if (-not $Execute) { return $plan }
    if (-not $EnableUnsupportedLabPreview) { throw 'Execute requires -EnableUnsupportedLabPreview.' }
    if ($ReplaceExistingNetworkAdapter -and -not $AcceptNetworkInterruption) {
        throw 'NIC replacement execution requires -AcceptNetworkInterruption.'
    }
    if (-not $PSCmdlet.ShouldProcess(
        "$($plan.VirtualMachineInstanceId); tenant $($plan.TenantId); subscription $($plan.SubscriptionId); owner $($plan.LocalHost); VM $($plan.LocalVmName); UUID $($plan.ExpectedVmId); custom location $($Configuration.CustomLocationId)",
        "$script:Risk Register VM (unless explicitly already complete) and enable guest management. $($plan.Impact)"
    )) {
        $plan.Status = 'NotExecuted'
        return $plan
    }
    $report = [ordered]@{
        Status = 'InProgress'; Stage = 'Guest preflight'; NetworkMode = $plan.NetworkMode; ApiVersion = $script:VmApi
        RegistrationAlreadyComplete = [bool]$RegistrationAlreadyComplete
        Registration = $null; NicReplacement = $null; Completion = $null
    }
    $reportStream = $null
    try {
        if ($null -eq $GuestCredential) { throw 'Unified setup requires -GuestCredential (Get-Credential); never put a password in JSON.' }
        if ($ReportPath) {
            $reportStream = [IO.File]::Open((Resolve-LabFilePath $ReportPath), [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
            Write-LabSetupReport $reportStream $report
        }
        $context = Get-LabAzureContext $Configuration
        Test-LabInfrastructure $Configuration $context $OwnerNodeSession
        $null = Test-LabGuestAccess $Configuration $OwnerNodeSession $GuestCredential
        if ($replacement) {
            Test-LabSetupNicPreflight $Configuration $context $OwnerNodeSession $GuestCredential $replacement
            $replacementArguments.SourceNetworkAdapterId = $replacement.SourceNetworkAdapterId
            $report.SourceNetworkAdapterId = $replacement.SourceNetworkAdapterId
            $report.SourceSelection = $replacement.SourceSelection
            Write-LabSetupReport $reportStream $report
        }
        $arguments = @{
            Configuration = $Configuration; OwnerNodeSession = $OwnerNodeSession
            Execute = $true; EnableUnsupportedLabPreview = $true; Confirm = $false
            TimeoutSeconds = $TimeoutSeconds; PollSeconds = $PollSeconds
        }
        if (-not $RegistrationAlreadyComplete) {
            $report.Stage = 'Registration'
            Write-LabSetupReport $reportStream $report
            $report.Registration = Invoke-AzureLocalVmRegistration @arguments
            if ($report.Registration.Status -ne 'PreviewProvisioningSucceeded') { throw 'Registration did not confirm provisioning success; guest completion was not started.' }
            Write-LabSetupReport $reportStream $report
        }
        if ($replacement) {
            $report.Stage = 'NIC replacement'
            Write-LabSetupReport $reportStream $report
            $nicConfirm = $true
            if ($PSBoundParameters.ContainsKey('Confirm')) { $nicConfirm = [bool]$PSBoundParameters.Confirm }
            $report.NicReplacement = Invoke-AzureLocalVmNicReplacement @replacementArguments `
                -OwnerNodeSession $OwnerNodeSession -GuestCredential $GuestCredential -Execute -EnableUnsupportedLabPreview `
                -AcceptNetworkInterruption -Confirm:$nicConfirm -TimeoutSeconds $TimeoutSeconds -PollSeconds $PollSeconds
            if ($report.NicReplacement.Status -ne 'PreviewNicReplacementSucceeded' -or -not $report.NicReplacement.OriginalRemoved) {
                throw 'NIC replacement or original removal was not completed; guest management was not started.'
            }
            Write-LabSetupReport $reportStream $report
        }
        $report.Stage = 'Guest management'
        Write-LabSetupReport $reportStream $report
        $report.Completion = Invoke-AzureLocalVmCompletion @arguments -GuestCredential $GuestCredential -EnableGuestManagement
        if ($report.Completion.Status -ne 'PreviewCompletionSucceeded' -or -not $report.Completion.GuestArcConnected) {
            throw 'Guest completion did not confirm an Arc connection.'
        }
        $report.Status = 'PreviewSetupSucceeded'
        $report.Stage = 'Verified'
        $report.Warning = $script:Risk
        Write-LabSetupReport $reportStream $report
        [pscustomobject]$report
    } catch {
        $failure = $_
        $report.Status = 'Failed'
        $report.Message = $failure.Exception.Message
        if ($null -ne $failure.Exception.Data['RegistrationReport']) { $report.Registration = $failure.Exception.Data['RegistrationReport'] }
        if ($null -ne $failure.Exception.Data['NicReplacementReport']) { $report.NicReplacement = $failure.Exception.Data['NicReplacementReport'] }
        if ($null -ne $failure.Exception.Data['CompletionReport']) { $report.Completion = $failure.Exception.Data['CompletionReport'] }
        $report.ManualAction = 'Inspect all phase reports, backups and actual Azure/host/guest state. No automatic retry, rollback or Azure resource cleanup. RegistrationAlreadyComplete skips only registration. Do not repeat NIC replacement after cutover or use a new backup/name to bypass guards. If replacement already succeeded, resume guest management without ReplaceExistingNetworkAdapter. Unattached timeout-created NICs and partial cutovers require manual inspection.'
        try { Write-LabSetupReport $reportStream $report } catch {
            $report.ReportWriteError = $_.Exception.Message
            Write-Warning "Could not persist the setup failure report: $($_.Exception.Message)"
        }
        $exception = [InvalidOperationException]::new("Setup failed at $($report.Stage). $($failure.Exception.Message)", $failure.Exception)
        $exception.Data['SetupReport'] = $report
        throw $exception
    } finally { if ($null -ne $reportStream) { $reportStream.Dispose() } }
}
