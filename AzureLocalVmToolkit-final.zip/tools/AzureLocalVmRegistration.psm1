﻿#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$script:Arm = 'https://management.azure.com'
$script:MachineApi = '2025-01-13'
$script:VmApi = '2026-04-01-preview'
$script:Risk = 'UNSUPPORTED LAB PREVIEW: unmanaged VM conversion is not supported by product documentation. API applicability, target versions and real behavior are unverified. Server-side changes may occur. No automatic rollback.'

function Get-Field($Object, [string]$Name) {
    if ($Object -is [System.Collections.IDictionary]) { return ,$Object[$Name] }
    if ($null -ne $Object -and $null -ne $Object.PSObject.Properties[$Name]) { return ,$Object.$Name }
    return $null
}

function Resolve-LabFilePath([string]$Path) {
    return $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($Path)
}

function Assert-Guid($Value, [string]$Field) {
    $guid = [guid]::Empty
    if ($Value -isnot [string] -or -not [guid]::TryParseExact($Value, 'D', [ref]$guid) -or $guid -eq [guid]::Empty) {
        throw "Invalid nonempty GUID: $Field."
    }
}

function Assert-Id([string]$Id, [string]$Type, [string]$Subscription) {
    $pattern = '^/subscriptions/' + [regex]::Escape($Subscription) +
        '/resourceGroups/[a-zA-Z0-9_.()-]+/providers/' + [regex]::Escape($Type) + '/[a-zA-Z0-9_.()-]+$'
    if ($Id -notmatch $pattern) { throw "Invalid resource ID or subscription for type $Type." }
}

function Resolve-LabLogicalNetworkId($Configuration, [string]$LogicalNetworkId) {
    if ($LogicalNetworkId) {
        Assert-Id $LogicalNetworkId 'Microsoft.AzureStackHCI/logicalNetworks' $Configuration.SubscriptionId
    }
    $configured = Get-Field $Configuration 'LogicalNetworkId'
    if ($configured) {
        if ($LogicalNetworkId -and $LogicalNetworkId -ine $configured) {
            throw 'LogicalNetworkId argument differs from configuration. Remove the stale argument or correct the JSON; no override is performed.'
        }
        return $configured
    }
    if ([string]::IsNullOrWhiteSpace($LogicalNetworkId)) {
        throw 'Specify LogicalNetworkId in the configuration JSON (or as an explicit argument). The network name and resource group are never inferred.'
    }
    return $LogicalNetworkId
}

function Assert-Configuration([System.Collections.IDictionary]$Configuration) {
    $fields = @('TenantId', 'SubscriptionId', 'ResourceGroup', 'MachineName', 'Location',
        'ClusterId', 'CustomLocationId',         'LocalVmName', 'OsType',
        'NetworkInterfaceIds', 'DataDiskIds')
    foreach ($key in $Configuration.Keys) {
                if ($key -cnotin ($fields + @('StackHciApiVersion', 'LogicalNetworkId', 'LocalHost', 'ExpectedVmId')) -and
                    -not ($key -cmatch '^_comment_(ExpectedVmId|NetworkInterfaceIds|DataDiskIds)$' -and $Configuration[$key] -is [string])) { throw 'Unknown configuration field. Secrets and arbitrary API properties are not accepted.' }
    }
    if ($Configuration.Contains('StackHciApiVersion') -and
        ($Configuration.StackHciApiVersion -isnot [string] -or
        $Configuration.StackHciApiVersion -cnotin @('2026-07-01-preview', '2026-04-01-preview'))) {
        throw 'StackHciApiVersion must be 2026-04-01-preview or 2026-07-01-preview; no automatic fallback is performed.'
    }
    foreach ($key in $fields) {
        if (-not $Configuration.Contains($key) -or $null -eq $Configuration[$key]) { throw "Missing configuration field: $key." }
    }
    $guidFields = @('TenantId', 'SubscriptionId')
    if ($Configuration.Contains('ExpectedVmId')) { $guidFields += 'ExpectedVmId' }
    foreach ($key in $guidFields) { Assert-Guid $Configuration[$key] $key }
    $textFields = @($fields | Where-Object { $_ -notin @('NetworkInterfaceIds', 'DataDiskIds') })
    if ($Configuration.Contains('LocalHost')) { $textFields += 'LocalHost' }
    foreach ($key in $textFields) {
        $value = $Configuration[$key]
        $guidance = if ($key -eq 'LocalVmName') {
            ' Retype the exact Hyper-V VM name in the JSON string, save the file, and reload the configuration. Names are not automatically trimmed.'
        } else { '' }
        if ($value -isnot [string]) {
            throw "Invalid text field: $key. Expected a JSON string, not a number, array, or object.$guidance"
        }
        if ([string]::IsNullOrWhiteSpace($value)) {
            throw "Invalid text field: $key. The value is empty or contains only whitespace.$guidance"
        }
        $control = [regex]::Match($value, '[\x00-\x1f]')
        if ($control.Success) {
            $codePoint = 'U+{0:X4}' -f [int][char]$control.Value
            throw "Invalid text field: $key. Found control character $codePoint at zero-based index $($control.Index).$guidance"
        }
    }
    if ($Configuration.ResourceGroup -notmatch '^[a-zA-Z0-9_()-][a-zA-Z0-9_.()-]{0,89}$' -or $Configuration.ResourceGroup.EndsWith('.')) {
        throw 'Invalid ResourceGroup.'
    }
    if ($Configuration.MachineName -notmatch '^[a-zA-Z0-9_.-]{1,54}$') { throw 'Invalid MachineName.' }
    if ($Configuration.Contains('LocalHost') -and $Configuration.LocalHost -notmatch '^[a-zA-Z0-9-]{1,63}$') { throw 'LocalHost must be the short node name. Omit it to discover the owner node automatically.' }
    if ($Configuration.LocalVmName -match '[/\\*?\[\]]' -or $Configuration.LocalVmName.Length -gt 100) { throw 'Invalid literal LocalVmName.' }
    if ($Configuration.Location -notmatch '^[a-z0-9]+$') { throw 'Use the canonical Azure region name for Location.' }
    if ($Configuration.OsType -notin @('Windows', 'Linux')) { throw 'OsType must be Windows or Linux.' }
    Assert-Id $Configuration.ClusterId 'Microsoft.AzureStackHCI/clusters' $Configuration.SubscriptionId
    Assert-Id $Configuration.CustomLocationId 'Microsoft.ExtendedLocation/customLocations' $Configuration.SubscriptionId
    if ($Configuration.Contains('LogicalNetworkId')) {
        if ($Configuration.LogicalNetworkId -isnot [string] -or
            [string]::IsNullOrWhiteSpace($Configuration.LogicalNetworkId) -or
            $Configuration.LogicalNetworkId -match '[\x00-\x1f]') {
            throw 'LogicalNetworkId in configuration must be a nonempty resource ID string.'
        }
        Assert-Id $Configuration.LogicalNetworkId 'Microsoft.AzureStackHCI/logicalNetworks' $Configuration.SubscriptionId
    }
    foreach ($entry in @(@{ Field = 'NetworkInterfaceIds'; Type = 'Microsoft.AzureStackHCI/networkInterfaces' },
            @{ Field = 'DataDiskIds'; Type = 'Microsoft.AzureStackHCI/virtualHardDisks' })) {
        $values = $Configuration[$entry.Field]
        if ($values -isnot [array]) { throw "$($entry.Field) must be an array." }
        $seen = [System.Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
        foreach ($id in $values) {
            if ($id -isnot [string]) { throw "Invalid ID in $($entry.Field)." }
            Assert-Id $id $entry.Type $Configuration.SubscriptionId
            if (-not $seen.Add($id)) { throw "Duplicate ID in $($entry.Field)." }
        }
    }
}

function New-AzureLocalVmRegistrationPlan {
    [CmdletBinding()]
    param([Parameter(Mandatory)][System.Collections.IDictionary]$Configuration)
    Assert-Configuration $Configuration
    $script:VmApi = if ($Configuration.Contains('StackHciApiVersion')) { $Configuration.StackHciApiVersion } else { '2026-04-01-preview' }
    $machineId = "/subscriptions/$($Configuration.SubscriptionId)/resourceGroups/$($Configuration.ResourceGroup)/providers/Microsoft.HybridCompute/machines/$($Configuration.MachineName)"
    $vmId = "$machineId/providers/Microsoft.AzureStackHCI/virtualMachineInstances/default"
    $properties = [ordered]@{
        createFromLocal = $true
        localVmName = $Configuration.LocalVmName
        osProfile = @{}
    }
    $osConfiguration = @{ provisionVMAgent = $false; provisionVMConfigAgent = $false }
    if ($Configuration.OsType -eq 'Windows') { $properties.osProfile.windowsConfiguration = $osConfiguration }
    else { $properties.osProfile.linuxConfiguration = $osConfiguration }
    if ($Configuration.NetworkInterfaceIds.Count -gt 0) {
        $properties.networkProfile = @{ networkInterfaces = @($Configuration.NetworkInterfaceIds | ForEach-Object { @{ id = $_ } }) }
    }
    if ($Configuration.DataDiskIds.Count -gt 0) {
        $properties.storageProfile = @{ dataDisks = @($Configuration.DataDiskIds | ForEach-Object { @{ id = $_ } }) }
    }
    [pscustomobject]@{
        Status = 'PlanOnly'
        ApiVersion = $script:VmApi
        Warning = $script:Risk
        TenantId = $Configuration.TenantId
        SubscriptionId = $Configuration.SubscriptionId
        LocalHost = Get-LabConfiguredHost $Configuration
        LocalVmName = $Configuration.LocalVmName
        ExpectedVmId = Get-LabConfiguredVmId $Configuration
        MachineId = $machineId
        VirtualMachineInstanceId = $vmId
        Requests = @(
            [pscustomobject]@{
                Method = 'PUT'; Uri = "$script:Arm${machineId}?api-version=$script:MachineApi"
                Headers = @{ 'If-None-Match' = '*' }
                Body = @{ location = $Configuration.Location; kind = 'HCI'; identity = @{ type = 'SystemAssigned' } }
            },
            [pscustomobject]@{
                Method = 'PUT'; Uri = "$script:Arm${vmId}?api-version=$script:VmApi"
                Headers = @{ 'If-None-Match' = '*' }
                Body = @{ extendedLocation = @{ name = $Configuration.CustomLocationId; type = 'CustomLocation' }; properties = $properties }
            }
        )
    }
}

function Assert-ArmUri([string]$Uri, [string]$Subscription) {
    $parsed = [uri]$Uri
    if (-not $parsed.IsAbsoluteUri -or $parsed.Scheme -ne 'https' -or $parsed.Host -ne 'management.azure.com' -or
        -not $parsed.IsDefaultPort -or $parsed.UserInfo -or $parsed.Fragment -or
        $parsed.AbsolutePath -notlike "/subscriptions/$Subscription/*" -or $Uri -match '%|\\') {
        throw 'Refusing an ARM URL outside the configured public Azure subscription.'
    }
}

function Resolve-LabOperationUri($Headers, [string]$Subscription) {
    $uri = Get-Field $Headers 'Azure-AsyncOperation'
    if (-not $uri) { $uri = Get-Field $Headers 'Location' }
    if (-not $uri) { return $null }
    $parsed = [uri][string]$uri
    $trustedOrigin = $parsed.IsAbsoluteUri -and $parsed.Scheme -eq 'https' -and
        $parsed.Host -eq 'management.azure.com' -and $parsed.IsDefaultPort -and
        -not $parsed.UserInfo -and -not $parsed.Fragment -and [string]$uri -notmatch '\\'
    if (-not $trustedOrigin) { throw 'Refusing an ARM URL outside the configured public Azure subscription.' }
    $scoped = $parsed.AbsolutePath -like "/subscriptions/$Subscription/*"
    $providerOperation = $parsed.AbsolutePath -like '/providers/Microsoft.AzureStackHCI/*'
    if (-not $scoped -and -not $providerOperation) {
        throw 'Refusing an ARM URL outside the configured public Azure subscription.'
    }
    if (-not $scoped -or [string]$uri -match '%') {
        Write-Warning 'Not following an unrecognized HCI operation URL. Polling only the planned resource GET until terminal provisioning state.'
        return $null
    }
    Assert-ArmUri $uri $Subscription
    return [string]$uri
}

function Get-LabAzureContext($Configuration) {
    Import-Module Az.Accounts -MinimumVersion 5.0.0 -ErrorAction Stop
    $context = Get-AzContext -ErrorAction Stop
    if ($null -eq $context -or $context.Tenant.Id -ine $Configuration.TenantId -or
        $context.Subscription.Id -ine $Configuration.SubscriptionId -or $context.Environment.Name -ne 'AzureCloud') {
        throw 'Azure context tenant/subscription/cloud does not match configuration. Select the context explicitly.'
    }
    return $context
}

function New-LabHttpClient {
    Add-Type -AssemblyName System.Net.Http
    $handler = [System.Net.Http.HttpClientHandler]::new()
    $handler.AllowAutoRedirect = $false
    return [System.Net.Http.HttpClient]::new($handler, $true)
}

function Invoke-LabWindowsHttpRequest([string]$Method, [string]$Uri, $Body, [securestring]$Token, [int]$TimeoutSeconds, [string]$IfMatch) {
    $client = New-LabHttpClient
    $request = $null
    $response = $null
    try {
        $client.Timeout = [TimeSpan]::FromSeconds($TimeoutSeconds)
        $request = [System.Net.Http.HttpRequestMessage]::new([System.Net.Http.HttpMethod]::new($Method), $Uri)
        $request.Headers.Authorization = [System.Net.Http.Headers.AuthenticationHeaderValue]::new(
            'Bearer', [System.Net.NetworkCredential]::new('', $Token).Password)
        if ($Method -eq 'PUT') {
            $request.Headers.IfNoneMatch.Add([System.Net.Http.Headers.EntityTagHeaderValue]::Any)
        }
        if ($Method -eq 'PATCH') {
            $request.Headers.IfMatch.Add([System.Net.Http.Headers.EntityTagHeaderValue]::Parse($IfMatch))
        }
        if ($Method -in @('PUT', 'PATCH')) {
            $request.Content = [System.Net.Http.StringContent]::new(
                ($Body | ConvertTo-Json -Depth 12 -Compress), [Text.Encoding]::UTF8, 'application/json')
        }
        $response = $client.SendAsync($request).GetAwaiter().GetResult()
        $content = $response.Content.ReadAsStringAsync().GetAwaiter().GetResult()
        $headers = @{}
        foreach ($header in $response.Headers) { $headers[$header.Key] = $header.Value -join ',' }
        [pscustomobject]@{ StatusCode = [int]$response.StatusCode; Headers = $headers; Content = $content }
    } finally {
        if ($null -ne $response) { $response.Dispose() }
        if ($null -ne $request) { $request.Dispose() }
        $client.Dispose()
    }
}

function Invoke-LabArmRequest {
    param(
        [ValidateSet('GET', 'PUT', 'PATCH')][string]$Method, [string]$Uri, $Body, $Context,
        [string]$Subscription, [int]$TimeoutSeconds = 30, [string]$IfMatch
    )
    Assert-ArmUri $Uri $Subscription
    if ($Method -eq 'PATCH' -and ([string]::IsNullOrWhiteSpace($IfMatch) -or $IfMatch -eq '*')) {
        throw 'PATCH requires the current resource ETag; unconditional updates are refused.'
    }
    $access = Get-AzAccessToken -ResourceUrl "$script:Arm/" -TenantId $Context.Tenant.Id -DefaultProfile $Context -AsSecureString -ErrorAction Stop
    if ($access.Token -isnot [securestring] -or $access.TenantId -ine $Context.Tenant.Id) { throw 'Unexpected access token type or tenant.' }
    if ($PSVersionTable.PSVersion -lt [version]'7.4') {
        $response = Invoke-LabWindowsHttpRequest $Method $Uri $Body $access.Token $TimeoutSeconds $IfMatch
    } else {
        $arguments = @{
            Uri = $Uri; Method = $Method; Authentication = 'Bearer'; Token = $access.Token
            SkipHttpErrorCheck = $true; MaximumRedirection = 0; MaximumRetryCount = 0
            ConnectionTimeoutSeconds = $TimeoutSeconds; OperationTimeoutSeconds = $TimeoutSeconds
            ErrorAction = 'Stop'; Verbose = $false; Debug = $false
        }
        if ($Method -eq 'PUT') {
            $arguments.Headers = @{ 'If-None-Match' = '*' }
        }
        if ($Method -eq 'PATCH') {
            $arguments.Headers = @{ 'If-Match' = $IfMatch }
        }
        if ($Method -in @('PUT', 'PATCH')) {
            $arguments.Body = $Body | ConvertTo-Json -Depth 12 -Compress
            $arguments.ContentType = 'application/json'
        }
        $response = Invoke-WebRequest @arguments
    }
    $content = if ($response.Content -is [byte[]]) { [Text.Encoding]::UTF8.GetString($response.Content) } else { [string]$response.Content }
    $json = @{}
    if (-not [string]::IsNullOrWhiteSpace($content)) {
        try { $json = ConvertFrom-Json -InputObject $content -ErrorAction Stop }
        catch {
            $exception = [InvalidOperationException]::new("ARM HTTP $([int]$response.StatusCode) returned non-JSON content: $content", $_.Exception)
            $exception.Data['RequestId'] = Get-Field $response.Headers 'x-ms-request-id'
            throw $exception
        }
    }
    [pscustomobject]@{ StatusCode = [int]$response.StatusCode; Headers = $response.Headers; Body = $json }
}

function Assert-Response($Response, [switch]$AllowNotFound) {
    if ($AllowNotFound -and $Response.StatusCode -eq 404) { return }
    if ($Response.StatusCode -lt 200 -or $Response.StatusCode -ge 300) {
        $errorBody = Get-Field $Response.Body 'error'
        $detail = if ($null -eq $errorBody) { 'No ARM error object returned.' } else { $errorBody | ConvertTo-Json -Depth 12 -Compress }
        $exception = [InvalidOperationException]::new("ARM HTTP $($Response.StatusCode): $detail")
        $exception.Data['ArmError'] = $errorBody
        $exception.Data['RequestId'] = Get-Field $Response.Headers 'x-ms-request-id'
        throw $exception
    }
}

function Read-LabResource([string]$Id, [string]$Api, $Context, [string]$Subscription, [switch]$AllowNotFound) {
    $response = Invoke-LabArmRequest GET "$script:Arm${Id}?api-version=$Api" $null $Context $Subscription
    Assert-Response $response -AllowNotFound:$AllowNotFound
    if ($response.StatusCode -eq 404) { return $null }
    if ((Get-Field $response.Body 'id') -ine $Id) { throw "ARM returned a different resource ID for $Id." }
    return $response.Body
}

function Get-LabConfiguredHost($Configuration) {
    if ($Configuration.Contains('LocalHost')) { return $Configuration.LocalHost }
    return '(automatic: current cluster owner node)'
}

function Get-LabHostArgument($Configuration) {
    if ($Configuration.Contains('LocalHost')) { return [string]$Configuration.LocalHost }
    return ''
}

function Read-LabNodeIdentity($Configuration, [System.Management.Automation.Runspaces.PSSession]$OwnerNodeSession) {
    if ($null -ne $OwnerNodeSession) {
        if ($OwnerNodeSession.State -ne 'Opened') { throw 'Owner node session is not open.' }
        return Invoke-Command -Session $OwnerNodeSession -ArgumentList $Configuration.LocalVmName -ScriptBlock {
            param($VmName)
            $ErrorActionPreference = 'Stop'
            $cluster = Get-Cluster -ErrorAction Stop
            [pscustomobject]@{
                HostName = $env:COMPUTERNAME
                VMs = @(Get-VM -ErrorAction Stop | Where-Object { $_.Name -ieq $VmName } |
                    Select-Object Name, Generation, @{ Name = 'State'; Expression = { [string]$_.State } },
                        @{ Name = 'Id'; Expression = { [string]$_.Id } })
                ClusterId = [string]$cluster.Id
                ClusterName = $cluster.Name
            }
        } -ErrorAction Stop
    }
    if ($Configuration.Contains('LocalHost') -and $env:COMPUTERNAME -ine $Configuration.LocalHost) {
        throw 'Run on the VM owner node or supply an OwnerNodeSession from Connect-AzureLocalVmOwnerNode.'
    }
    $cluster = Get-Cluster -ErrorAction Stop
    [pscustomobject]@{
        HostName = $env:COMPUTERNAME
        VMs = @(Get-VM -ErrorAction Stop | Where-Object { $_.Name -ieq $Configuration.LocalVmName })
        ClusterId = [string]$cluster.Id
        ClusterName = $cluster.Name
    }
}

function Assert-LocalVm($Configuration, [System.Management.Automation.Runspaces.PSSession]$OwnerNodeSession) {
    $node = Read-LabNodeIdentity $Configuration $OwnerNodeSession
    if ($Configuration.Contains('LocalHost') -and $node.HostName -ine $Configuration.LocalHost) {
        throw "Authenticated session is on $($node.HostName), not the configured LocalHost. Remove LocalHost from the JSON to discover the owner node automatically."
    }
    $matches = @($node.VMs)
    if ($matches.Count -ne 1) {
        throw 'Local VM name/UUID mismatch or ambiguous VM name. Refusing registration.'
    }
    if (-not $Configuration.Contains('ExpectedVmId')) {
        $resolved = [string]$matches[0].Id
        Assert-Guid $resolved 'ExpectedVmId'
        $Configuration['ExpectedVmId'] = $resolved
    }
    if ([string]$matches[0].Id -ine $Configuration.ExpectedVmId) {
        throw 'Local VM name/UUID mismatch or ambiguous VM name. Refusing registration.'
    }
    # Azure Local resolves createFromLocal by name; use the exact Hyper-V name, not the user's casing.
    $Configuration['LocalVmName'] = [string]$matches[0].Name
}

function Get-LabConfiguredVmId($Configuration) {
    if ($Configuration.Contains('ExpectedVmId')) { return $Configuration.ExpectedVmId }
    return '(automatic: resolved from the unique VM name at run time)'
}

function Test-LabInfrastructure($Configuration, $Context, [System.Management.Automation.Runspaces.PSSession]$OwnerNodeSession) {
    Assert-LocalVm $Configuration $OwnerNodeSession
    $sub = $Configuration.SubscriptionId
    $groupId = "/subscriptions/$sub/resourceGroups/$($Configuration.ResourceGroup)"
    $null = Read-LabResource $groupId '2021-04-01' $Context $sub
    $cluster = Read-LabResource $Configuration.ClusterId '2024-04-01' $Context $sub
    $reported = Get-Field (Get-Field $cluster 'properties') 'reportedProperties'
    $node = Read-LabNodeIdentity $Configuration $OwnerNodeSession
    if ($node.ClusterId -ine (Get-Field $reported 'clusterId') -or
        $node.ClusterName -ine (Get-Field $reported 'clusterName')) { throw 'Local cluster identity differs from the configured Azure Local cluster.' }
    $nodes = @((Get-Field $reported 'nodes') | Where-Object { (Get-Field $_ 'name') -ieq $node.HostName })
    if ($nodes.Count -ne 1) { throw 'Configured local host is not reported as a node of the Azure Local cluster.' }
    $cl = Read-LabResource $Configuration.CustomLocationId '2021-08-15' $Context $sub
    if ((Get-Field $cl 'location') -ine $Configuration.Location) { throw 'Custom location region differs from the planned machine region.' }
    $clProperties = Get-Field $cl 'properties'
    $bridgeId = Get-Field $clProperties 'hostResourceId'
    Assert-Id $bridgeId 'Microsoft.ResourceConnector/appliances' $sub
    $bridge = Read-LabResource $bridgeId '2022-10-27' $Context $sub
    $bridgeProperties = Get-Field $bridge 'properties'
    if ((Get-Field $bridgeProperties 'provisioningState') -ne 'Succeeded' -or
        (Get-Field $bridgeProperties 'status') -ne 'Running' -or
        (Get-Field (Get-Field $bridgeProperties 'infrastructureConfig') 'provider') -ne 'HCI') {
        throw 'Resource bridge is not a running, successfully provisioned HCI bridge.'
    }
    $associated = $false
    foreach ($extensionId in (Get-Field $clProperties 'clusterExtensionIds')) {
        if ($extensionId -notmatch ('^' + [regex]::Escape($bridgeId) + '/providers/Microsoft.KubernetesConfiguration/extensions/[a-zA-Z0-9_.-]+$')) {
            throw 'Custom location extension is not scoped to its resource bridge.'
        }
        $extension = Read-LabResource $extensionId '2024-11-01' $Context $sub
        $settings = Get-Field (Get-Field $extension 'properties') 'configurationSettings'
        if ((Get-Field $settings 'HCIClusterID') -ieq $Configuration.ClusterId) { $associated = $true }
    }
    if (-not $associated) { throw 'Custom location extensions do not identify the configured HCI cluster.' }
    foreach ($id in @($Configuration.NetworkInterfaceIds) + @($Configuration.DataDiskIds)) {
        $resource = Read-LabResource $id $script:VmApi $Context $sub
        if ((Get-Field (Get-Field $resource 'extendedLocation') 'name') -ine $Configuration.CustomLocationId -or
            (Get-Field (Get-Field $resource 'properties') 'provisioningState') -ne 'Succeeded') {
            throw "Referenced NIC/disk is not successfully provisioned in the configured custom location: $id."
        }
    }
}

function Test-LabPreflight($Configuration, $Plan, $Context, [System.Management.Automation.Runspaces.PSSession]$OwnerNodeSession) {
    Test-LabInfrastructure $Configuration $Context $OwnerNodeSession
    $sub = $Configuration.SubscriptionId
    $machine = Read-LabResource $Plan.MachineId $script:MachineApi $Context $sub -AllowNotFound
    $vm = Read-LabResource $Plan.VirtualMachineInstanceId $script:VmApi $Context $sub -AllowNotFound
    if ($null -ne $machine -or $null -ne $vm) { throw 'Destination already exists. Existing parent machines and VM instances are never adopted or updated.' }
    $uri = "$script:Arm/subscriptions/$sub/providers/Microsoft.HybridCompute/machines?api-version=$script:MachineApi"
    $seen = [System.Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    while ($uri) {
        if (-not $seen.Add($uri)) { throw 'Repeated machine list continuation URL.' }
        $list = Invoke-LabArmRequest GET $uri $null $Context $sub
        Assert-Response $list
        $parents = Get-Field $list.Body 'value'
        if ($parents -isnot [array]) { throw 'Machine list response does not contain a value array; duplicate projection check is incomplete.' }
        foreach ($parent in $parents) {
            if ((Get-Field $parent 'kind') -ne 'HCI') { continue }
            $parentId = Get-Field $parent 'id'
            Assert-Id $parentId 'Microsoft.HybridCompute/machines' $sub
            $existing = Read-LabResource "$parentId/providers/Microsoft.AzureStackHCI/virtualMachineInstances/default" $script:VmApi $Context $sub -AllowNotFound
            $properties = Get-Field $existing 'properties'
            if ($null -ne $existing -and (Get-Field (Get-Field $existing 'extendedLocation') 'name') -ieq $Configuration.CustomLocationId -and
                -not (Get-Field $properties 'hyperVVmId') -and -not (Get-Field $properties 'localVmName')) {
                throw "Existing projection under $parentId lacks local VM identifiers; duplicate registration cannot be ruled out."
            }
            if ((Get-Field $properties 'hyperVVmId') -ieq $Configuration.ExpectedVmId -or
                ((Get-Field (Get-Field $existing 'extendedLocation') 'name') -ieq $Configuration.CustomLocationId -and
                 (Get-Field $properties 'localVmName') -ieq $Configuration.LocalVmName)) {
                throw "VM already has an Azure projection under $parentId."
            }
        }
        $uri = Get-Field $list.Body 'nextLink'
    }
}

function Wait-LabDelay([int]$Seconds) { Start-Sleep -Seconds $Seconds }

function Wait-LabProvisioning($Initial, [string]$Id, [string]$Api, $Context, [string]$Subscription, [int]$TimeoutSeconds, [int]$PollSeconds) {
    Assert-Response $Initial
    $clock = [Diagnostics.Stopwatch]::StartNew()
    $response = $Initial
    $operationUri = Resolve-LabOperationUri $Initial.Headers $Subscription
    $asyncHeader = -not [string]::IsNullOrEmpty((Get-Field $Initial.Headers 'Azure-AsyncOperation'))
    while ($true) {
        if ($clock.Elapsed.TotalSeconds -ge $TimeoutSeconds) { throw "Timeout waiting for ARM provisioning of $Id. Server operation may still be running." }
        $state = Get-Field (Get-Field $response.Body 'properties') 'provisioningState'
        $operationState = Get-Field $response.Body 'status'
        if ($state -in @('Failed', 'Canceled') -or $operationState -in @('Failed', 'Canceled')) {
            $detail = $response.Body | ConvertTo-Json -Depth 12 -Compress
            throw "ARM provisioning failed or canceled for ${Id}: $detail"
        }
        $operationDone = (-not $operationUri) -or $operationState -eq 'Succeeded' -or
            (-not $asyncHeader -and $response.StatusCode -in @(200, 204) -and -not $operationState -and $state -notin @('Accepted', 'Creating', 'Updating', 'InProgress'))
        if ($operationDone) {
            $final = Invoke-LabArmRequest GET "$script:Arm${Id}?api-version=$Api" $null $Context $Subscription ([Math]::Max(1, [Math]::Min(30, $TimeoutSeconds - [int]$clock.Elapsed.TotalSeconds)))
            Assert-Response $final -AllowNotFound
            if ($clock.Elapsed.TotalSeconds -ge $TimeoutSeconds) { throw "Timeout waiting for ARM provisioning of $Id. Server operation may still be running." }
            $finalState = Get-Field (Get-Field $final.Body 'properties') 'provisioningState'
            if ($finalState -in @('Failed', 'Canceled')) { throw "ARM resource failed for ${Id}: $($final.Body | ConvertTo-Json -Depth 12 -Compress)" }
            $identity = Get-Field $final.Body 'identity'
            $parentReady = $Api -eq $script:MachineApi -and $final.StatusCode -eq 200 -and
                (Get-Field $final.Body 'kind') -eq 'HCI' -and (Get-Field $identity 'type') -eq 'SystemAssigned' -and
                -not [string]::IsNullOrWhiteSpace((Get-Field $identity 'principalId')) -and
                (-not $finalState -or $finalState -eq 'Succeeded')
            $resourceReady = if ($Api -eq $script:MachineApi) { $parentReady } else { $finalState -eq 'Succeeded' }
            if ($final.StatusCode -eq 200 -and $resourceReady) {
                if ((Get-Field $final.Body 'id') -ine $Id) { throw 'Provisioning returned a different resource ID.' }
                return $final.Body
            }
        }
        $remaining = $TimeoutSeconds - $clock.Elapsed.TotalSeconds
        if ($remaining -le 0) { throw "Timeout waiting for ARM provisioning of $Id. Server operation may still be running." }
        $delay = $PollSeconds
        $retry = Get-Field $response.Headers 'Retry-After'
        $retrySeconds = 0
        if ($retry -and [int]::TryParse([string]$retry, [ref]$retrySeconds) -and $retrySeconds -gt 0) { $delay = $retrySeconds }
        Wait-LabDelay ([int][Math]::Min($delay, [Math]::Ceiling($remaining)))
        if ($clock.Elapsed.TotalSeconds -ge $TimeoutSeconds) { throw "Timeout waiting for ARM provisioning of $Id. Server operation may still be running." }
        if ($operationUri -and -not $operationDone) {
            $response = Invoke-LabArmRequest GET $operationUri $null $Context $Subscription ([Math]::Max(1, [Math]::Min(30, $TimeoutSeconds - [int]$clock.Elapsed.TotalSeconds)))
            Assert-Response $response
        } else { $response = $Initial }
    }
}

function Invoke-AzureLocalVmRegistration {
    [CmdletBinding(SupportsShouldProcess, ConfirmImpact = 'High')]
    param(
        [Parameter(Mandatory)][System.Collections.IDictionary]$Configuration,
        [switch]$Execute,
        [switch]$EnableUnsupportedLabPreview,
        [System.Management.Automation.Runspaces.PSSession]$OwnerNodeSession,
        [ValidateRange(1, 3600)][int]$TimeoutSeconds = 600,
        [ValidateRange(1, 60)][int]$PollSeconds = 5
    )
    $plan = New-AzureLocalVmRegistrationPlan $Configuration
    if (-not $Execute) { return $plan }
    if (-not $EnableUnsupportedLabPreview) { throw 'Execute requires -EnableUnsupportedLabPreview. This is not a supported migration route.' }
    if (-not $PSCmdlet.ShouldProcess("$($plan.MachineId); local VM $($Configuration.LocalVmName) UUID $(Get-LabConfiguredVmId $Configuration); custom location $($Configuration.CustomLocationId); tenant $($Configuration.TenantId)", $script:Risk)) {
        $plan.Status = 'NotExecuted'
        return $plan
    }
    $stage = 'Preflight'
    $operationUri = $null
    $attempted = [System.Collections.Generic.List[string]]::new()
    $confirmed = [System.Collections.Generic.List[string]]::new()
    try {
        $context = Get-LabAzureContext $Configuration
        Test-LabPreflight $Configuration $plan $context $OwnerNodeSession
        foreach ($request in $plan.Requests) {
            $id = if ($request -eq $plan.Requests[0]) { $plan.MachineId } else { $plan.VirtualMachineInstanceId }
            $api = if ($id -eq $plan.MachineId) { $script:MachineApi } else { $script:VmApi }
            $stage = "Create $id"
            Assert-LocalVm $Configuration $OwnerNodeSession
            if ($id -ne $plan.MachineId -and $request.Body.properties.localVmName -cne $Configuration.LocalVmName) {
                $request.Body.properties.localVmName = $Configuration.LocalVmName
            }
            if ($null -ne (Read-LabResource $id $api $context $Configuration.SubscriptionId -AllowNotFound)) {
                throw "Resource appeared after preflight; refusing overwrite: $id."
            }
            $attempted.Add($id)
            $operationUri = $null
            $response = Invoke-LabArmRequest PUT $request.Uri $request.Body $context $Configuration.SubscriptionId ([Math]::Min(30, $TimeoutSeconds))
            Assert-Response $response
            $operationUri = Resolve-LabOperationUri $response.Headers $Configuration.SubscriptionId
            $result = Wait-LabProvisioning $response $id $api $context $Configuration.SubscriptionId $TimeoutSeconds $PollSeconds
            $confirmed.Add($id)
            if ($id -eq $plan.MachineId) {
                if ((Get-Field $result 'kind') -ne 'HCI' -or (Get-Field $result 'location') -ine $Configuration.Location -or
                    (Get-Field (Get-Field $result 'identity') 'type') -ne 'SystemAssigned') { throw 'Created parent machine does not match the planned HCI machine.' }
            } else {
                $stage = 'Verify registered VM identity'
                $properties = Get-Field $result 'properties'
                if ((Get-Field (Get-Field $result 'extendedLocation') 'name') -ine $Configuration.CustomLocationId -or
                    (Get-Field $properties 'localVmName') -ine $Configuration.LocalVmName -or
                    (Get-Field $properties 'hyperVVmId') -ine $Configuration.ExpectedVmId) {
                    throw 'VM registration identity could not be verified or refers to a different VM. Manual investigation required.'
                }
            }
        }
        Assert-LocalVm $Configuration $OwnerNodeSession
        [pscustomobject]@{
            Status = 'PreviewProvisioningSucceeded'; Warning = $script:Risk
            MachineId = $plan.MachineId; VirtualMachineInstanceId = $plan.VirtualMachineInstanceId
            VerifiedHyperVVmId = $Configuration.ExpectedVmId; CreatedResourceIds = $confirmed.ToArray()
            LifecycleOperationsTested = $false
        }
    } catch {
        $report = [ordered]@{
            Status = 'Failed'; Stage = $stage; Message = $_.Exception.Message
            ConfirmedResourceIds = $confirmed.ToArray(); PotentialResourceIds = $attempted.ToArray()
            OperationUri = $operationUri
            ArmError = $_.Exception.Data['ArmError']; RequestId = $_.Exception.Data['RequestId']
            ManualAction = 'Inspect listed resources and ARM operation state in the configured tenant/subscription. Creation may continue after timeout. Do not rerun blindly; existing resources are refused. No resources were deleted or rolled back.'
        }
        $exception = [InvalidOperationException]::new("Registration failed at $stage. $($_.Exception.Message)", $_.Exception)
        $exception.Data['RegistrationReport'] = $report
        throw $exception
    }
}

function Connect-AzureLocalVmOwnerNode {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][System.Collections.IDictionary]$Configuration,
        [string]$ClusterName,
        [pscredential]$Credential
    )
    Assert-Configuration $Configuration
    if ([string]::IsNullOrWhiteSpace($ClusterName)) { $ClusterName = ($Configuration.ClusterId -split '/')[-1] }
    if ($ClusterName -notmatch '^[a-zA-Z0-9.-]{1,253}$') { throw 'ClusterName must be a cluster or node DNS name.' }
    $splat = @{ ComputerName = $ClusterName; ErrorAction = 'Stop' }
    if ($null -ne $Credential) { $splat.Credential = $Credential }
    $entry = New-PSSession @splat
    $owner = $null
    try {
        $vmId = if ($Configuration.Contains('ExpectedVmId')) { [string]$Configuration.ExpectedVmId } else { '' }
        $found = Invoke-Command -Session $entry -ArgumentList $vmId, $Configuration.LocalVmName -ScriptBlock {
            param($VmId, $VmName)
            $ErrorActionPreference = 'Stop'
            $groups = if ($VmId) { @(Get-ClusterGroup -VMId ([guid]$VmId)) }
            else { @(Get-ClusterGroup | Where-Object { [string]$_.GroupType -eq 'VirtualMachine' -and $_.Name -ieq $VmName }) }
            if ($groups.Count -ne 1) { throw "Expected exactly one clustered VM role for the VM; found $($groups.Count)." }
            [pscustomobject]@{ Owner = [string]$groups[0].OwnerNode.Name; Entry = $env:COMPUTERNAME }
        } -ErrorAction Stop
        if ($found.Owner -notmatch '^[a-zA-Z0-9-]{1,63}$') { throw 'Cluster returned an invalid owner node name.' }
        if ($found.Owner -ieq $found.Entry) { $owner = $entry }
        else {
            $splat.ComputerName = $found.Owner
            $owner = New-PSSession @splat
        }
        if ($Configuration.Contains('LocalHost') -and $Configuration.LocalHost -ine $found.Owner) {
            throw "The cluster reports $($found.Owner) as the current owner, but LocalHost is $($Configuration.LocalHost). Remove LocalHost from the JSON to follow the owner automatically."
        }
        $owner
    } catch {
        if ($null -ne $owner -and $owner -ne $entry) { Remove-PSSession $owner -ErrorAction SilentlyContinue }
        $owner = $null
        throw
    } finally {
        if ($null -eq $owner -or $owner -ne $entry) { Remove-PSSession $entry -ErrorAction SilentlyContinue }
    }
}

. (Join-Path $PSScriptRoot 'AzureLocalVmCompletion.ps1')
. (Join-Path $PSScriptRoot 'AzureLocalVmSetup.ps1')
. (Join-Path $PSScriptRoot 'AzureLocalVmNicReplacement.ps1')
Export-ModuleMember -Function Connect-AzureLocalVmOwnerNode, New-AzureLocalVmRegistrationPlan, Invoke-AzureLocalVmRegistration,
    New-AzureLocalVmCompletionPlan, Invoke-AzureLocalVmCompletion, Invoke-AzureLocalVmSetup,
    Invoke-AzureLocalVmNicReplacement
