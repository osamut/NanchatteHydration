#Requires -Version 5.1
[CmdletBinding(SupportsShouldProcess, ConfirmImpact = 'High')]
param(
    [Parameter(Mandatory)][string]$ConfigurationPath,
    [string]$LogicalNetworkId,
    [switch]$AddNetworkInterface,
    [switch]$ConfigureGuestNetwork,
    [switch]$EnableGuestManagement,
    [pscredential]$GuestCredential,
    [System.Management.Automation.Runspaces.PSSession]$OwnerNodeSession,
    [switch]$Execute,
    [switch]$EnableUnsupportedLabPreview,
    [ValidateRange(1, 3600)][int]$TimeoutSeconds = 600,
    [ValidateRange(1, 60)][int]$PollSeconds = 5
)
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot 'AzureLocalVmRegistration.psm1') -Force
$parsed = Get-Content -LiteralPath $ConfigurationPath -Raw | ConvertFrom-Json
if ($null -eq $parsed -or $parsed -isnot [pscustomobject]) { throw 'Configuration must be a JSON object.' }
$configuration = @{}
foreach ($property in $parsed.PSObject.Properties) { $configuration[$property.Name] = $property.Value }
$arguments = @{
    Configuration = $configuration; LogicalNetworkId = $LogicalNetworkId
    AddNetworkInterface = $AddNetworkInterface; ConfigureGuestNetwork = $ConfigureGuestNetwork
    EnableGuestManagement = $EnableGuestManagement; GuestCredential = $GuestCredential
    OwnerNodeSession = $OwnerNodeSession; Execute = $Execute; EnableUnsupportedLabPreview = $EnableUnsupportedLabPreview
    TimeoutSeconds = $TimeoutSeconds; PollSeconds = $PollSeconds
}
if ($PSBoundParameters.ContainsKey('Confirm')) { $arguments.Confirm = $PSBoundParameters.Confirm }
if ($PSBoundParameters.ContainsKey('WhatIf')) { $arguments.WhatIf = $PSBoundParameters.WhatIf }
try {
    Invoke-AzureLocalVmCompletion @arguments | ConvertTo-Json -Depth 15
} catch {
    $report = $_.Exception.Data['CompletionReport']
    if ($null -ne $report) { Write-Error ($report | ConvertTo-Json -Depth 15) -ErrorAction Continue }
    throw
}
