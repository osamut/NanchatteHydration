#Requires -Version 5.1
[CmdletBinding()]
param([Parameter(Mandatory)][string]$OutputPath)
$ErrorActionPreference = 'Stop'
$root = Split-Path $PSScriptRoot
$files = @(
    'README.md', 'examples\registration.example.json',
    'tools\AzureLocalVmRegistration.psm1', 'tools\AzureLocalVmCompletion.ps1',
    'tools\AzureLocalVmSetup.ps1', 'tools\AzureLocalVmNicReplacement.ps1',
    'tools\Register-AzureLocalVm.ps1', 'tools\Complete-AzureLocalVm.ps1',
    'tools\Invoke-AzureLocalVmSetup.ps1', 'tools\Replace-AzureLocalVmNic.ps1',
    'tools\New-AzureLocalVmToolkit.ps1',
    'tests\AzureLocalVmRegistration.Tests.ps1', 'tests\AzureLocalVmCompletion.Tests.ps1',
    'tests\AzureLocalVmNicReplacement.Tests.ps1', 'tests\AzureLocalVmSetup.Tests.ps1'
)
$output = $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($OutputPath)
if ([IO.Path]::GetExtension($output) -ine '.zip') { throw 'OutputPath must be a new .zip file in an existing directory.' }
foreach ($file in $files) {
    if (-not (Test-Path -LiteralPath (Join-Path $root $file) -PathType Leaf)) { throw "Required toolkit file missing: $file" }
}
Add-Type -AssemblyName System.IO.Compression.FileSystem
Add-Type -AssemblyName System.IO.Compression
$stream = [IO.File]::Open($output, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
try {
    $archive = [IO.Compression.ZipArchive]::new($stream, [IO.Compression.ZipArchiveMode]::Create, $true)
    try {
        foreach ($file in $files) {
            $null = [IO.Compression.ZipFileExtensions]::CreateEntryFromFile(
                $archive, (Join-Path $root $file), $file.Replace('\', '/'), [IO.Compression.CompressionLevel]::Optimal)
        }
    } finally { $archive.Dispose() }
    $stream.Flush($true)
} finally { $stream.Dispose() }
[pscustomobject]@{ Path = $output; FileCount = $files.Count; SHA256 = (Get-FileHash -LiteralPath $output -Algorithm SHA256).Hash }
