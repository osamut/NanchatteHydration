#Requires -Version 5.1

function ConvertTo-LabNicMac([string]$Mac) {
    $value = $Mac -replace '[:-]', ''
    if ($value -notmatch '^[0-9a-fA-F]{12}$' -or $value -match '^(0{12}|F{12})$' -or
        ([Convert]::ToInt32($value.Substring(0, 2), 16) -band 1)) { throw 'Missing, multicast or invalid NIC MAC.' }
    return $value.ToUpperInvariant()
}

function Assert-LabSourceNicId([string]$Id, [string]$VmId) {
    $pattern = '^Microsoft:' + [regex]::Escape($VmId) + '\\[0-9a-f-]{36}$'
    if ($Id -notmatch $pattern) { throw 'SourceNetworkAdapterId must be the full Hyper-V adapter ID of the configured VM.' }
    Assert-Guid ($Id.Split('\')[-1]) 'Source NIC ID'
}

function Select-LabSourceNic($Adapters, [string]$Id, [string]$VmId) {
    if ($Id) {
        $matches = @($Adapters | Where-Object Id -EQ $Id)
        if ($matches.Count -ne 1) { throw 'Original Hyper-V NIC ID is absent or ambiguous.' }
        $source = $matches[0]
    } else {
        if (@($Adapters).Count -ne 1) {
            throw "Automatic source NIC selection requires exactly one Hyper-V adapter; found $(@($Adapters).Count). Specify SourceNetworkAdapterId explicitly. No adapter was selected."
        }
        $source = @($Adapters)[0]
    }
    Assert-LabSourceNicId ([string]$source.Id) $VmId
    return $source
}

function Invoke-LabNicHost($Configuration, $OwnerNodeSession, [string]$Action = 'Read', $Source = $null) {
    Assert-LocalVm $Configuration $OwnerNodeSession
    $command = {
        param($HostName, $VmId, $VmName, $Action, $Source)
        $ErrorActionPreference = 'Stop'
        $vm = Get-VM -Id ([guid]$VmId) -ErrorAction Stop
        if (($HostName -and $env:COMPUTERNAME -ine $HostName) -or $vm.Name -ine $VmName -or
            $vm.Generation -ne 2 -or [string]$vm.State -ne 'Running') { throw 'NIC operation owner/VM identity or power state changed.' }
        if ($Action -ne 'Read') {
            $nic = @(Get-VMNetworkAdapter -VM $vm -ErrorAction Stop | Where-Object { [string]$_.Id -ieq $Source.Id })
            if ($nic.Count -ne 1 -or $nic[0].MacAddress -ine $Source.MacAddress) { throw 'Original Hyper-V NIC identity changed.' }
            if ($Action -eq 'Disconnect') {
                if ([string]$nic[0].SwitchId -ine $Source.SwitchId) { throw 'Original NIC switch changed.' }
                Disconnect-VMNetworkAdapter -VMNetworkAdapter $nic[0] -Confirm:$false -ErrorAction Stop
            } elseif ($Action -eq 'Remove') {
                if ($nic[0].SwitchName) { throw 'Original NIC is not disconnected; refusing removal.' }
                Remove-VMNetworkAdapter -VMNetworkAdapter $nic[0] -Confirm:$false -ErrorAction Stop
            } else { throw 'Unknown NIC host action.' }
        }
        @(Get-VMNetworkAdapter -VM $vm -ErrorAction Stop | ForEach-Object {
            $vlan = Get-VMNetworkAdapterVlan -VMNetworkAdapter $_ -ErrorAction Stop
            [pscustomobject]@{
                Id = [string]$_.Id; Name = $_.Name; MacAddress = [string]$_.MacAddress
                SwitchId = [string]$_.SwitchId; SwitchName = $_.SwitchName
                VlanMode = [string]$vlan.OperationMode; VlanId = [int]$vlan.AccessVlanId
                IsLegacy = [bool]$_.IsLegacy
                MacAddressSpoofing = [string]$_.MacAddressSpoofing; PortMirroring = [string]$_.PortMirroringMode
                DhcpGuard = [string]$_.DhcpGuard; RouterGuard = [string]$_.RouterGuard
                AclCount = @(Get-VMNetworkAdapterAcl -VMNetworkAdapter $_ -ErrorAction Stop).Count +
                    @(Get-VMNetworkAdapterExtendedAcl -VMNetworkAdapter $_ -ErrorAction Stop).Count
            }
        })
    }
    $arguments = @((Get-LabHostArgument $Configuration), $Configuration.ExpectedVmId, $Configuration.LocalVmName, $Action, $Source)
    if ($null -ne $OwnerNodeSession) {
        return Invoke-Command -Session $OwnerNodeSession -ScriptBlock $command -ArgumentList $arguments -ErrorAction Stop
    }
    return & $command @arguments
}

function Get-LabNicGuestSnapshot($Configuration, $OwnerNodeSession, $Credential) {
    Invoke-LabGuest $Configuration $OwnerNodeSession $Credential {
        $ErrorActionPreference = 'Stop'
        $adapters = @(Get-NetAdapter -ErrorAction Stop)
        $addresses = @(Get-NetIPAddress -ErrorAction Stop)
        $routes = @(Get-NetRoute -AddressFamily IPv4 -ErrorAction Stop)
        $interfaces = @(Get-NetIPInterface -AddressFamily IPv4 -ErrorAction Stop)
        $dns = @(Get-DnsClientServerAddress -ErrorAction Stop)
        $clients = @(Get-DnsClient -ErrorAction Stop)
        $teamMembers = @()
        if (Get-Command Get-NetLbfoTeamMember -ErrorAction SilentlyContinue) {
            $teamMembers = @(Get-NetLbfoTeamMember -ErrorAction Stop)
        }
        foreach ($nic in $adapters) {
            $index = $nic.InterfaceIndex
            $ipif = @($interfaces | Where-Object InterfaceIndex -EQ $index)
            $client = @($clients | Where-Object InterfaceIndex -EQ $index)
            if ($ipif.Count -ne 1 -or $client.Count -ne 1) { throw 'Guest IPv4/DNS interface inventory is ambiguous.' }
            [pscustomobject]@{
                Name = $nic.Name; InterfaceGuid = [string]$nic.InterfaceGuid; InterfaceIndex = [int]$index
                MacAddress = [string]$nic.MacAddress; Status = [string]$nic.Status
                TeamMember = @($teamMembers | Where-Object Name -EQ $nic.Name).Count -gt 0
                Dhcp = [string]$ipif[0].Dhcp; AutomaticMetric = [string]$ipif[0].AutomaticMetric
                InterfaceMetric = [int]$ipif[0].InterfaceMetric
                NlMtu = [int]$ipif[0].NlMtu
                Forwarding = [string]$ipif[0].Forwarding
                WeakHostSend = [string]$ipif[0].WeakHostSend; WeakHostReceive = [string]$ipif[0].WeakHostReceive
                DnsServers = @($dns | Where-Object InterfaceIndex -EQ $index | ForEach-Object { $_.ServerAddresses })
                DnsSuffix = [string]$client[0].ConnectionSpecificSuffix
                RegisterAddress = [bool]$client[0].RegisterThisConnectionsAddress
                UseSuffix = [bool]$client[0].UseSuffixWhenRegistering
                IPv4 = @($addresses | Where-Object { $_.InterfaceIndex -eq $index -and [string]$_.AddressFamily -eq 'IPv4' } |
                    Sort-Object IPAddress | ForEach-Object {
                        [pscustomobject]@{ IPAddress = $_.IPAddress; PrefixLength = [int]$_.PrefixLength
                            SkipAsSource = [bool]$_.SkipAsSource; AddressState = [string]$_.AddressState }
                    })
                GlobalIPv6 = @($addresses | Where-Object {
                    $_.InterfaceIndex -eq $index -and [string]$_.AddressFamily -eq 'IPv6' -and
                    -not ([Net.IPAddress]::Parse($_.IPAddress)).IsIPv6LinkLocal
                } | ForEach-Object { $_.IPAddress })
                Routes = @($routes | Where-Object { $_.InterfaceIndex -eq $index -and [string]$_.Protocol -ne 'Local' } |
                    Sort-Object DestinationPrefix, NextHop | ForEach-Object {
                        [pscustomobject]@{ DestinationPrefix = $_.DestinationPrefix; NextHop = $_.NextHop
                            RouteMetric = [int]$_.RouteMetric; Protocol = [string]$_.Protocol }
                    })
            }
        }
    }
}

function Get-LabNicByMac($Items, [string]$Mac) {
    $matches = @($Items | Where-Object { ($_.MacAddress -replace '[:-]', '') -ieq $Mac })
    if ($matches.Count -ne 1) { throw 'NIC MAC is absent or ambiguous in inventory.' }
    return $matches[0]
}

function Assert-LabReplacementGuest($Guest, [switch]$Source) {
    Assert-Guid ([string]$Guest.InterfaceGuid).Trim('{}') 'Guest interface GUID'
    if ($Guest.TeamMember -or @($Guest.GlobalIPv6).Count -ne 0 -or
        $Guest.Forwarding -ne 'Disabled' -or $Guest.WeakHostSend -ne 'Disabled' -or $Guest.WeakHostReceive -ne 'Disabled') {
        throw 'NIC replacement does not support teaming, non-link-local IPv6, forwarding or weak-host configuration.'
    }
    if ($Source) {
        if ($Guest.Status -ne 'Up' -or @($Guest.IPv4).Count -ne 1 -or $Guest.IPv4[0].SkipAsSource -or
            $Guest.IPv4[0].AddressState -ne 'Preferred' -or
            @($Guest.Routes).Count -ne 1 -or $Guest.Routes[0].DestinationPrefix -ne '0.0.0.0/0') {
            throw 'Original NIC must be Up with one preferred IPv4 and one default route; additional routes/addresses are not supported.'
        }
        if ($Guest.Dhcp -notin @('Enabled', 'Disabled') -or $Guest.AutomaticMetric -notin @('Enabled', 'Disabled')) {
            throw 'Unknown guest DHCP/metric configuration.'
        }
        Assert-LabIpv4 $Guest.IPv4[0].IPAddress 'Original IPv4'
        Assert-LabIpv4 $Guest.Routes[0].NextHop 'Original gateway'
        if (@($Guest.DnsServers).Count -eq 0) { throw 'Original NIC has no explicit IPv4 DNS server inventory.' }
        foreach ($address in $Guest.DnsServers) { Assert-LabIpv4 $address 'Original DNS' }
    } elseif (@($Guest.Routes | Where-Object DestinationPrefix -NE '0.0.0.0/0').Count -gt 0) {
        throw 'Replacement NIC has additional routes; refusing to discard them.'
    }
}

function ConvertTo-LabIpv4Number([string]$Address) {
    Assert-LabIpv4 $Address 'IPv4 range'
    $bytes = [Net.IPAddress]::Parse($Address).GetAddressBytes()
    return ([uint64]$bytes[0] * 16777216 + [uint64]$bytes[1] * 65536 + [uint64]$bytes[2] * 256 + [uint64]$bytes[3])
}

function Assert-LabReplacementPool($LogicalNetwork, $Configuration, $Source, $Guest, [string]$Address) {
    $properties = Get-Field $LogicalNetwork 'properties'
    $networkType = [string](Get-Field $properties 'networkType')
    if ((Get-Field (Get-Field $LogicalNetwork 'extendedLocation') 'name') -ine $Configuration.CustomLocationId -or
        (Get-Field $properties 'provisioningState') -ne 'Succeeded' -or
        ($networkType -and $networkType -ne 'Workload') -or
        (Get-Field $properties 'vmSwitchName') -cne $Source.SwitchName) {
        throw 'Logical network must be a ready workload network on the original NIC switch/custom location.'
    }
    if (-not $networkType) {
        Write-Warning 'Logical network networkType is not reported. Validating the selected static subnet, switch, VLAN and pool; Azure NIC creation and VM attachment must succeed before any guest cutover. No networkType value is inferred or written.'
    }
    $subnets = @(Get-LabItems $properties 'subnets')
    if ($subnets.Count -ne 1) { throw 'Replacement supports one logical network subnet only.' }
    $subnet = Get-Field $subnets[0] 'properties'
    if ((Get-Field $subnet 'ipAllocationMethod') -ne 'Static') { throw 'Replacement requires a static logical network IP pool.' }
    $vlan = Get-Field $subnet 'vlan'
    if ($null -eq $vlan -or [int]$vlan -ne $Source.VlanId -or $Source.VlanMode -notin @('Untagged', 'Access')) {
        throw 'Original VLAN is incompatible with the logical network; trunk VLANs are not supported.'
    }
    $prefixes = @(Get-LabItems $subnet 'addressPrefixes')
    $prefix = [string](Get-Field $subnet 'addressPrefix')
    if ($prefix) { $prefixes += $prefix }
    $prefixes = @($prefixes | Sort-Object -Unique)
    if ($prefixes.Count -ne 1 -or $prefixes[0] -notmatch '^([0-9.]+)/([0-9]{1,2})$') { throw 'One IPv4 subnet prefix is required.' }
    $network = ConvertTo-LabIpv4Number $Matches[1]
    $length = [int]$Matches[2]
    if ($length -lt 1 -or $length -gt 30 -or $length -ne $Guest.IPv4[0].PrefixLength) {
        throw 'Original prefix length differs from the logical network or is unsupported.'
    }
    $size = [math]::Pow(2, 32 - $length)
    $start = [uint64]([math]::Floor($network / $size) * $size)
    $ip = ConvertTo-LabIpv4Number $Address
    $gateway = ConvertTo-LabIpv4Number $Guest.Routes[0].NextHop
    if ($ip -le $start -or $ip -ge $start + $size - 1 -or $gateway -le $start -or
        $gateway -ge $start + $size - 1 -or $ip -eq $gateway) { throw 'Replacement address/gateway is not usable in the selected subnet.' }
    $inPool = $false
    foreach ($pool in @(Get-LabItems $subnet 'ipPools')) {
        $poolType = [string](Get-Field $pool 'ipPoolType')
        if ($poolType -and $poolType -notin @('vm', 'vippool')) { throw 'Unknown logical network IP pool type.' }
        if ($poolType -eq 'vippool') { continue }
        $first = ConvertTo-LabIpv4Number (Get-Field $pool 'start')
        $last = ConvertTo-LabIpv4Number (Get-Field $pool 'end')
        if ($first -gt $last) { throw 'Invalid logical network IP pool range.' }
        if ($ip -ge $first -and $ip -le $last) {
            if (-not $poolType) {
                Write-Warning 'Selected IP pool ipPoolType is not reported. Range validation alone does not prove allocatability; Azure must allocate and provision this exact VM NIC address successfully before cutover. No pool type is inferred or changed.'
            }
            $inPool = $true
        }
    }
    if (-not $inPool) { throw 'Requested IPv4 is outside the logical network VM IP pool. Specify an approved -PrivateIPAddress; pools are never changed.' }
}

function Save-LabNicBackup([string]$Path, $Backup) {
    $fullPath = Resolve-LabFilePath $Path
    $stream = [IO.File]::Open($fullPath, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
    try {
        $bytes = [Text.UTF8Encoding]::new($false).GetBytes(($Backup | ConvertTo-Json -Depth 30))
        $stream.Write($bytes, 0, $bytes.Length)
        $stream.Flush($true)
    } finally { $stream.Dispose() }
    return $fullPath
}

function Get-LabNicFingerprint($Items) {
    @($Items | Sort-Object InterfaceGuid | Select-Object InterfaceGuid, MacAddress, Status, Dhcp,
        AutomaticMetric, InterfaceMetric, NlMtu, Forwarding, WeakHostSend, WeakHostReceive,
        DnsServers, DnsSuffix, RegisterAddress, UseSuffix, IPv4, GlobalIPv6, Routes) |
        ConvertTo-Json -Depth 12 -Compress
}

function Assert-LabNicTopology($Before, $After, $Source, [string]$TargetMac, [switch]$Reuse,
    [switch]$Disconnected, [switch]$Removed) {
    $target = Get-LabNicByMac $After $TargetMac
    if ($target.Id -ieq $Source.Id -or $target.SwitchId -ine $Source.SwitchId -or
        $target.VlanMode -notin @('Untagged', 'Access') -or $target.VlanId -ne $Source.VlanId) {
        throw 'Replacement host NIC switch/VLAN/identity differs from the original.'
    }
    $expected = @($Before).Count + $(if ($Reuse) { 0 } else { 1 }) - $(if ($Removed) { 1 } else { 0 })
    if (@($After).Count -ne $expected) { throw 'Unexpected number of Hyper-V NICs; refusing further changes.' }
    $macs = @($After | ForEach-Object { ConvertTo-LabNicMac $_.MacAddress })
    if (@($macs | Sort-Object -Unique).Count -ne $macs.Count) { throw 'Duplicate Hyper-V NIC MAC detected.' }
    foreach ($old in $Before | Where-Object { $_.Id -ine $Source.Id -and $_.Id -ine $target.Id }) {
        $actual = @($After | Where-Object Id -EQ $old.Id)
        if ($actual.Count -ne 1 -or
            ($old | Select-Object Id, MacAddress, SwitchId, VlanMode, VlanId | ConvertTo-Json -Compress) -cne
            ($actual[0] | Select-Object Id, MacAddress, SwitchId, VlanMode, VlanId | ConvertTo-Json -Compress)) {
            throw 'An unrelated Hyper-V NIC changed.'
        }
    }
    $original = @($After | Where-Object Id -EQ $Source.Id)
    if ($Removed) {
        if ($original.Count -ne 0) { throw 'Original Hyper-V NIC removal was not confirmed.' }
    } elseif ($original.Count -ne 1 -or $original[0].MacAddress -ine $Source.MacAddress -or
        ($Disconnected -and $original[0].SwitchName) -or
        (-not $Disconnected -and $original[0].SwitchId -ine $Source.SwitchId)) {
        throw 'Original NIC changed unexpectedly or was not disconnected.'
    }
    return $target
}

function Assert-LabReplacementNic($Nic, $Plan, $Configuration, $Guest, [string]$Address) {
    $p = Get-Field $Nic 'properties'
    $ips = @(Get-LabItems $p 'ipConfigurations')
    if ((Get-Field $Nic 'id') -ine $Plan.NetworkInterfaceId -or
        (Get-Field (Get-Field $Nic 'extendedLocation') 'name') -ine $Configuration.CustomLocationId -or
        (Get-Field $p 'provisioningState') -ne 'Succeeded' -or $ips.Count -ne 1) { throw 'Replacement Azure NIC identity/state differs.' }
    $ip = Get-Field $ips[0] 'properties'
    if ((Get-Field (Get-Field $ip 'subnet') 'id') -ine $Plan.LogicalNetworkId -or
        (Get-Field $ip 'privateIPAddress') -ne $Address -or
        [string](Get-Field $ip 'prefixLength') -ne [string]$Guest.IPv4[0].PrefixLength -or
        (Get-Field $ip 'gateway') -ne $Guest.Routes[0].NextHop) {
        throw 'Replacement Azure NIC IP/prefix/gateway/network differs from the intended guest configuration.'
    }
    return ConvertTo-LabNicMac (Get-Field $p 'macAddress')
}

function Assert-LabReplacementReferences($Configuration, $Plan, $Context, $ExpectedIds) {
    $vm = Read-LabCompletionVm $Configuration $Plan $Context
    $actual = @(Get-LabItems (Get-Field (Get-Field $vm.Body 'properties') 'networkProfile') 'networkInterfaces' |
        ForEach-Object { [string](Get-Field $_ 'id') })
    if ((Get-Field (Get-Field $vm.Body 'properties') 'provisioningState') -ne 'Succeeded' -or
        (@($ExpectedIds | Sort-Object) -join '|') -ine (@($actual | Sort-Object) -join '|')) {
        throw 'VM provisioning/NIC references differ from the replacement plan.'
    }
}

function Set-LabReplacementGuest($Configuration, $OwnerNodeSession, $Credential, $OriginalGuest, $TargetGuest, [string]$Address) {
    Invoke-LabGuest $Configuration $OwnerNodeSession $Credential {
        param($Original, $Target, $Address)
        $ErrorActionPreference = 'Stop'
        $all = @(Get-NetAdapter -ErrorAction Stop)
        $old = @($all | Where-Object { [string]$_.InterfaceGuid -ieq $Original.InterfaceGuid -and $_.MacAddress -ieq $Original.MacAddress })
        $new = @($all | Where-Object { [string]$_.InterfaceGuid -ieq $Target.InterfaceGuid -and $_.MacAddress -ieq $Target.MacAddress })
        if ($old.Count -ne 1 -or $new.Count -ne 1 -or $old[0].InterfaceIndex -eq $new[0].InterfaceIndex) { throw 'Guest NIC identity changed before cutover.' }
        $oldIndex = $old[0].InterfaceIndex
        $newIndex = $new[0].InterfaceIndex
        Set-NetIPInterface -InterfaceIndex $oldIndex -AddressFamily IPv4 -Dhcp Disabled -ErrorAction Stop
        Get-NetRoute -AddressFamily IPv4 -ErrorAction Stop |
            Where-Object { $_.InterfaceIndex -eq $oldIndex -and $_.DestinationPrefix -eq '0.0.0.0/0' } |
            Remove-NetRoute -Confirm:$false -ErrorAction Stop
        Get-NetIPAddress -AddressFamily IPv4 -ErrorAction Stop |
            Where-Object InterfaceIndex -EQ $oldIndex | Remove-NetIPAddress -Confirm:$false -ErrorAction Stop
        Set-NetIPInterface -InterfaceIndex $newIndex -AddressFamily IPv4 -Dhcp Disabled -ErrorAction Stop
        Get-NetRoute -AddressFamily IPv4 -ErrorAction Stop |
            Where-Object { $_.InterfaceIndex -eq $newIndex -and $_.DestinationPrefix -eq '0.0.0.0/0' } |
            Remove-NetRoute -Confirm:$false -ErrorAction Stop
        Get-NetIPAddress -AddressFamily IPv4 -ErrorAction Stop |
            Where-Object InterfaceIndex -EQ $newIndex | Remove-NetIPAddress -Confirm:$false -ErrorAction Stop
        $null = New-NetIPAddress -InterfaceIndex $newIndex -IPAddress $Address -PrefixLength $Original.IPv4[0].PrefixLength -ErrorAction Stop
        $null = New-NetRoute -InterfaceIndex $newIndex -DestinationPrefix '0.0.0.0/0' -NextHop $Original.Routes[0].NextHop `
            -RouteMetric $Original.Routes[0].RouteMetric -ErrorAction Stop
        if ($Original.AutomaticMetric -eq 'Enabled') {
            Set-NetIPInterface -InterfaceIndex $newIndex -AddressFamily IPv4 -AutomaticMetric Enabled -ErrorAction Stop
        } else {
            Set-NetIPInterface -InterfaceIndex $newIndex -AddressFamily IPv4 -AutomaticMetric Disabled `
                -InterfaceMetric $Original.InterfaceMetric -ErrorAction Stop
        }
        Set-NetIPInterface -InterfaceIndex $newIndex -AddressFamily IPv4 -NlMtuBytes $Original.NlMtu -ErrorAction Stop
        Set-DnsClientServerAddress -InterfaceIndex $newIndex -ServerAddresses $Original.DnsServers -ErrorAction Stop
        Set-DnsClient -InterfaceIndex $newIndex -ConnectionSpecificSuffix $Original.DnsSuffix `
            -RegisterThisConnectionsAddress $Original.RegisterAddress -UseSuffixWhenRegistering $Original.UseSuffix -ErrorAction Stop
    } @($OriginalGuest, $TargetGuest, $Address)
}

function Test-LabReplacementNetwork($Configuration, $OwnerNodeSession, $Credential, [string]$TargetMac, [string]$Address, [string]$TestHost) {
    Invoke-LabGuest $Configuration $OwnerNodeSession $Credential {
        param($Mac, $Address, $TestHost)
        $ErrorActionPreference = 'Stop'
        $nic = @(Get-NetAdapter -ErrorAction Stop | Where-Object { ($_.MacAddress -replace '[:-]', '') -ieq $Mac })
        if ($nic.Count -ne 1) { throw 'Replacement guest NIC is absent or ambiguous.' }
        $clock = [Diagnostics.Stopwatch]::StartNew()
        do {
            $ip = @(Get-NetIPAddress -AddressFamily IPv4 -ErrorAction Stop | Where-Object {
                $_.InterfaceIndex -eq $nic[0].InterfaceIndex -and $_.IPAddress -eq $Address
            })
            if ($ip.Count -eq 1 -and [string]$ip[0].AddressState -eq 'Duplicate') { throw 'Replacement guest IPv4 failed duplicate-address detection.' }
            if ($ip.Count -eq 1 -and [string]$ip[0].AddressState -eq 'Preferred') { break }
            if ($clock.Elapsed.TotalSeconds -ge 30) { throw 'Replacement guest IPv4 is not Preferred; inspect duplicate-address detection.' }
            Start-Sleep -Seconds 1
        } while ($true)
        $test = Test-NetConnection -ComputerName $TestHost -Port 443 -InformationLevel Detailed -WarningAction Continue
        $sourceAddress = ''
        if ($test.SourceAddress -is [string] -or $test.SourceAddress -is [Net.IPAddress]) {
            $sourceAddress = [string]$test.SourceAddress
        } elseif ($null -ne $test.SourceAddress -and $null -ne $test.SourceAddress.PSObject.Properties['IPAddress']) {
            $sourceAddress = [string]$test.SourceAddress.IPAddress
        }
        if (-not $test.TcpTestSucceeded -or $sourceAddress -ne $Address -or
            $test.InterfaceAlias -cne $nic[0].Name) {
            $diagnostic = [pscustomobject]@{
                ComputerName = $test.ComputerName; SourceAddress = $sourceAddress
                InterfaceAlias = $test.InterfaceAlias; TcpTestSucceeded = $test.TcpTestSucceeded
            }
            throw "Replacement NIC DNS/TCP443 test failed or used another interface: $($diagnostic | ConvertTo-Json -Compress)"
        }
        [pscustomobject]@{
            TestHost = $TestHost; Port = 443; SourceAddress = $sourceAddress
            InterfaceAlias = [string]$test.InterfaceAlias; TcpTestSucceeded = $true
        }
    } @($TargetMac, $Address, $TestHost)
}

function Assert-LabReplacementGuestResult($Before, $After, $Original, $Target, [string]$Address) {
    $actual = Get-LabNicByMac $After (ConvertTo-LabNicMac $Target.MacAddress)
    if ($actual.InterfaceGuid -ine $Target.InterfaceGuid -or $actual.Dhcp -ne 'Disabled' -or
        @($actual.IPv4).Count -ne 1 -or $actual.IPv4[0].IPAddress -ne $Address -or
        $actual.IPv4[0].PrefixLength -ne $Original.IPv4[0].PrefixLength -or
        $actual.NlMtu -ne $Original.NlMtu -or
        $actual.AutomaticMetric -ne $Original.AutomaticMetric -or
        ($Original.AutomaticMetric -eq 'Disabled' -and $actual.InterfaceMetric -ne $Original.InterfaceMetric) -or
        @($actual.Routes).Count -ne 1 -or $actual.Routes[0].DestinationPrefix -ne '0.0.0.0/0' -or
        $actual.Routes[0].NextHop -ne $Original.Routes[0].NextHop -or
        $actual.Routes[0].RouteMetric -ne $Original.Routes[0].RouteMetric -or
        (@($actual.DnsServers) -join ',') -cne (@($Original.DnsServers) -join ',') -or
        $actual.DnsSuffix -cne $Original.DnsSuffix -or $actual.RegisterAddress -ne $Original.RegisterAddress -or
        $actual.UseSuffix -ne $Original.UseSuffix) { throw 'Transferred guest IP/DNS/gateway/metric settings were not verified.' }
    $oldAddresses = @($After | Where-Object InterfaceGuid -EQ $Original.InterfaceGuid | ForEach-Object { $_.IPv4 })
    if (@($oldAddresses | Where-Object { $_.IPAddress -eq $Original.IPv4[0].IPAddress }).Count -gt 0) {
        throw 'Original guest NIC still owns its IPv4 address.'
    }
    $othersBefore = @($Before | Where-Object { $_.InterfaceGuid -ine $Original.InterfaceGuid -and $_.InterfaceGuid -ine $Target.InterfaceGuid })
    $othersAfter = @($After | Where-Object { $_.InterfaceGuid -ine $Original.InterfaceGuid -and $_.InterfaceGuid -ine $Target.InterfaceGuid })
    if ((Get-LabNicFingerprint $othersBefore) -cne (Get-LabNicFingerprint $othersAfter)) { throw 'An unrelated guest NIC configuration changed.' }
}

function Invoke-AzureLocalVmNicReplacement {
    [CmdletBinding(SupportsShouldProcess, ConfirmImpact = 'High')]
    param(
        [Parameter(Mandatory)][System.Collections.IDictionary]$Configuration,
        [string]$SourceNetworkAdapterId,
        [string]$LogicalNetworkId,
        [string]$NetworkInterfaceName,
        [string]$PrivateIPAddress,
        [string]$BackupPath,
        [string]$ConnectivityTestHost = 'management.azure.com',
        [switch]$ReuseAttachedNetworkInterface,
        [switch]$ConvertDhcpToStatic,
        [pscredential]$GuestCredential,
        [System.Management.Automation.Runspaces.PSSession]$OwnerNodeSession,
        [switch]$Execute,
        [switch]$EnableUnsupportedLabPreview,
        [switch]$AcceptNetworkInterruption,
        [ValidateRange(1, 3600)][int]$TimeoutSeconds = 600,
        [ValidateRange(1, 60)][int]$PollSeconds = 5
    )
    $registration = New-AzureLocalVmRegistrationPlan $Configuration
    if ($Configuration.OsType -ne 'Windows') { throw 'NIC replacement supports Windows guests only.' }
    $LogicalNetworkId = Resolve-LabLogicalNetworkId $Configuration $LogicalNetworkId
    if ($SourceNetworkAdapterId -and $Configuration.Contains('ExpectedVmId')) { Assert-LabSourceNicId $SourceNetworkAdapterId $Configuration.ExpectedVmId }
    if (-not $NetworkInterfaceName) { $NetworkInterfaceName = "$($Configuration.MachineName)-nic0" }
    if ($NetworkInterfaceName -notmatch '^[a-zA-Z0-9]$|^[a-zA-Z0-9][a-zA-Z0-9_.-]{0,78}[a-zA-Z0-9_]$') { throw 'Invalid replacement NetworkInterfaceName.' }
    if ($PrivateIPAddress) { Assert-LabIpv4 $PrivateIPAddress 'PrivateIPAddress' }
    if ([uri]::CheckHostName($ConnectivityTestHost) -ne [UriHostNameType]::Dns -or $ConnectivityTestHost -match '[:/\\]') {
        throw 'ConnectivityTestHost must be a DNS host name, not an IP address or URL.'
    }
    $nicId = "/subscriptions/$($Configuration.SubscriptionId)/resourceGroups/$($Configuration.ResourceGroup)/providers/Microsoft.AzureStackHCI/networkInterfaces/$NetworkInterfaceName"
    $plan = [pscustomobject]@{
        Status = 'PlanOnly'; Warning = $script:Risk; LiveReadsPerformed = $false; ApiVersion = $script:VmApi
        TenantId = $Configuration.TenantId; SubscriptionId = $Configuration.SubscriptionId
        MachineId = $registration.MachineId; VirtualMachineInstanceId = $registration.VirtualMachineInstanceId
        LocalHost = Get-LabConfiguredHost $Configuration; ExpectedVmId = Get-LabConfiguredVmId $Configuration
        SourceNetworkAdapterId = $SourceNetworkAdapterId; NetworkInterfaceId = $nicId; LogicalNetworkId = $LogicalNetworkId
        SourceSelection = $(if ($SourceNetworkAdapterId) { 'ExplicitId' } else { 'AutoSingleAdapter' })
        PrivateIPAddress = $PrivateIPAddress; BackupPath = $BackupPath; ConnectivityTestHost = $ConnectivityTestHost
        ReuseAttachedNetworkInterface = [bool]$ReuseAttachedNetworkInterface; ConvertDhcpToStatic = [bool]$ConvertDhcpToStatic
        Impact = 'Back up original IPv4 settings before any mutation; create/attach an Azure NIC (or explicitly reuse one already attached); move IPv4/DNS/default route and metrics using PowerShell Direct; disconnect original NIC; verify new-path DNS/TCP443 and any existing Arc connection; confirm then REMOVE ONLY the original unmanaged Hyper-V adapter. Brief network interruption. No VM power operations, Azure resource deletion, automatic rollback or pool changes.'
        Note = 'Without SourceNetworkAdapterId, execution selects the sole Hyper-V adapter; zero/multiple adapters require an explicit ID. All unmanaged/source suitability checks still apply. Without PrivateIPAddress, reuse the original guest IPv4 exactly; reject it if outside the pool. DHCP requires ConvertDhcpToStatic. Default plan/WhatIf performs no live reads and cannot include discovered settings. BackupPath must be a new protected file in an existing directory.'
    }
    if (-not $Execute) { return $plan }
    if (-not $EnableUnsupportedLabPreview -or -not $AcceptNetworkInterruption) {
        throw 'Execute requires -EnableUnsupportedLabPreview and -AcceptNetworkInterruption.'
    }
    $sourceLabel = if ($SourceNetworkAdapterId) { $SourceNetworkAdapterId } else { 'AUTO: sole Hyper-V adapter (not yet discovered)' }
    if (-not $PSCmdlet.ShouldProcess("$nicId; original $sourceLabel; VM $(Get-LabConfiguredVmId $Configuration); owner $(Get-LabConfiguredHost $Configuration); tenant $($Configuration.TenantId); backup $BackupPath", "$script:Risk $($plan.Impact)")) {
        $plan.Status = 'NotExecuted'
        return $plan
    }
    $state = [ordered]@{
        Status = 'InProgress'; Stage = 'Preflight'; ApiVersion = $script:VmApi
        VmId = $plan.VirtualMachineInstanceId; NicId = $nicId; SourceNetworkAdapterId = $SourceNetworkAdapterId
        SourceSelection = $plan.SourceSelection
        BackupPath = $null; PotentialResourceIds = @(); CreatedResourceIds = @(); ModifiedResourceIds = @()
        GuestCutoverAttempted = $false; OriginalDisconnectAttempted = $false; OriginalDisconnected = $false
        OriginalRemovalAttempted = $false; OriginalRemoved = $false; ConnectivityVerified = $false; ArcVerified = $false
        BeforeRemovalVerified = $false; AfterRemovalVerified = $false
    }
    try {
        if ($null -eq $GuestCredential -or [string]::IsNullOrWhiteSpace($BackupPath)) { throw 'Execute requires GuestCredential and a new BackupPath.' }
        if (Test-Path -LiteralPath $BackupPath) { throw 'BackupPath already exists; refusing overwrite or blind retry.' }
        $context = Get-LabAzureContext $Configuration
        Test-LabInfrastructure $Configuration $context $OwnerNodeSession
        $null = Test-LabGuestAccess $Configuration $OwnerNodeSession $GuestCredential
        $parent = Read-LabResource $plan.MachineId $script:MachineApi $context $Configuration.SubscriptionId
        $identity = Get-Field $parent 'identity'
        if ((Get-Field $parent 'kind') -ne 'HCI' -or (Get-Field $parent 'location') -ine $Configuration.Location -or
            (Get-Field $identity 'type') -ne 'SystemAssigned' -or -not (Get-Field $identity 'principalId') -or
            (Get-Field $identity 'tenantId') -ine $Configuration.TenantId) { throw 'Existing parent identity differs.' }
        $arcWasConnected = (Get-Field (Get-Field $parent 'properties') 'status') -eq 'Connected'
        $current = Read-LabCompletionVm $Configuration $plan $context
        if ((Get-Field (Get-Field $current.Body 'properties') 'provisioningState') -ne 'Succeeded') { throw 'VM is not successfully provisioned.' }
        $refs = @(Get-LabItems (Get-Field (Get-Field $current.Body 'properties') 'networkProfile') 'networkInterfaces')
        $refIds = @($refs | ForEach-Object { [string](Get-Field $_ 'id') })
        if (@($refIds | Sort-Object -Unique).Count -ne $refIds.Count) { throw 'Duplicate Azure NIC references.' }
        $hostBefore = @(Invoke-LabNicHost $Configuration $OwnerNodeSession)
        $source = Select-LabSourceNic $hostBefore $SourceNetworkAdapterId $Configuration.ExpectedVmId
        $SourceNetworkAdapterId = [string]$source.Id
        $plan.SourceNetworkAdapterId = $SourceNetworkAdapterId
        $state.SourceNetworkAdapterId = $SourceNetworkAdapterId
        $sourceMac = ConvertTo-LabNicMac $source.MacAddress
        if (-not $source.SwitchName -or $source.IsLegacy -or $source.MacAddressSpoofing -ne 'Off' -or
            $source.PortMirroring -ne 'None' -or $source.DhcpGuard -ne 'Off' -or $source.RouterGuard -ne 'Off' -or
            $source.AclCount -ne 0) {
            throw 'Original NIC is disconnected, legacy or has unsupported advanced Hyper-V settings.'
        }
        foreach ($id in $refIds) {
            Assert-Id $id 'Microsoft.AzureStackHCI/networkInterfaces' $Configuration.SubscriptionId
            $attached = Read-LabResource $id $script:VmApi $context $Configuration.SubscriptionId
            if ((ConvertTo-LabNicMac (Get-Field (Get-Field $attached 'properties') 'macAddress')) -eq $sourceMac) {
                throw 'Original NIC is already Azure-managed; unmanaged adapter replacement only.'
            }
        }
        $guestBefore = @(Get-LabNicGuestSnapshot $Configuration $OwnerNodeSession $GuestCredential)
        $originalGuest = Get-LabNicByMac $guestBefore $sourceMac
        Assert-LabReplacementGuest $originalGuest -Source
        if ($originalGuest.Dhcp -eq 'Enabled' -and -not $ConvertDhcpToStatic) { throw 'Original NIC uses DHCP; explicitly approve -ConvertDhcpToStatic or stop.' }
        $address = if ($PrivateIPAddress) { $PrivateIPAddress } else { $originalGuest.IPv4[0].IPAddress }
        $state.PrivateIPAddress = $address
        $lnet = Read-LabResource $LogicalNetworkId $script:VmApi $context $Configuration.SubscriptionId
        Assert-LabReplacementPool $lnet $Configuration $source $originalGuest $address
        $nic = Read-LabResource $nicId $script:VmApi $context $Configuration.SubscriptionId -AllowNotFound
        $alreadyAttached = $nicId -iin $refIds
        if ($ReuseAttachedNetworkInterface) {
            if ($null -eq $nic -or -not $alreadyAttached) { throw 'Reuse requires an existing Azure NIC already attached to this exact VM.' }
            $targetMac = Assert-LabReplacementNic $nic $plan $Configuration $originalGuest $address
            $targetGuest = Get-LabNicByMac $guestBefore $targetMac
            Assert-LabReplacementGuest $targetGuest
            $null = Assert-LabNicTopology $hostBefore $hostBefore $source $targetMac -Reuse
        } elseif ($null -ne $nic -or $alreadyAttached) { throw 'Replacement NIC already exists; choose a new name or explicitly reuse an attached NIC.' }
        foreach ($other in $guestBefore | Where-Object { $_.InterfaceGuid -ine $originalGuest.InterfaceGuid }) {
            if ($ReuseAttachedNetworkInterface -and $other.InterfaceGuid -ieq $targetGuest.InterfaceGuid) { continue }
            if (@($other.IPv4 | Where-Object IPAddress -EQ $address).Count -gt 0) { throw 'Requested IPv4 already belongs to another guest NIC.' }
        }
        $state.Stage = 'Persist original network backup'
        $state.BackupPath = Save-LabNicBackup $BackupPath ([ordered]@{
            Format = 'AzureLocalNicReplacementBackup-v1'; CreatedUtc = [DateTime]::UtcNow.ToString('o')
            Plan = $plan; OriginalHostNic = $source; OriginalGuestNic = $originalGuest
            HostAdapters = $hostBefore; GuestAdapters = $guestBefore; AzureNicReferences = $refIds
            DesiredIPv4 = $address; ArcWasConnected = $arcWasConnected
        })
        if (-not $ReuseAttachedNetworkInterface) {
            $state.Stage = 'Create replacement Azure NIC'
            Assert-LocalVm $Configuration $OwnerNodeSession
            if ($null -ne (Read-LabResource $nicId $script:VmApi $context $Configuration.SubscriptionId -AllowNotFound)) { throw 'Replacement NIC appeared after preflight.' }
            $body = @{
                location = $Configuration.Location; extendedLocation = @{ name = $Configuration.CustomLocationId; type = 'CustomLocation' }
                properties = @{ createFromLocal = $false; dnsSettings = @{ dnsServers = @($originalGuest.DnsServers) }
                    ipConfigurations = @(@{ name = 'ipconfig0'; properties = @{ privateIPAddress = $address; subnet = @{ id = $LogicalNetworkId } } }) }
            }
            $state.PotentialResourceIds = @($nicId)
            $response = Invoke-LabArmRequest PUT "$script:Arm${nicId}?api-version=$script:VmApi" $body $context $Configuration.SubscriptionId ([Math]::Min(30, $TimeoutSeconds))
            Assert-Response $response
            $nic = Wait-LabProvisioning $response $nicId $script:VmApi $context $Configuration.SubscriptionId $TimeoutSeconds $PollSeconds
            $state.CreatedResourceIds = @($nicId)
            $targetMac = Assert-LabReplacementNic $nic $plan $Configuration $originalGuest $address
            if ($targetMac -eq $sourceMac) { throw 'Azure allocated the original MAC; refusing duplicate adapters.' }
            $state.Stage = 'Attach replacement Azure NIC'
            $latest = Read-LabCompletionVm $Configuration $plan $context
            $latestRefs = @(Get-LabItems (Get-Field (Get-Field $latest.Body 'properties') 'networkProfile') 'networkInterfaces' | ForEach-Object { [string](Get-Field $_ 'id') })
            if ((@($latestRefs | Sort-Object) -join '|') -ine (@($refIds | Sort-Object) -join '|')) { throw 'Azure NIC references changed before attachment.' }
            $newRefs = @($refIds) + @($nicId)
            $state.ModifiedResourceIds = @($plan.VirtualMachineInstanceId)
            Update-LabCompletionVm $Configuration $plan $context $OwnerNodeSession `
                @{ networkProfile = @{ networkInterfaces = @($newRefs | ForEach-Object { @{ id = $_ } }) } } `
                $TimeoutSeconds $PollSeconds ([string](Get-Field $latest.Headers 'ETag'))
        }
        $state.TargetMacAddress = $targetMac
        $state.Stage = 'Wait for replacement adapter'
        $clock = [Diagnostics.Stopwatch]::StartNew()
        do {
            $hosts = @(Invoke-LabNicHost $Configuration $OwnerNodeSession)
            $guests = @(Get-LabNicGuestSnapshot $Configuration $OwnerNodeSession $GuestCredential)
            $present = @($hosts | Where-Object { ($_.MacAddress -replace '[:-]', '') -ieq $targetMac }).Count -gt 0 -and
                @($guests | Where-Object { ($_.MacAddress -replace '[:-]', '') -ieq $targetMac }).Count -gt 0
            if ($present) { break }
            if ($clock.Elapsed.TotalSeconds -ge $TimeoutSeconds) { throw 'Timeout waiting for replacement NIC realization; original NIC was not changed.' }
            Wait-LabDelay $PollSeconds
        } while ($true)
        $targetHost = Assert-LabNicTopology $hostBefore $hosts $source $targetMac -Reuse:$ReuseAttachedNetworkInterface
        $targetGuest = Get-LabNicByMac $guests $targetMac
        Assert-LabReplacementGuest $targetGuest
        $beforeCutover = @($guestBefore | Where-Object InterfaceGuid -NE $targetGuest.InterfaceGuid)
        $currentCutover = @($guests | Where-Object InterfaceGuid -NE $targetGuest.InterfaceGuid)
        if ((Get-LabNicFingerprint $beforeCutover) -cne (Get-LabNicFingerprint $currentCutover)) { throw 'Original or unrelated guest settings changed after backup.' }
        $expectedRefs = @($refIds | Where-Object { $_ -ine $nicId }) + @($nicId)
        Assert-LabReplacementReferences $Configuration $plan $context $expectedRefs
        $liveNic = Read-LabResource $nicId $script:VmApi $context $Configuration.SubscriptionId
        if ((Assert-LabReplacementNic $liveNic $plan $Configuration $originalGuest $address) -ne $targetMac) { throw 'Azure NIC MAC changed before cutover.' }
        $state.TargetNetworkAdapterId = $targetHost.Id
        $state.Stage = 'Guest network cutover'
        $state.GuestCutoverAttempted = $true
        $null = Set-LabReplacementGuest $Configuration $OwnerNodeSession $GuestCredential $originalGuest $targetGuest $address
        $state.Stage = 'Disconnect original Hyper-V NIC'
        $state.OriginalDisconnectAttempted = $true
        $hosts = @(Invoke-LabNicHost $Configuration $OwnerNodeSession 'Disconnect' $source)
        $null = Assert-LabNicTopology $hostBefore $hosts $source $targetMac -Reuse:$ReuseAttachedNetworkInterface -Disconnected
        $state.OriginalDisconnected = $true
        foreach ($phase in @('Verify before removal', 'Verify after removal')) {
            $state.Stage = $phase
            $state.ConnectivityVerified = $false
            $state.ArcVerified = $false
            $guests = @(Get-LabNicGuestSnapshot $Configuration $OwnerNodeSession $GuestCredential)
            Assert-LabReplacementGuestResult $guestBefore $guests $originalGuest $targetGuest $address
            $state.Connectivity = Test-LabReplacementNetwork $Configuration $OwnerNodeSession $GuestCredential $targetMac $address $ConnectivityTestHost
            $state.ConnectivityVerified = $true
            $finalNic = Read-LabResource $nicId $script:VmApi $context $Configuration.SubscriptionId
            if ((Assert-LabReplacementNic $finalNic $plan $Configuration $originalGuest $address) -ne $targetMac) { throw 'Azure NIC MAC changed during cutover.' }
            Assert-LabReplacementReferences $Configuration $plan $context $expectedRefs
            if ($arcWasConnected) {
                $null = Wait-LabGuestConnected $Configuration $plan $context 'Arc' $TimeoutSeconds $PollSeconds
                $null = Invoke-LabGuest $Configuration $OwnerNodeSession $GuestCredential {
                    if ((Get-Service himds -ErrorAction Stop).Status -ne 'Running') { throw 'Existing Arc service is not running.' }
                }
                $state.ArcVerified = $true
            }
            if ($phase -eq 'Verify before removal') {
                $hosts = @(Invoke-LabNicHost $Configuration $OwnerNodeSession)
                $null = Assert-LabNicTopology $hostBefore $hosts $source $targetMac -Reuse:$ReuseAttachedNetworkInterface -Disconnected
                $state.BeforeRemovalVerified = $true
                if (-not $PSCmdlet.ShouldProcess("$SourceNetworkAdapterId; VM $(Get-LabConfiguredVmId $Configuration); backup $($state.BackupPath)",
                    'New NIC configuration and connectivity verified. Permanently remove ONLY the disconnected original Hyper-V NIC.')) {
                    $state.Status = 'CutoverVerifiedOriginalRetained'; $state.Stage = 'Original removal declined'
                    return [pscustomobject]$state
                }
                $state.Stage = 'Remove original Hyper-V NIC'
                $state.OriginalRemovalAttempted = $true
                $hosts = @(Invoke-LabNicHost $Configuration $OwnerNodeSession 'Remove' $source)
                $null = Assert-LabNicTopology $hostBefore $hosts $source $targetMac -Reuse:$ReuseAttachedNetworkInterface -Removed
                $state.OriginalRemoved = $true
            } else {
                $hosts = @(Invoke-LabNicHost $Configuration $OwnerNodeSession)
                $null = Assert-LabNicTopology $hostBefore $hosts $source $targetMac -Reuse:$ReuseAttachedNetworkInterface -Removed
                $state.AfterRemovalVerified = $true
            }
        }
        $state.Status = 'PreviewNicReplacementSucceeded'; $state.Stage = 'Verified'; $state.Warning = $script:Risk
        return [pscustomobject]$state
    } catch {
        $state.Status = 'Failed'; $state.Message = $_.Exception.Message
        $state.ArmError = $_.Exception.Data['ArmError']; $state.RequestId = $_.Exception.Data['RequestId']
        $state.ManualAction = 'Stop and inspect the saved backup, original/target adapter IDs and Azure resources. Partial guest changes or server operations may remain. No automatic rollback, Azure resource deletion or VM power operations. Before original removal, recover via PowerShell Direct and the saved original switch/VLAN/IP/DNS/DHCP settings; avoid duplicate IPs. After removal, the original adapter GUID cannot be restored by simply creating another adapter. Do not rerun blindly.'
        $exception = [InvalidOperationException]::new("NIC replacement failed at $($state.Stage). $($_.Exception.Message)", $_.Exception)
        $exception.Data['NicReplacementReport'] = $state
        throw $exception
    }
}
