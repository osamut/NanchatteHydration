#Requires -Version 5.1
[CmdletBinding(SupportsShouldProcess, ConfirmImpact = 'High')]
param(
    [Parameter(Mandatory)][string]$ConfigurationPath,
    [string]$SourceNetworkAdapterId,
    [string]$LogicalNetworkId,
    [string]$NetworkInterfaceName,
    [string]$PrivateIPAddress,
    [string]$BackupPath,
    [string]$ConnectivityTestHost = 'management.azure.com',
    [switch]$ReuseAttachedNetworkInterface,
    [switch]$ConvertDhcpToStatic,
    [pscredential]$GuestCredential,
    [System.Management.Automation.Runspaces.PSSession]$OwnerNodeSession,
    [switch]$Execute,
    [switch]$EnableUnsupportedLabPreview,
    [switch]$AcceptNetworkInterruption,
    [ValidateRange(1, 3600)][int]$TimeoutSeconds = 600,
    [ValidateRange(1, 60)][int]$PollSeconds = 5
)
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot 'AzureLocalVmRegistration.psm1') -Force
$parsed = Get-Content -LiteralPath $ConfigurationPath -Raw | ConvertFrom-Json
if ($null -eq $parsed -or $parsed -isnot [pscustomobject]) { throw 'Configuration must be a JSON object.' }
$configuration = @{}
foreach ($property in $parsed.PSObject.Properties) { $configuration[$property.Name] = $property.Value }
$arguments = @{}
foreach ($key in $PSBoundParameters.Keys) {
    if ($key -ne 'ConfigurationPath') { $arguments[$key] = $PSBoundParameters[$key] }
}
$arguments.Configuration = $configuration
try {
    Invoke-AzureLocalVmNicReplacement @arguments | ConvertTo-Json -Depth 30
} catch {
    $report = $_.Exception.Data['NicReplacementReport']
    if ($null -ne $report) { Write-Error ($report | ConvertTo-Json -Depth 30) -ErrorAction Continue }
    throw
}
